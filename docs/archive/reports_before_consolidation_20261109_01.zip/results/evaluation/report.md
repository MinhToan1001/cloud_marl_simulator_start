# Đánh giá Round Robin, Least Loaded và MARL (IPPO)

**Dữ liệu simulation; không phải metrics OpenStack/Kubernetes/AWS.**

Checkpoint episode 20, chọn bằng validation, inference sample với policy RNG riêng có seed cố định.
Policy initialization seed: 7; training workload seeds: [1000, 1299];
validation: [20001, 20002, 20003]; testing độc lập: [30001, 30002, 30003, 30004, 30005].
Mỗi cặp scenario/seed dùng cùng workload, tài nguyên, tick và hạch toán cho cả ba phương pháp.
`metadata.json` lưu hash workload/checkpoint và cấu hình từng scenario; không tune bằng tập testing.

| Scenario | Thuật toán | Throughput req/s | Latency mean ms | P95 ms | Error % | Thành công |
|---|---|---:|---:|---:|---:|---:|
| mixed | round_robin | 169.80 ± 0.18 | 1031.26 ± 13.09 | 2837.44 ± 14.69 | 9.91 ± 0.17 | 30564.60 ± 33.29 |
| mixed | least_loaded | 173.25 ± 0.34 | 1193.22 ± 14.63 | 2901.78 ± 6.94 | 8.40 ± 0.27 | 31185.00 ± 61.53 |
| mixed | marl | 171.47 ± 1.52 | 1068.19 ± 85.94 | 2839.33 ± 41.06 | 9.26 ± 0.56 | 30864.80 ± 273.73 |
| stable | round_robin | 89.56 ± 1.24 | 232.03 ± 2.32 | 473.33 ± 0.00 | 0.00 ± 0.00 | 4030.40 ± 55.97 |
| stable | least_loaded | 89.56 ± 1.24 | 218.73 ± 2.15 | 375.00 ± 2.04 | 0.00 ± 0.00 | 4030.40 ± 55.97 |
| stable | marl | 89.56 ± 1.24 | 230.25 ± 1.72 | 460.00 ± 7.45 | 0.00 ± 0.00 | 4030.40 ± 55.97 |
| ramp_up | round_robin | 138.99 ± 2.23 | 351.37 ± 8.70 | 776.56 ± 27.49 | 0.00 ± 0.00 | 6254.60 ± 100.17 |
| ramp_up | least_loaded | 139.35 ± 2.23 | 323.31 ± 5.22 | 629.00 ± 14.52 | 0.00 ± 0.00 | 6270.80 ± 100.18 |
| ramp_up | marl | 139.23 ± 2.31 | 342.29 ± 5.36 | 733.33 ± 30.28 | 0.00 ± 0.00 | 6265.40 ± 103.92 |
| spike | round_robin | 265.94 ± 1.57 | 1614.20 ± 16.65 | 2945.00 ± 0.00 | 21.69 ± 0.62 | 11967.20 ± 70.64 |
| spike | least_loaded | 270.00 ± 0.00 | 2358.86 ± 14.67 | 2990.33 ± 0.75 | 19.03 ± 1.11 | 12150.00 ± 0.00 |
| spike | marl | 268.17 ± 1.32 | 1731.43 ± 150.30 | 2947.33 ± 5.22 | 20.52 ± 1.04 | 12067.60 ± 59.38 |
| recovery | round_robin | 225.04 ± 1.06 | 1400.30 ± 10.80 | 2902.00 ± 7.50 | 14.38 ± 0.45 | 20254.00 ± 95.04 |
| recovery | least_loaded | 230.99 ± 0.77 | 1654.60 ± 12.53 | 2955.00 ± 2.81 | 12.55 ± 0.79 | 20789.40 ± 69.51 |
| recovery | marl | 227.82 ± 2.72 | 1356.05 ± 81.00 | 2897.44 ± 10.85 | 13.65 ± 0.77 | 20503.80 ± 244.46 |

Giá trị mean ± sample std giữa testing seed; p95 tính trên từng request hoàn tất của từng run rồi tổng hợp.
CPU/RAM trung bình, imbalance, số dropped/waiting và số mẫu hợp lệ cũng có trong `csv/comparison.csv`.

## Diễn giải kết quả

Trong mixed, MARL − round_robin: +1.67 req/s throughput; +36.93 ms latency mean; -0.65 điểm phần trăm error.
Trong mixed, MARL − least_loaded: -1.78 req/s throughput; -125.03 ms latency mean; +0.86 điểm phần trăm error.

Không coi throughput cao hơn là thắng mọi tiêu chí. Kiểm tra đồng thời latency, drop, imbalance và queue cuối.
Đây là đánh giá trên năm seed tải (mặc định), với một seed huấn luyện chính sách; không phải năm lần train độc lập.
Mean/std mô tả biến thiên, chưa phải chứng minh ý nghĩa thống kê hoặc ưu thế ngoài mô hình.

## Ưu điểm và giới hạn

Round Robin đơn giản; Least Loaded phản ứng trực tiếp với backlog/capacity và cần telemetry hiện tại.
MARL học ba policy riêng từ reward, có chi phí training và suy luận; có thể kém baseline nếu học chưa đủ hoặc reward lệch mục tiêu.
Không có imitation hay hardcode kết quả MARL. Training hữu hạn, mạng nhỏ chạy CPU và chọn checkpoint bằng validation.
Stable/Ramp-up/Spike được chạy riêng theo phase; Recovery gồm Spike rồi Recovery để quan sát xả backlog.
Mô hình arrival theo lô một giây, capacity cố định, chưa hiệu chỉnh cluster thật, chỉ có lỗi overflow.
Không drain queue cuối run; dropped/waiting không có latency hoàn tất, nên có censoring.
Không dùng kết quả này để khẳng định hiệu năng OpenStack/AWS thật.

## Dữ liệu và biểu đồ

`csv/summary.csv`: từng run; `comparison.csv`: mean/std; `paired_differences.csv`: chênh lệch paired theo seed;
`cluster_metrics.csv`, `timeseries.csv`, `workload.csv`, `latency_histogram.csv`: dữ liệu để tái kiểm tra.
`figures/`: bảy hình cho scenario mixed, seed đầu tiên ở các time-series; comparison dùng tất cả testing seed.
`figures/scenario_comparison.png`: throughput, latency, error và imbalance giữa các scenario.
