# Kết quả smoke Task 3 — SIMULATED

192 episode: 4 mẫu DAG × 6 scenario × 2 seed mới × 4 heuristic; không huấn luyện MARL. Một trace dùng chung mọi DAG/policy trong cùng scenario và seed.

| Heuristic | E2E mean (s) | Traffic (bytes) | CPU std | RAM std | SLA resolved |
|---|---:|---:|---:|---:|---:|
| round_robin | 0.155548 | 907517.637524 | 0.077804 | 0.043405 | 0.110382 |
| least_loaded | 0.155328 | 829204.444723 | 0.077635 | 0.048195 | 0.111551 |
| random_valid | 0.148128 | 585833.596456 | 0.077669 | 0.069636 | 0.110956 |
| traffic_aware | 0.143273 | 580864.000000 | 0.077476 | 0.061574 | 0.111641 |

Trung bình đều giữa episode; p95/p99 trong metrics.csv là phân vị workflow từng episode, không phải phân vị gộp. Completed-only latency phải đọc cùng failed/unfinished. Heuristic random-valid có thể migration nhiều hơn và chịu overlap; không kết luận thứ hạng MARL.

Calibration V1 low-load, CPU sai số 60,86%; capacity tối đa chưa biết. B/C, WAN, workload DAG, capacity và faults đều giả lập. Không dùng seed test 30001–30005 để tune.

Bằng chứng: [metrics](smoke/metrics.csv), [aggregate](smoke/aggregate.csv), [contract](smoke/contract.json), [metadata](smoke/metadata.json), [traces](smoke/traces/), [ledgers](smoke/episodes/), [JUnit](validation/junit.xml).

Tái hiện: `.venv-task2\Scripts\python.exe -X utf8 -m cli.task3 --output results/task3/<run_moi>`; stage từ chối ghi đè.
