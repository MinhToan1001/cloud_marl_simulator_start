﻿Run thử chưa hoàn tất: lỗi serialize numpy.bool_ khi lưu ledger. Không dùng run này làm bằng chứng kết quả. Đã sửa writer ở CLI, tiếp tục bằng run mới _02; giữ nguyên stage cũ.
