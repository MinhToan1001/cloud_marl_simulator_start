# Báo cáo baseline A + B

Dữ liệu **simulation**, không phải metrics OpenStack/Kubernetes/AWS.

Seeds: 42, 43, 44, 45, 46. Mỗi seed dùng cùng workload và cấu hình cho hai thuật toán.
Nguồn workload: Stable → Ramp-up tuyến tính → Spike → Recovery; jitter có seed.
Tick = 1 giây; FIFO hữu hạn; không xả queue sau thời điểm kết thúc.
CPU/RAM, thời gian phục vụ và độ trễ mạng cơ sở đều là tham số mô hình.

| Thuật toán | Throughput req/s | Latency mean ms | Latency p95 ms | Error % | Thành công | Chờ cuối |
|---|---:|---:|---:|---:|---:|---:|
| round_robin | 169.78 ± 0.72 | 1026.38 ± 18.04 | 2826.56 ± 13.98 | 10.38 ± 0.24 | 30559.60 ± 128.88 | 95.60 ± 15.32 |
| least_loaded | 172.48 ± 0.87 | 1203.08 ± 11.63 | 2905.44 ± 2.73 | 9.24 ± 0.36 | 31045.60 ± 157.29 | 0.00 ± 0.00 |

Các giá trị là mean ± sample standard deviation giữa các seed; một seed có std=0 theo quy ước.
P95 tính nearest-rank từ các request hoàn tất của từng run, rồi tổng hợp giữa seed; không lấy p95 của trung bình theo giây.
Request bị loại hoặc còn chờ không có latency hoàn tất; do đó latency chịu ảnh hưởng của censoring.

## Đọc kết quả

Throughput, latency và error cần được xem đồng thời. Throughput cao hơn không đảm bảo latency thấp hơn.
Round Robin đơn giản và không cần trạng thái tải; Least Loaded cần backlog hiện tại, năng lực và giới hạn queue.
Không có MARL trong thí nghiệm A + B; chưa thể kết luận về MARL hoặc ý nghĩa thống kê.


Chênh lệch mean (Least Loaded − Round Robin) trong các run này: +2.70 req/s throughput; -1.14 điểm phần trăm error; +176.70 ms latency mean.

## Biểu đồ và dữ liệu

`figures/workload.png`, `cpu_utilization.png`, `memory_utilization.png`, `queue_length.png`,
`latency_throughput.png`, `error_rate.png`, `comparison.png`.
Biểu đồ theo thời gian hiển thị seed đầu tiên; comparison tổng hợp tất cả seed.
Dữ liệu gốc nằm trong `csv/`; `metadata.json` lưu cấu hình, môi trường và hash workload để kiểm tra tái lập.

## Hạn chế và bước tiếp theo

Chưa hiệu chỉnh bằng cluster thật; arrival theo lô đầu giây, tài nguyên đồng nhất cho mọi request, không có lỗi mạng ngẫu nhiên.
Error chỉ gồm request bị loại vì vượt tổng chỗ phục vụ và buffer/RAM, không mô phỏng lỗi ứng dụng.
Base latency là thành phần cộng độc lập, không chiếm slot phục vụ. CPU là trung bình trong tick; RAM là đỉnh trước phục vụ.
CPU/RAM tổng hợp là trung bình đều theo cluster và thời gian, không phải trung bình có trọng số phần cứng.
Load imbalance = std dân số của (processed + queue_after) / capacity giữa ba cluster, rồi trung bình theo thời gian.
Cần thiết kế và kiểm thử môi trường MARL (C) trước huấn luyện (D); dùng seed testing riêng ở E; API ở F chưa triển khai.
