# H6 Đóng các thiếu sót Task 2B

**Task 2B chưa nghiệm thu đầy đủ: A4 bị chặn ở quyền truy cập key/sudo trên Ubuntu. Phần B Task 3 tiếp tục độc lập.**

| Hạng mục | Trạng thái | Kết quả |
|---|---|---|
| A1 | DONE | Phân tích đủ 6 scenario, policy/workload SD và paired differences từ run gốc |
| A2 | DONE | Tái tạo telemetry tài nguyên 150 run, xác minh summary khớp; không bịa trường bị thiếu |
| A3 | DONE | 3 checkpoint, CPU 1 thread, warmup 100, 1000 mẫu, mean/p95/p99 |
| A4 | BLOCKED | SSH Windows → Ubuntu đã xác thực; key second-hop Permission denied, sudo -n yêu cầu mật khẩu. Chưa có snapshot REAL mới |
| A5 | PENDING | Chỉ có kế hoạch yêu cầu phê duyệt bằng văn bản; không phát tải thật |
| A6 | DONE | Phân biệt reward/randomization V1 với phần bổ sung V2/Task 4 |

## A1 Kết quả theo scenario

Số là mean từng run; SD policy được tính sau mean qua workload, SD workload sau mean qua policy. Không xem 15 run IPPO là 15 policy seed độc lập.

| Scenario | Method | Throughput ± SD policy / workload | P99 ms ± SD policy / workload | SLA resolved ± SD policy / workload |
|---|---|---|---|---|
| periodic | round_robin | 72.5600 ± N/A / 0.7094 | 1754.5600 ± N/A / 441.4224 | 0.2249 ± N/A / 0.0299 |
| periodic | least_loaded | 73.4533 ± N/A / 1.9694 | 1068.7800 ± N/A / 603.9700 | 0.1719 ± N/A / 0.0718 |
| periodic | ippo | 70.8607 ± 0.8498 / 1.5712 | 2405.8667 ± 499.1876 / 1004.5043 | 0.2571 ± 0.0305 / 0.0587 |

periodic, IPPO − round_robin: throughput -1.6993 req/s; p99 +651.3067 ms; SLA +0.0322. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


periodic, IPPO − least_loaded: throughput -2.5926 req/s; p99 +1337.0867 ms; SLA +0.0852. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| ramp_up | round_robin | 74.7378 ± N/A / 2.8371 | 1731.2400 ± N/A / 1055.4132 | 0.1697 ± N/A / 0.0838 |
| ramp_up | least_loaded | 76.4067 ± N/A / 1.3969 | 1161.9000 ± N/A / 466.4237 | 0.1139 ± N/A / 0.0239 |
| ramp_up | ippo | 74.5789 ± 1.6905 / 2.2477 | 2198.0667 ± 1054.4823 / 578.3716 | 0.1785 ± 0.0552 / 0.0472 |

ramp_up, IPPO − round_robin: throughput -0.1589 req/s; p99 +466.8267 ms; SLA +0.0089. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


ramp_up, IPPO − least_loaded: throughput -1.8278 req/s; p99 +1036.1667 ms; SLA +0.0647. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| recovery | round_robin | 68.0100 ± N/A / 1.0688 | 1166.6800 ± N/A / 395.5244 | 0.4351 ± N/A / 0.0347 |
| recovery | least_loaded | 69.1289 ± N/A / 0.5290 | 1010.6600 ± N/A / 378.7451 | 0.4124 ± N/A / 0.0232 |
| recovery | ippo | 66.7226 ± 2.0550 / 2.2260 | 1522.6800 ± 407.7395 / 560.2586 | 0.4563 ± 0.0274 / 0.0315 |

recovery, IPPO − round_robin: throughput -1.2874 req/s; p99 +356.0000 ms; SLA +0.0212. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


recovery, IPPO − least_loaded: throughput -2.4063 req/s; p99 +512.0200 ms; SLA +0.0438. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| shift | round_robin | 73.7256 ± N/A / 1.1275 | 1000.0200 ± N/A / 491.8217 | 0.1045 ± N/A / 0.0683 |
| shift | least_loaded | 73.9189 ± N/A / 1.2492 | 707.9400 ± N/A / 1273.7185 | 0.0487 ± N/A / 0.0581 |
| shift | ippo | 73.7611 ± 1.1489 / 1.0256 | 1109.9733 ± 762.1261 / 446.0805 | 0.0803 ± 0.0413 / 0.0275 |

shift, IPPO − round_robin: throughput +0.0356 req/s; p99 +109.9533 ms; SLA -0.0242. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


shift, IPPO − least_loaded: throughput -0.1578 req/s; p99 +402.0333 ms; SLA +0.0316. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| spike | round_robin | 49.2856 ± N/A / 3.7765 | 2231.1000 ± N/A / 869.4323 | 0.4683 ± N/A / 0.0742 |
| spike | least_loaded | 52.3556 ± N/A / 1.6490 | 1162.2000 ± N/A / 445.6883 | 0.3995 ± N/A / 0.0672 |
| spike | ippo | 51.1181 ± 0.8341 / 2.1373 | 1681.8267 ± 446.7367 / 408.1394 | 0.4426 ± 0.0200 / 0.0460 |

spike, IPPO − round_robin: throughput +1.8326 req/s; p99 -549.2733 ms; SLA -0.0257. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


spike, IPPO − least_loaded: throughput -1.2374 req/s; p99 +519.6267 ms; SLA +0.0431. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| stable | round_robin | 23.9878 ± N/A / 0.4830 | 37.7800 ± N/A / 0.1789 | 0.0040 ± N/A / 0.0089 |
| stable | least_loaded | 24.0544 ± N/A / 0.3418 | 37.7200 ± N/A / 0.1924 | 0.0012 ± N/A / 0.0026 |
| stable | ippo | 23.9889 ± 0.0195 / 0.4806 | 37.7133 ± 0.0945 / 0.1820 | 0.0040 ± 0.0008 / 0.0088 |

stable, IPPO − round_robin: throughput +0.0011 req/s; p99 -0.0667 ms; SLA -0.0000. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


stable, IPPO − least_loaded: throughput -0.0656 req/s; p99 -0.0067 ms; SLA +0.0028. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


## A2 Cân bằng tài nguyên

File timeseries gốc chỉ có arrival/processed/errors/waiting/placements, không có CPU/RAM. Vì vậy không thể tính đúng các std yêu cầu chỉ từ file đó. Closeout replay frozen V1 để ghi `offline/resource_timeseries_reconstructed.csv`; mọi summary gốc khớp trong 1e-9. Không huấn luyện hoặc sửa file gốc.

| Method | CPU usage std | RAM usage std | CPU reservation std | RAM reservation std | CPU mean | RAM mean | Waste |
|---|---:|---:|---:|---:|---:|---:|---:|
| round_robin | 0.177752 | 0.062582 | 0.102535 | 0.128169 | 0.528023 | 0.305491 | 0.381419 |
| least_loaded | 0.129023 | 0.060231 | 0.099083 | 0.123853 | 0.526926 | 0.299507 | 0.357060 |
| ippo | 0.181311 | 0.060748 | 0.099236 | 0.124045 | 0.522047 | 0.301541 | 0.368799 |

## A3 Thời gian inference

| Policy seed | Mean ms | P95 ms | P99 ms |
|---|---:|---:|---:|
| 7 | 1.5659 | 2.5586 | 4.7292 |
| 17 | 1.3123 | 1.8850 | 2.8848 |
| 27 | 1.2143 | 1.7958 | 3.1852 |

Đây là benchmark local CPU, không phải latency controller/live Kubernetes; tải máy có thể ảnh hưởng tail. Cấu hình máy và phạm vi đo ở `offline/inference.json`.

## A4 và A5

SSH Windows → Ubuntu đã xác thực public key thành công (user nguyenminhtoan). A4 **BLOCKED tại bước quyền truy cập key trên Ubuntu**: đường dẫn second-hop `/opt/stack/.ssh/openstack_key` trả Permission denied; fallback `sudo -n -u stack -H` trả `sudo: a password is required`. Chưa thực hiện được SSH tới ubuntu@172.24.4.16; chưa có snapshot Cluster A fresh hoặc shadow replay mới. Không đọc/copy/chmod key, không hỏi/lưu mật khẩu hoặc sửa SSH. Archive H5 chỉ là tham chiếu quá khứ. Chẩn đoán có UTC ở `connectivity.json`. **Task 2B chưa nghiệm thu đầy đủ** vì A4 chưa hoàn tất; Task 3 tiếp tục độc lập. B/C chưa có thật nên closed_loop_ready=false dù A4 sau này thành công. [Kế hoạch A5](../../../docs/task2/A5_LOAD_TEST_APPROVAL_REQUEST.md) chỉ PENDING; warmup/tải chỉ được chạy ở lượt riêng có phê duyệt đúng file và mức tải.

## A6 Phần đã có và còn thiếu

V1 đã có success, latency/SLO, error, SLO violation, resource waste, migration/overlap cost, failed moves; randomization CPU factor, background CPU, network factor, readiness và faults. V1 actor nhìn toàn bộ 123 features, chưa phải actor local/critic global CTDE.

V2 bổ sung DAG, bốn mục tiêu gồm cân bằng CPU/RAM, traffic bytes/cost theo cạnh, ma trận RTT/bandwidth, CPU/RAM capacity randomization, bandwidth jitter, và schema tách actor/critic. Các miền randomization vẫn ASSUMPTION(SIMULATED), chưa được xác minh thực nghiệm. MAPPO/MADDPG/QMIX training, GA/Single-Agent RL/K8s-default-like benchmarks và nhiều controlled DAG đồng thời để Task 4/5.

Calibration vẫn profile V1 low-load, CPU purged relative MAE 60,86%; maximum capacity null. Không có profile mới vì A5 chưa được duyệt/chạy.

## Bằng chứng và tái hiện

[Closeout artifacts](./), source `src/cli/task2b.py`; `python -m cli.task2b --output <thư mục mới>` tạo stage offline mới và từ chối ghi đè. Seed/trace/config/code fingerprints, runtime freeze, JUnit được lưu cùng run.

## Diễn giải A1 theo paired mean

Các nhận xét sau so với baseline trong cùng scenario/trace; chưa phải kết luận có ý nghĩa thống kê.

- periodic, IPPO so với round_robin: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- periodic, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- ramp_up, IPPO so với round_robin: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- ramp_up, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- recovery, IPPO so với round_robin: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- recovery, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- shift, IPPO so với round_robin: throughput tốt hơn, p99 kém hơn, SLA tốt hơn.
- shift, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- spike, IPPO so với round_robin: throughput tốt hơn, p99 tốt hơn, SLA tốt hơn.
- spike, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- stable, IPPO so với round_robin: throughput tốt hơn, p99 tốt hơn, SLA tốt hơn.
- stable, IPPO so với least_loaded: throughput kém hơn, p99 tốt hơn, SLA kém hơn.

Kiểm toán cuối: 232 file gốc khớp hash; xem `closeout_audit.json`. `junit.xml` là bản sao bộ regression thực 206 test (156 cũ + 50 V2); A4 vẫn BLOCKED, không có snapshot fresh hoặc shadow replay mới.
