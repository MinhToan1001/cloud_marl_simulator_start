# Ghi nhận Cluster A phục hồi và đối chiếu Task 3

Cluster A đã phục hồi theo người dùng: k3s-a Ready, v1.37.2+k3s1; CoreDNS 1/1 Running/Deployment Available 1/1; Metrics Server và Local Path Provisioner 1/1 Running. CPU node 196m (9%), RAM 1180Mi (60%). Calibration workload 1/1 Running ở lần kiểm tra trước. SSH từ Ubuntu VMware user stack tới ubuntu@172.24.4.16 thành công theo người dùng. Nguyên nhân được báo: VM từng SHUTOFF, bật lại thì K3s phục hồi.

Nguồn REAL / USER_REPORTED_MANUAL; chưa xác minh độc lập bằng lệnh của agent ở lượt này. Không có capture UTC hoặc output raw của các lệnh gốc. [manual_observation.json](manual_observation.json) phân biệt thời điểm ghi nhận và thời điểm đo chưa biết.

A4 PENDING, không đánh dấu DONE: thiếu snapshot Node/namespace/Pod/Deployment với UTC/UID/ownerReferences, inventory requests/limits toàn cụm, raw Metrics API timestamp/window và shadow replay placement-v1 trên dữ liệu mới. Không còn kết luận Cluster A offline. [H6 hiện hành](../../../../docs/task2/H6_CLOSEOUT_REPORT.md) và [A4_STATUS.json](../../../../docs/task2/A4_STATUS.json) là cập nhật mới; các artifact closeout trước giữ làm lịch sử.

Task 3 B1–B8 đã hoàn thành trong run dag_v2_20261109_05 với 206 test và 192 episode SIMULATED ở lần nghiệm thu trước. Lượt này đối chiếu độc lập lại artifact: [task3_artifact_verification.json](task3_artifact_verification.json) PASS, code/schema/trace khớp, workflow conservation đúng và đủ 286 feature rows. Không chạy lại smoke/training. Không sửa source simulator, checkpoint hoặc dataset. [Cập nhật Task 3](../../../../docs/task3/PROGRESS_UPDATE.md).

Không thay SSH key, sudoers hay cấu hình OpenStack; không chạy tải. A5 PENDING, closed_loop_ready=false; B/C vẫn giả lập.
