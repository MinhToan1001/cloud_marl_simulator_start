# Task 2 Kết quả calibration và placement IPPO

Đã thực hiện PHẦN 0 và H1–H5 theo phạm vi cục bộ/offline shadow được người dùng phê duyệt. Có simulator placement riêng, calibration profile, ba policy seeds mới, 150 lượt đánh giá và báo cáo sim-to-real. **Chưa có bằng chứng capacity tối đa hoặc closed-loop deployment readiness. CPU calibration chưa đủ ổn định để khẳng định accuracy ngoài miền low-load.**

## Những gì đã hoàn thành

| Hạng mục | Kết quả | Bằng chứng |
|---|---|---|
| H1 audit | routing v1 được phân biệt khỏi placement | [H1](../../../docs/task2/H1_CODE_AUDIT.md) |
| H2 calibration | raw replay khớp, 8 windows, temporal holdout và simulator replay | [H2](../../../docs/task2/H2_CALIBRATION_REPORT.md) |
| H3 implementation | 3 workload agents, 123 features, KEEP/MOVE, validator/lifecycle/masks | [H3](../../../docs/task2/H3_IMPLEMENTATION_REPORT.md) |
| H4 training | 3 seeds × 300 episodes, 30 traces, 150 evaluation runs | [H4](../../../docs/task2/H4_TRAINING_EVALUATION_REPORT.md) |
| H5 shadow | version checks/negative cases, 3-policy archived replay, no writes | [H5](../../../docs/task2/H5_SIM_TO_REAL_READINESS.md) |
| Tests | 156 passed | [JUnit](../../../docs/task2/evidence/task2-tests-final.xml) |

## Kết quả cần đọc trước

RAM/latency low-load có response profile và error estimates; CPU temporal-purged relative MAE 60.86% cho thấy dữ liệu còn yếu. Maximum capacity vẫn `null`, không extrapolate từ CPU thấp. Xem [calibration](calibration/calibration.json), [purged validation](calibration/purged_validation.json), [profile](calibration/profile.json).

So sánh sau đây là **SIMULATED placement**, không phải đo live OpenStack/AWS:

| Thuật toán | Throughput req/s | Mean ms | P95 ms | P99 ms | Error % | SLO violation % | Completed moves |
|---|---:|---:|---:|---:|---:|---:|---:|
| round_robin | 60.384 | 157.00 | 780.48 | 1320.23 | 5.508 | 23.440 | 11.500 |
| least_loaded | 61.553 | 105.90 | 479.61 | 858.20 | 3.688 | 19.127 | 9.867 |
| ippo | 60.172 | 170.11 | 886.38 | 1492.69 | 5.613 | 23.645 | 10.078 |


IPPO không thắng Least Loaded tổng thể; báo cáo giữ đủ seed/scenario. Các percentile là mean của từng run; xem [CSV đầy đủ](evaluation/comparison.csv) để đọc riêng biến thiên policy/workload seeds và [paired differences](evaluation/paired_differences.csv).

![Placement comparison](figures/placement_comparison.png)

## Kiểm tra sản phẩm

- [Config](placement_config.json), [schema](schema.json), [provenance](provenance.json), [runtime](runtime.json), [freeze](runtime-freeze.txt).
- [Training manifest](training/manifest.json), checkpoints [seed 7](training/seed_7/best.pt), [seed 17](training/seed_17/best.pt), [seed 27](training/seed_27/best.pt); từng thư mục còn có last.pt/training.csv/validation.csv.
- [Evaluation metadata](evaluation/metadata.json), [per-run summary](evaluation/summary.csv), [events](evaluation/events.csv), [timeseries](evaluation/timeseries.csv), [latency histograms](evaluation/latency_histogram.csv).
- [Shadow matrix](shadow-matrix.json), [readiness](shadow/readiness.json), [safety/preservation verification](verification.json).
- [Mã simulator](../../../src/placement/), [CLI](../../../src/cli/task2.py), [tests](../../../tests/placement/test_placement.py).

## Chạy lại

Từ workspace, dùng output mới để giữ nguyên mọi kết quả cũ:

```powershell
.\.venv-task2\Scripts\python.exe -m cli.task2 --output results/task2/my_new_run
.\.venv-task2\Scripts\python.exe docs/task2/purged_validation.py --run results/task2/my_new_run
.\.venv\Scripts\python.exe -m pytest -q
```

CLI `--stage` cho phép calibrate/train/evaluate/shadow/plots riêng, mỗi stage từ chối ghi đè thư mục kết quả đã tồn tại. Runtime mới có thể dựng offline bằng [bootstrap_runtime.py](../../../docs/task2/bootstrap_runtime.py) khi các dependencies gốc hiện diện; [requirements/task2.txt](../../../requirements/task2.txt) liệt kê top-level dependencies để dựng trên máy khác. Model loader kiểm tra implementation fingerprint nên sửa physics/reward/schema cần run/checkpoint mới.

## Giới hạn còn lại

SSH Ubuntu timeout; chưa có live verification của A và B/C chưa triển khai. H5 chỉ logic/offline shadow, `closed_loop_ready=false`; không có operation thực thi. Chưa có external-run calibration, saturated-load data hoặc kiểm chứng CPU fit ổn định. Có [kế hoạch thu dữ liệu bổ sung](../../../docs/task2/CONTROLLED_LOAD_TEST_PLAN.md), chưa chạy tải thật.

Các draft `_01`/`_02` được giữ với `SUPERSEDED.md`; **run chính thức để kiểm tra là `placement_v1_20261109_03`**. Dataset, checkpoint routing và kết quả gốc không bị sửa hoặc ghi đè.
