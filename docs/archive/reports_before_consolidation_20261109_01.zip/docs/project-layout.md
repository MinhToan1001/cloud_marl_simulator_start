# Bản đồ project

```text
README.md                  bắt đầu và các lệnh chính
pyproject.toml             đóng gói src, cài editable bằng pip install -e .
requirements.txt           dependency toàn project
requirements/integration.txt  G và tests G, không kéo PyTorch
pytest.ini                 pytest tìm mã trong src/

src/                       mã nguồn theo trách nhiệm
  cloud_sim/               workload, queue, metrics, baseline, CSV và plots
  marl/                    env, reward, IPPO, training và evaluation
  cloud_api/               API simulation chỉ đọc
  integration/             schema, parser, collector, preprocess, calibration, adapters
  apps/sample_api/         HTTP app nhẹ chạy độc lập trong pod
  loadtests/               Locust, bốn giai đoạn tải và giới hạn bảo vệ
  cli/                     lệnh điều phối

configs/                   simulation.json, marl.json và integration/
deploy/k3s/                các manifest triển khai
tests/                     simulation/, marl/, api/, integration/, fixtures/
results/                   chỉ kết quả chính đã bàn giao
  baseline/                csv/, figures/, metadata.json, report.md
  training/                checkpoints/, csv/, figures/, metadata.json, report.md
  evaluation/              csv/, figures/, metadata.json, report.md
data/
  runs/<run-id>/           dữ liệu thu trực tiếp sau khi xác minh cluster
  imported/<run-id>/       dữ liệu chép từ VM, tạo khi cần
  demo/                    đầu ra offline/localhost sinh khi chạy, được gitignore
  validation/              test report, kiểm tra HTTP và checksum bảo toàn
  archive/af-experiments.zip  pilot/smoke và tài liệu lịch sử, giữ byte gốc
legacy/                    simulate.py, README.md và output/ gốc
docs/                      hướng dẫn theo chủ đề
  reports/                 bàn giao, audit và bằng chứng kiểm chứng
dist/                      ZIP sinh khi đóng gói, được gitignore
```

Các thư mục đầu ra được tạo khi cần. `.venv/` là môi trường cục bộ, không đưa vào ZIP.

## Lệnh theo vai trò

Từ thư mục gốc, sau khi `pip install -r requirements.txt` hoặc `pip install -e . --no-deps`:

| Vai trò | Lệnh |
|---|---|
| Baseline | `python -m cli.baselines --output results/my-baseline` |
| Training mới, khi chủ động cần | `python -m cli.train --output results/my-training` |
| Đánh giá checkpoint | `python -m cli.evaluate --checkpoint results/training/checkpoints/best.pt --output results/my-evaluation` |
| Vẽ CSV | `python -m cli.plot --input results/baseline/csv --output data/demo/figures` |
| API | `python -m cli.serve` |
| Collector và calibration | `python -m cli.cluster --help` |
| G offline + localhost | `python -m cli.cluster_smoke --output data/demo/my-stage-g` |
| Kiểm tra HTTP | `python -m cli.verify_api` |
| Kiểm tra 75 lượt đánh giá | `python -m cli.verify_results` |
| Pipeline có training, chỉ chạy khi cần | `python -m cli.pipeline --output results/my-pipeline` |
| Đóng gói | `python -m cli.package` |

Các file `run_baselines.py`, `train_marl.py`, `serve_api.py` và launcher tương tự ở gốc đã bỏ vì chỉ lặp lại CLI.

## Lịch sử và bảo toàn

CSV baseline chuyển cùng biểu đồ/báo cáo sang `results/baseline/`. Training và evaluation chính giữ đường dẫn cũ. Dữ liệu gốc chuyển cùng simulator vào `legacy/`; chạy `python legacy/simulate.py` sẽ ghi vào `legacy/output/` nên không chạy nếu muốn giữ CSV gốc.

`training_smoke*`, `training_greedy_pilot`, `training_large_step`, `pipeline_smoke`, `replay`, `legacy_figures`, demo cũ và tài liệu lịch sử đã được kiểm tra rồi gom vào một ZIP trong `data/archive/`. Tên thành viên ZIP vẫn là đường dẫn trước khi dọn. Giải nén vào thư mục riêng nếu cần đối chiếu. Checksum kết quả chính, source simulator/MARL và ZIP lịch sử nằm ở `data/validation/preserved-files.json`.
