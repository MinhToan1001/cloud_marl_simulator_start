# Kiến trúc simulator và hệ thống A → F

`python -m cli.baselines` → load JSON → tạo workload một lần cho mỗi seed → chạy riêng hai dispatcher trên các cluster mới → tổng hợp CSV/report → Matplotlib PNG. Simulator và policy chỉ dùng thư viện chuẩn; Matplotlib phục vụ biểu đồ và pytest phục vụ test. Lõi mô phỏng không kết nối mạng; collector G được tách riêng và không thay transition/training.

## Trách nhiệm module

`config` định nghĩa dataclass bất biến và validation. `workload` dùng `random.Random(seed)` riêng, không làm thay đổi RNG toàn cục. `model.Cluster` giữ FIFO và cung cấp `observe/step`. `policies.Dispatcher` giữ trạng thái của thuật toán. `engine.simulate` tạo trạng thái mới cho mỗi run, kiểm tra hạch toán mỗi tick và toàn run. `experiments` ghép thí nghiệm công bằng. `storage` và `plotting` tách khỏi logic mô hình.

Sau này có thể thay nguồn `Observation` bằng adapter đo đạc thực, nhưng phải tách nhãn dữ liệu và hiệu chỉnh mô hình. Không đưa SDK OpenStack hoặc hành động hạ tầng thật vào `Cluster.step`.

## Giới hạn tài nguyên

Tick cố định 1 giây; cấu hình năng lực là request/s:

```text
cpu_capacity = cpu_cores * requests_per_core
memory_slots = floor((memory_mb - idle_memory_mb) / memory_per_request_mb)
service_capacity = min(capacity, floor(cpu_capacity), memory_slots)
max_queue = min(queue_limit, memory_slots - service_capacity)
```

Phải phục vụ được ít nhất một request/tick; config không hợp lệ bị từ chối, không âm thầm sửa. `max_queue` là backlog sau service; RAM luôn dành trước một service batch đầy đủ. Đây là giới hạn bảo thủ khi service batch không đầy.

Cho `Q` là backlog đầu giây, `A` là số assigned, `C` là service capacity, `K` là max_queue:

```text
accepted = min(A, C + K - Q)
dropped = A - accepted
processed = min(C, Q + accepted)
queue_after = Q + accepted - processed
Q + A = processed + dropped + queue_after
```

RAM đỉnh trước service gồm memory nền + `(processed + queue_after) * memory_per_request_mb`; CPU trung bình tick là `processed / cpu_capacity * 100`. Cả hai nằm trong [0,100]. CPU có thể dưới 100% khi bottleneck là capacity hoặc RAM. Error ở phiên bản này chỉ là drop vì đầy chỗ, không có lỗi xử lý ngẫu nhiên. Mọi request được phục vụ đều thành công.

## Thời gian và latency

Toàn bộ request của tick `t` đến ở đầu giây `t`. FIFO phục vụ tối đa `C` request, request ở vị trí `k` (bắt đầu 1) hoàn tất ở `t + k/C`. Độ trễ:

```text
latency_ms = 1000 * (t - arrival_second) + 1000 * k/C + base_latency_ms
```

Base latency biểu diễn độ trễ độc lập, không chiếm service slot. Thời điểm CPU/service hoàn tất trong tick quyết định `processed`; phần base latency được cộng vào phản hồi, không theo dõi như một hàng đợi network đang truyền. Đây là mô hình xác định, không phải độ trễ đo thật. Arrival theo lô có thể làm latency cao hơn arrival liên tục.

Latency mean dùng số request hoàn tất làm trọng số. P95 dùng nearest-rank của các mẫu hoàn tất (histogram đầy đủ); không lấy trung bình p95 cluster để làm p95 hệ thống. Không có hoàn tất → giá trị `None`, CSV trống, biểu đồ bỏ mẫu; không ghi latency 0 giả. Cuối run không drain queue, không gán latency cho dropped/waiting.

## Điều phối và thông tin quan sát

Round Robin giữ cursor giữa các tick, kể cả khi một tick có số request không chia hết cho ba. Không dựa vào tài nguyên để đổi tỷ lệ.

Least Loaded xét từng request trong batch hiện tại. Cluster chưa đầy được ưu tiên trước; tiếp theo tối thiểu hóa `(queue + assigned_in_tick + 1)/service_capacity + base_latency_ms/1000`. Nếu tất cả đã đầy, vẫn phân bổ request theo score, sau đó simulator ghi drop đúng ở cluster nhận. Hòa điểm dùng thứ tự cluster trong JSON. Chính sách dùng backlog đầu tick, cấu hình hiện tại và số đã phân bổ của batch hiện tại; không nhận workload tương lai, kết quả service tương lai hoặc RNG tương lai.

Biết batch của giây hiện tại là giả định điều phối theo lô. Khi triển khai streaming thật cần kiểm tra lại mô hình arrival và độ trễ telemetry.

## Metric toàn run

Throughput = tổng processed / số giây, error % = tổng dropped / tổng incoming, không lấy mean error theo tick. CPU/RAM trung bình đều theo cluster và thời gian. Imbalance mỗi tick = population std của `(processed + queue_after)/service_capacity` giữa các cluster; sau đó trung bình theo thời gian. Chỉ số này đo khác biệt tải đã chuẩn hóa, không phải số request tuyệt đối.

`summary.csv` giữ từng run. `comparison.csv` dùng mean và sample std (`ddof=1`) giữa các seed, std=0 nếu chỉ có một mẫu; các cột `_n` ghi số run có metric hợp lệ. Không gộp request từ seed dài/ngắn khác nhau để che giấu sự khác biệt giữa run.

## Mở rộng C → F

`engine.SimulationSession` là lõi transition/metric chung; wrapper `simulate` giữ tương thích A+B. `marl.env` dùng cùng session, quản lý tỷ lệ/action/reward và cung cấp adapter Gymnasium đã qua check_env. `marl.ippo` có ba actor-critic/optimizer độc lập, CPU. `marl.training` ghi checkpoint best/last, optimizer, RNG và log; validation không làm thay đổi RNG training. Chi tiết feature, reward, GAE và action normalization nằm trong `marl.md`.

`marl.evaluation` đóng băng checkpoint chọn bằng validation, chạy paired workload testing cho cả ba phương pháp và tổng hợp riêng từng scenario. `metadata.json` lưu seed split, config và hash workload/checkpoint. Không dùng heuristic baseline để thay action của MARL.

`cloud_api.app.create_app(results_dir)` đọc CSV/metadata của baseline hoặc evaluation, không import PyTorch ở startup, không giữ cloud credentials và không có endpoint điều khiển hạ tầng thật. Bốn GET endpoints gắn nhãn simulation; xem `api.md` về OpenAPI, filter, phân trang và CORS. React chưa được sửa vì không có source website trong workspace.

## G — biên thu thập dữ liệu

`src/integration/` chứa schema, quantities/parser, collector read-only, preprocess và calibration. K3s inventory/metrics và app counters được lưu riêng trong data/runs; không ghi vào results A–F hoặc thay nhãn API simulation. Node/pod/application/client/host/hypervisor giữ layer và source rõ ràng. Fixture có source simulated; live phải qua context/node/pod identity checks.

`src/apps/sample_api` là server stdlib độc lập; `deploy/k3s` giữ manifest; `loadtests` chứa Locust/profile/guard. `src/cli/cluster.py` là entrypoint G; `src/cli/cluster_smoke.py` chỉ test offline/localhost. Không có code apply cluster hoặc restart cloud tự động. Xem `real-cluster-integration.md`, `k3s-deployment.md`, `metrics-calibration.md` và `project-layout.md`.

`python -m cli.pipeline` kiểm thử trước rồi chạy baseline, training và evaluation trong một output mới; `python -m cli.package` đóng gói source/tài liệu/checkpoint/kết quả, bỏ venv/cache và kiểm tra SHA-256 manifest. API được khởi động riêng bằng `python -m cli.serve`.
