# Schema, chuẩn hóa và hiệu chỉnh

## Source và lớp quan sát

`integration.schema.MetricRecord`/CSV schema_version=1 dùng chung cho collector và bản export simulator. **source chỉ nhận `real` hoặc `simulated`**; API A–F vẫn giữ `data_source=simulation` để tương thích, không đổi dữ liệu cũ. `collection_mode` bổ sung live/offline_fixture/simulator_export/local_test. Fixture không được phép ghi source real. App/Locust trên localhost Windows được xếp simulated/local_test để không dùng nhầm làm số đo K3s A.

| layer | Ý nghĩa | cluster_id |
|---|---|---|
| ubuntu_host | /proc của Ubuntu chạy VMware/DevStack | bắt buộc trống |
| openstack_hypervisor | /proc trên OS được xác minh là hypervisor | bắt buộc trống |
| k3s_node | CPU/RAM toàn VM/node K3s, gồm OS/control-plane/pod | A |
| k3s_pod | working-set/CPU của pod đã chọn theo namespace/label | A |
| application | counters và service latency bên trong sample app | A, hoặc cluster mô phỏng khi export |
| client | response/latency/error thấy từ Locust, gồm mạng/tunnel | A nếu thật, trống nếu local smoke |

Nếu Ubuntu host cũng là hypervisor, đó là hai vai trò của **cùng** OS, không phải hai tập tài nguyên để cộng. CPU host không biến thành CPU A. Node K3s được đối chiếu VM OpenStack bằng hostname/IP/ID ở bước khám phá; collector không tự suy diễn topology từ địa chỉ backend.

## Các trường và đơn vị

Timestamp ISO-8601 có timezone, normalized về UTC khi so sánh. `timestamp_utc` là thời điểm metric gốc/window end; `observed_at_utc` là thời điểm collector, để kiểm tra staleness. `run_id`, `workload_sha256` gắn profile; metadata_json chứa work CPU/memory, cửa sổ, denominator và provenance. Inventory chỉ lưu tên/UID/resource/status, không ghi pod env/annotations hoặc kubeconfig/token.

CPU lưu usage **cores**: 250m=0,25 core, 125000000n=0,125 core. Memory lưu bytes: Ki/Mi/Gi là nhị phân, K/M/G là thập phân. Node % dùng node.status.capacity; pod % dùng tổng container **limits** khi tất cả có limit, không dùng requests làm denominator. Thiếu limit → usage vẫn có, % là null. Không tự điền giá trị thiếu bằng zero.

Metrics API CPU là average trên `window`, memory là working set, không giống Linux MemAvailable. [Kubernetes resource metrics](https://kubernetes.io/docs/tasks/debug/debug-cluster/resource-metrics-pipeline/) và [Metrics Server](https://kubernetes-sigs.github.io/metrics-server/) nêu đây là tín hiệu phục vụ autoscaling, không dành cho phép đo monitoring chính xác. Đợt G dùng addon sẵn có để thăm dò nhẹ; trước hiệu chỉnh khoa học cuối cần kiểm tra/chọn kubelet resource metrics hoặc đo app/proc/cgroup phù hợp, không âm thầm xem dữ liệu smoothed là ground truth.

## Request và latency

App chỉ đếm `/work`; health/metrics không vào workload. Counters trong một instance bảo toàn:

```text
received_total = completed_total + errors_total + inflight
```

completed nghĩa là service work xong thành công, không bảo đảm client đã nhận response. errors gồm 429 khi hết work slot; lỗi transport/client timeout có thể chỉ thấy từ Locust. `inflight` **không phải queue length**; queue_length real để null vì không đo được TCP/worker backlog. Simulator exporter có queue_length rõ ràng theo mô hình, không gán queue thật từ chênh lệch counters một cách suy đoán.

Delta giữa hai lần poll trong cùng instance:

```text
incoming_rps  = delta(received_total) / delta(app monotonic uptime)
completed_rps = delta(completed_total) / delta(app monotonic uptime)
error_rps     = delta(errors_total) / delta(app monotonic uptime)
error_rate    = errors / (completed + errors) * 100  # response outcomes của cửa sổ
```

Đây là denominator theo outcome của app window; khác simulator drop/incoming nếu còn in-flight. Row đầu là warmup, rate/latency null. Counter reset/uptime không tăng → không tạo rate âm hoặc spike; UUID mới → warmup mới.

App giữ tối đa 4096 completion events, sequence tăng đơn điệu; collector yêu cầu events sau cursor. Mean dùng delta latency sum/count của **successful server work**; p95 nearest-rank đúng các successful events trong interval. Nếu events bị mất, mean từ counter còn có thể tính, p95 để null, quality=latency_events_lost; không lấy p95 từ mean hoặc cửa sổ rolling khác thời gian. Sample app một replica; nhiều replica cần URL/cursor riêng theo pod, không scrape service load-balancer rồi coi là một series.

Locust raw CSV có từng response, source/run/profile/phase. Stats/history CSV Locust có percentile histogram xấp xỉ; normalizer tự tính nearest-rank từ requests.csv cho successful client responses. Latency client bao gồm Windows→SSH/network→service; không trộn với server latency. Common client window cuối có thể ngắn hơn 15s, được đánh quality partial; incoming_rps không suy diễn từ completed responses. Dữ liệu này dùng kiểm tra chéo, chưa đưa vào CPU calibration.

## Preprocessing

```powershell
.\.venv\Scripts\python.exe -m cli.cluster preprocess --input data/imported/first-a/collector/metrics.csv --output data/imported/first-a/processed
.\.venv\Scripts\python.exe -m cli.cluster normalize-locust --input data/runs/first-a/load/client/requests.csv --workload-metadata data/runs/first-a/load/client/workload.json --output data/runs/first-a/client-common.csv
```

Preprocessor chỉ ghép application với **pod cùng tên/namespace/run/source/profile**, không ghép host hoặc node CPU. Dùng resource timestamp gần nhất **không ở tương lai** so với app window; mặc định lệch tối đa 20s, age tại collector từ −2 đến 30s để phát hiện clock skew. Mỗi resource timestamp dùng một lần, tránh lặp cache metrics-server thành nhiều quan sát độc lập. Không interpolation hoặc zero fill. Cửa sổ warmup, mất latency events, thiếu resource, stale hoặc duplicate bị loại và ghi quality.json.

Cần NTP/clock đồng bộ trên Windows/Ubuntu/VM. CPU smoothed window và app interval chỉ được căn chỉnh thăm dò, chưa phải sampling đồng bộ tuyệt đối. Chưa tổng hợp nhiều pod/replica thành capacity cả cluster; mô hình G hiện phục vụ sample app một pod.

## Calibration

```powershell
.\.venv\Scripts\python.exe -m cli.cluster calibrate --input data/imported/first-a/collector/metrics.csv --output data/imported/first-a/calibration
```

Mặc định chỉ real/live; cần ít nhất ba aligned windows, fit cần ba mức tải khác nhau. Không gộp các work CPU/memory settings hoặc pod limits khác nhau. Report JSON/Markdown lưu số mẫu/loại trừ, input SHA-256, load range, hệ số/intercept/R²:

- CPU cores theo completed req/s; nếu slope dương/R² đủ, ngoại suy theo CPU limit được ghi riêng là **ước tính**, không phải capacity đã chứng minh.
- Working-set MB (bytes/1e6) theo incoming req/s; tương quan mô tả, không suy ra RAM/request trong queue.
- Server latency mean theo incoming req/s; không dùng trực tiếp làm base_latency simulator vì simulator đã cộng service time.
- Capacity: max healthy completed RPS là **observed lower bound** nếu chưa bão hòa. Không có overload → onset null/not observed.
- Ngưỡng overload thăm dò: CPU pod ≥85% limit hoặc outcome error ≥1%; không chứng minh nguyên nhân hay steady state, không tự tăng tải để buộc chạm ngưỡng.

Profile mặc định 1→3→6→1 user, 120s, thường chỉ đủ baseline an toàn và chưa bão hòa. Muốn tăng user/thời lượng, copy profile, giám sát host/VM trước, giữ max 16 users, tổng ≤600s, spike ≤30s, spawn ≤2/s, think-time ≥0,5s. Guard dừng khi có ≥20 response và lỗi >10% hoặc latency mean >1000ms trong ba tick liên tiếp. Thời hạn subprocess kết thúc nếu Locust không tự dừng. Đây không phải cam kết chống treo host; Ctrl+C nếu host CPU/RAM/IO xấu đi.

## Cấu hình đề xuất A — không tự áp dụng

Chỉ khi đã có ≥6 real/live windows, nhiều mức tải và overload quan sát, có thể yêu cầu tệp **mới**:

```powershell
.\.venv\Scripts\python.exe -m cli.cluster calibrate --input data/imported/first-a/collector/metrics.csv --output data/imported/first-a/calibration-reviewed --write-candidate configs/integration/simulation-A.candidate.json
```

Tool chỉ đề xuất **A.capacity** bằng floor của lower bound đã quan sát, không sửa simulator config gốc. `.provenance.json` cạnh candidate ghi toàn bộ hạn chế/giả định. Các trường CPU/RAM/base latency/queue của A chưa xác định vẫn giữ nguyên và được liệt kê; B/C giữ nguyên từng giá trị, **vẫn là giả định mô phỏng**. Nếu CPU/RAM giả định cũ sẽ chặn capacity đề xuất, tool từ chối và yêu cầu review mapping, không đoán resource mới. Không overwrite candidate đã có hoặc config gốc.

Đây là ứng viên kiểm tra thủ công cho **budget sample pod**, chưa đồng nghĩa năng lực toàn Cluster A. Không dùng ngay để tuyên bố đã calibrated thật, không train lại MARL trong G. Fixture `--allow-simulated` chỉ sinh report demo, không được xuất candidate real.
