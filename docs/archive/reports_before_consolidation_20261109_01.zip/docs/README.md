# Tìm tài liệu theo công việc

| Công việc | Tài liệu |
|---|---|
| Tìm mã, kết quả và lệnh chạy | [project-layout.md](project-layout.md) |
| Cài và chạy trên Windows | [windows-setup.md](windows-setup.md) |
| Lệnh Windows/Ubuntu/VM K3s và thu metrics | [real-cluster-integration.md](real-cluster-integration.md) |
| Kiểm tra mạng, triển khai/gỡ ứng dụng mẫu | [k3s-deployment.md](k3s-deployment.md) |
| Schema và calibration | [metrics-calibration.md](metrics-calibration.md) |
| Simulator và API | [architecture.md](architecture.md), [api.md](api.md) |
| MARL, reward và thí nghiệm | [marl.md](marl.md), [experiments.md](experiments.md) |
| Bàn giao và kiểm chứng A–F | [af-delivery.md](reports/af-delivery.md), [af-validation.md](reports/af-validation.md) |
| Bàn giao G và audit mô hình | [stage-g.md](reports/stage-g.md), [stage-g-audit.md](reports/stage-g-audit.md) |
| Những thay đổi khi dọn | [cleanup.md](reports/cleanup.md) |

Kết quả A–F là simulation. Fixture và localhost chưa chứng minh đã kết nối Cluster A thật.
