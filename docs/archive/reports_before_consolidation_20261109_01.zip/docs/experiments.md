# Thí nghiệm A → E và tái lập

## Mô hình và workload

Trace hỗn hợp 180 giây: Stable 45 giây (90 req/s), Ramp-up 45 giây tuyến tính (90 → 190), Spike 45 giây (350), Recovery 45 giây (180), jitter ±15%. Năng lực chuẩn A/B/C 60/90/120 req/s, có giới hạn CPU/RAM. Mọi phương pháp dùng chung `SimulationSession.step` và công thức metric.

Mỗi scenario/seed tạo một workload duy nhất, truyền cho ba phương pháp trên trạng thái cluster mới. Service xác định; RNG policy không ảnh hưởng workload hoặc training. Metadata ghi config thực và hash incoming/checkpoint.

## Seed split trước testing

| Tập | Seed mặc định | Vai trò |
|---|---|---|
| Baseline phát triển | 42–46 | Kiểm tra A+B |
| Policy RNG/khởi tạo | 7 | Training initialization và lấy mẫu |
| Training workload | 1000–1299 | 300 episode, trace mới mỗi episode |
| Validation | 20001, 20002, 20003 | Chọn checkpoint và kiểm tra config trước testing |
| Testing | 30001–30005 | So sánh cuối, không tune hoặc chọn checkpoint |

Evaluator từ chối testing seed trùng policy seed, training range hoặc validation. Resume cập nhật metadata best checkpoint về toàn bộ training seed range kế hoạch, giữ nguyên trọng số đã chọn. Năm testing workload seed không đồng nghĩa năm training seed độc lập; bản này có một policy training seed chính.

Các pilot thay inference/action_step được lưu nguyên byte trong `data/archive/af-experiments.zip`, quyết định bằng validation trước khi chạy testing. Config bàn giao `action_step=0.03`, inference lấy mẫu với RNG cố định, cô lập khỏi RNG training. Không chọn inference mode bằng testing.

## Scenario testing

- `mixed`: bốn pha giống thiết kế training, seed mới.
- `stable`, `ramp_up`, `spike`: chạy riêng phase tương ứng.
- `recovery`: Spike rồi Recovery để có backlog trước lúc hồi phục.

Năm scenario × năm testing seed × ba phương pháp = 75 run. Tài nguyên và trace giống nhau trong mỗi cặp scenario/seed. Tổng hợp riêng từng scenario, không gộp các thời lượng khác nhau thành một mẫu để che khác biệt.

```powershell
.\.venv\Scripts\python.exe -m cli.evaluate
.\.venv\Scripts\python.exe -m cli.evaluate --scenarios spike --output results/test_spike
```

## Metric và thống kê

Throughput = completed/duration; error = dropped/incoming ×100%. Mean/p95 latency tính trên request hoàn tất trong từng run rồi tổng hợp giữa seed; không dùng p95 của mean theo giây hoặc mean p95 cluster. CPU/RAM trung bình đều theo cluster/time; RAM tick là đỉnh trước service. Imbalance là std dân số của (processed+queue_after)/capacity giữa cluster rồi trung bình theo thời gian. Luôn báo completed, dropped và waiting cuối.

`comparison.csv` lưu mean và sample std (ddof=1), cùng `_n` cho số mẫu hợp lệ; một run std=0 theo quy ước. `paired_differences.csv` lưu MARL − từng baseline trên đúng scenario/seed. Thanh sai số là std, không phải confidence interval. Không coi từng request là thí nghiệm độc lập; không tuyên bố ý nghĩa thống kê trong bản này.

Time-series dùng seed đầu và scenario mixed; comparison dùng mọi testing seed cho mixed; scenario_comparison hiển thị cả năm scenario. Mọi hình vẽ từ CSV thực chạy, không hardcode số.

## Tái lập

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m cli.pipeline --output results/reproduced
```

Tests kiểm tra resume khớp từng tensor/log với train liên tục và evaluation CSV khớp byte khi lặp. Metadata timestamp/thời gian khác nhau; PNG có thể khác byte do font/Matplotlib. Best có thể là episode 0 nếu không cải thiện, last vẫn lưu trọng số cập nhật; đọc checkpoint_episode thay vì giả định hội tụ.

## Dữ liệu cũ và hạn chế

Giữ nguyên `legacy/output/*.csv`: workload gốc seed 42 có 36.352 request, bản mới 34.123 do sửa Ramp-up. Latency mới khác proxy gốc; README có replay và plot legacy, không tạo p95 giả.

Arrival theo batch đầu giây, capacity cố định, tài nguyên đồng nhất/request, không mô phỏng pod scheduling hay lỗi ứng dụng/mạng. Không drain queue cuối run; latency không gồm dropped/waiting nên chịu censoring. Chưa hiệu chỉnh hạ tầng thật, không suy diễn hiệu năng OpenStack/AWS. Xem throughput, latency, drop, imbalance đồng thời; reward không thay thế metric.
