# Khung lý thuyết cho Chương 1

Đây là khung ý chính cho đồ án; **tài liệu tham khảo cần người dùng bổ sung và kiểm chứng** trước khi đưa vào luận văn. Các liên kết dưới đây là nguồn gốc để đối chiếu, không phải danh mục trích dẫn hoàn thiện.

## Multi-Cluster và Hybrid Cloud

Multi-cluster phân bố ứng dụng trên các cụm có CPU/RAM, điều kiện mạng và miền lỗi khác nhau. Hybrid cloud phối hợp môi trường riêng và công cộng; mô hình ba cụm trong đồ án chưa chứng minh triển khai hybrid thật. Cluster A là nguồn calibration lịch sử, B/C hiện giả lập. Quyết định placement liên cụm ở tầng trên không đồng nhất với quyết định pod→node trong một cluster.

## Microservice DAG và phương pháp lập lịch

DAG biểu diễn dependency và payload trên cạnh. Fork-join có nhánh song song nên critical path lấy max tại join; workflow ID là đơn vị SLA, khác số lần gọi service. Scheduler phải cân đối contention CPU/RAM với chi phí truyền cạnh qua WAN.

Heuristic như RR/LL dễ giải thích nhưng chưa tối ưu đồng thời mọi mục tiêu. Heuristic traffic-aware khai thác cạnh dữ liệu và mạng. GA có thể tìm placement tổ hợp với nhiều mục tiêu nhưng chịu chi phí tính và cần định nghĩa feasibility. Kubernetes scheduler thực hiện filtering rồi scoring node cho pod trong cluster; không tự coi nó là optimizer DAG đa cụm. [Kubernetes Scheduling Framework và scheduler](https://kubernetes.io/docs/concepts/scheduling-eviction/kube-scheduler/) mô tả phạm vi này. Baseline K8s-default-like, GA và Single-Agent RL để Task 5 với cùng trace, constraints và budget.

## RL, MDP, MARL và CTDE

MDP gồm state, action, transition, reward và horizon/discount; actor nhìn observation cục bộ nên bài toán triển khai phù hợp hơn với cooperative partially observed setting. Mỗi service là một agent; action KEEP/PLACE/MOVE chịu mask. Environment nắm global state, tải nền và fault; actor chỉ thấy service, cụm và DAG lân cận. Padding không phải agent thật, không vào inference/loss. Mask invalid action phải áp dụng cả sampling và training sau này.

CTDE cho phép critic dùng global state khi train, actor dùng observation cục bộ khi thực thi. V1 actor đã thấy toàn bộ 123 feature nên chưa thực hiện tách này. V2 tạo schema riêng; có global_state không tự chứng minh thuật toán CTDE đã được huấn luyện hoặc hội tụ.

## MAPPO, MADDPG, QMIX và hướng chọn

MAPPO dùng PPO cho hợp tác đa tác tử, có centralized value function, phù hợp action categorical bị mask và chia sẻ tham số theo service/role ID. Đây là ứng viên Task 4, cần thí nghiệm riêng về credit assignment, reward, entropy, clipping và generalization; chưa có kết quả MAPPO trong Task 3. Nguồn đối chiếu: [The Surprising Effectiveness of PPO in Cooperative Multi-Agent Games](https://arxiv.org/abs/2103.01955).

MADDPG dùng critic có thông tin tác tử khác để giảm vấn đề môi trường không dừng; thường thuận tiện với action liên tục. Với bốn action rời rạc của đồ án cần nêu rõ biến thể/ước lượng action trước khi so sánh. Nguồn: [Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments](https://arxiv.org/abs/1706.02275).

QMIX phân rã giá trị chung bằng mixing đơn điệu để lựa chọn action phân tán; ràng buộc đơn điệu có thể giới hạn biểu diễn tương tác placement/traffic. Nguồn: [QMIX: Monotonic Value Function Factorisation for Deep Multi-Agent Reinforcement Learning](https://arxiv.org/abs/1803.11485).

Lý do ưu tiên MAPPO là sự phù hợp sơ bộ với cooperative categorical policies và schema actor/critic tách biệt, không phải kết luận nó tốt hơn các thuật toán khác. Task 4 mới huấn luyện CTDE/reward đa mục tiêu; nhiều controlled DAG đồng thời cần mở rộng entity/ID/credit assignment. Task 5 mới nghiệm thu baseline và đánh giá ngoài mẫu.
