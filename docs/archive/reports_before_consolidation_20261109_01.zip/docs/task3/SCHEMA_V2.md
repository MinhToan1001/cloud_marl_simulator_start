# Schema placement-v2 cho CTDE

Actor observation có 91 feature/agent, padding thành `(5,91)`. Critic global_state có 195 feature. Dtype float32, số chiều cố định. Schema hash: `934b66378221ba50d0347189ca27a135d2139127257da8e5d4edd329f6de45dd`. Danh sách thứ tự, đơn vị và scale đầy đủ ở [schema_v2.json](schema_v2.json), bản đóng băng theo run ở [contract](../../results/task3/dag_v2_20261109_05/smoke/contract.json).

Actor nhận trạng thái của chính service, CPU/RAM/capacity/availability toàn cụm, vị trí và payload cạnh của các láng giềng trực tiếp, tóm tắt outgoing RTT/bandwidth. Không nhận chi tiết service không kề. Critic nhận mọi service, mọi cạnh DAG, tài nguyên cụm, ma trận mạng đầy đủ và giá. Global_state không tiết lộ trace tương lai; summary queue chưa đủ mô tả mọi job residual nên chưa khẳng định vector là Markov đầy đủ. Task 4 cần đánh giá lịch sử quan sát/recurrent policy nếu cần.

Service role ID là vị trí topo ổn định trong DAG, chuẩn hóa `(index+1)/5`, kèm metadata tên service trong DAG. ID không chứng minh vai trò cùng ngữ nghĩa giữa các DAG; Task 4 có thể mở rộng role embedding có version.

`agent_mask` bật khi DAG đã đến và slot là service thật. `decision_mask` chỉ bật cho UNPLACED/READY có ít nhất một action hợp lệ. Padding trước/sau MAX_SERVICES và PREPARING/MIGRATING/PENDING/REJECTED không vào inference, action_mask toàn false, không gửi action. `obs` padding là zero. Busy service thật vẫn giữ reservation theo lifecycle; padding không có workload hay reservation.

Action 0 KEEP, 1/2/3 là chọn A/B/C. UNPLACED chọn cụm được log PLACE; đã đặt chọn cụm khác được log MOVE. UNPLACED không có KEEP; cụm hiện tại không có MOVE-to-self. READY có KEEP ngay cả khi cluster đang lỗi để giữ placement logic; việc request có được phục vụ vẫn xét endpoint. Không có WAIT. Đề xuất đồng thời được kiểm tra lại theo topo; bị xung đột headroom thì log proposal_rejected, không tự thực hiện action không hợp lệ.

Feature ratio không clip ở 1: overload vẫn hiện tỷ lệ >1 và có flag. Scale là phép chia ghi trong manifest, không tự suy từ batch. Bandwidth None mã hóa 0, critic có unlimited flag; actor chỉ có bandwidth trung bình, 0 không phân biệt zero/unlimited nên adapter live phải bỏ/proxy có missing semantics trước khi huấn luyện. Đây là giới hạn được công khai của tóm tắt actor.

`save_contract/load_contract` lưu schema đầy đủ và hash từng source file V2; version/hash/code mismatch đều bị từ chối. Artifact V1 (checkpoint torch placement-v1) không được V2 nạp; loader V1 cũng từ chối contract V2. Contract chỉ là giao kèo metadata chuẩn bị Task 4, chưa có V2 trained policy. Đổi schema/code phải version lại và tạo run mới; không dùng checkpoint V1 với action/obs V2.
