# Báo cáo Simulator DAG V2

Run nghiệm thu: [results/task3/dag_v2_20261109_05](../../results/task3/dag_v2_20261109_05/REPORT.md). **206 test đạt**, gồm 156 test cũ và 50 test V2; 192 episode smoke SIMULATED. Không huấn luyện MAPPO/IPPO trong Task 3, không đổi hạ tầng. Task 2B chưa nghiệm thu đầy đủ do A4 PENDING (Cluster A đã phục hồi theo kiểm tra thủ công, còn thiếu bằng chứng); phần B hoàn thành độc lập với A4/A5.

| Heuristic | E2E mean (s) | Traffic (bytes) | CPU std | RAM std | SLA resolved |
|---|---:|---:|---:|---:|---:|
| round_robin | 0.155548 | 907517.637524 | 0.077804 | 0.043405 | 0.110382 |
| least_loaded | 0.155328 | 829204.444723 | 0.077635 | 0.048195 | 0.111551 |
| random_valid | 0.148128 | 585833.596456 | 0.077669 | 0.069636 | 0.110956 |
| traffic_aware | 0.143273 | 580864.000000 | 0.077476 | 0.061574 | 0.111641 |


Đây là trung bình 48 episode mỗi heuristic, không phải benchmark MARL hoặc Task 5. Traffic-aware giảm traffic và E2E trong bộ smoke này nhưng RAM std cao hơn RR; SLA không đồng thời tốt hơn mọi cách. Không chọn policy bằng các seed test cũ. Seed mới 51001/51002; bốn DAG × sáu scenario dùng trace chung theo scenario/seed. Latency completed-only phải đọc cùng thất bại/censored.

Tổng trên mọi episode: arrivals=13568, completed=13185, failed=380, unfinished=3, service invocations=49306. Đây là tổng qua nhiều episode độc lập, không phải duy nhất request thật. Mỗi episode có assert workflow conservation và invocation conservation; ledger liên kết bằng workflow ID. Không lấy tổng service calls làm tổng workflow arrivals.

## Chức năng đã xây dựng

Module mới `src/placement_v2/` có DAG tối đa năm service, bốn template, initial topo placement, DAG đến giữa episode khi cụm có tải nền, PENDING/retry/REJECTED, KEEP/PLACE/MOVE, prepare/grace/drain/rollback/cooldown. Workflow admission dùng endpoint Ready và dependency, không chặn theo nhãn MIGRATING. Mỗi request tới ứng dụng không tạo deployment mới.

Event engine tính fork-join max, CPU fair sharing/queue, RAM pressure, link RTT/bandwidth contention và bytes/cost riêng. Capacity randomization có điều kiện initial feasibility; capacity fault log tường minh; overload giữ workload/raw ratios, chặn inbound, cho MOVE out. Workflow timeout/failure/cancellation và censored được báo riêng. Schema actor/critic cố định, masks/padding và loader fingerprint là giao kèo Task 4.

## Bằng chứng và giới hạn

[Mô hình toán](MATH_MODEL.md), [schema](SCHEMA_V2.md), [feasibility từng feature](SCHEMA_REAL_FEASIBILITY.csv), [validation](VALIDATION_REPORT.md), [lý thuyết](THEORY_NOTES.md). Mỗi run có config/provenance, profile hash, code/schema fingerprints, runtime freeze, trace seed/hash, decision/event/resource/workflow/invocation ledgers và JUnit. Hai runtime được ghi riêng: .venv-task2 chạy smoke; .venv đầy đủ chạy regression API/Gymnasium. Không cài thêm hay thay package của runtime cũ.

Profile V1 chỉ low-load, CPU relative MAE 60,86%, saturation null. Các node DAG dùng cùng Sample API class proxy, không phải calibration từng microservice. Capacity/queues/RAM pressure/WAN/prices/background/readiness đều là giả định chưa xác minh miền. Một DAG/episode, không optional branch/async/retry, không state-transfer traffic của migration, không OOM-kill, không MARL training. Reward tham chiếu dùng thống kê lũy kế; actor network summary có giới hạn ghi trong schema. Hạ tầng thật chưa sẵn sàng closed loop.

Task 4: MAPPO CTDE, masked rollout/loss, reward và credit assignment, huấn luyện ngoài mẫu; nhiều DAG đồng thời nếu cần phải mở rộng entity schema. Task 5: GA, Single-Agent RL, K8s-default-like với cùng constraints và budget. A5 là lượt thử tải riêng sau phê duyệt đúng file/mức RPS.
