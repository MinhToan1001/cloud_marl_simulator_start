# Kiểm thử và tái hiện V2

**206/206 test đạt**, không failure/error. Bộ cũ 156 test vẫn đạt; thêm 50 test V2. [JUnit](../../results/task3/dag_v2_20261109_05/validation/junit.xml), [console](../../results/task3/dag_v2_20261109_05/validation/pytest.txt), [status/fingerprints](../../results/task3/dag_v2_20261109_05/validation/status.json). Kiểm thử cũ có fixture huấn luyện nhỏ trong tmp như trước; không huấn luyện lại checkpoint nghiên cứu.

| Nhóm nghiệm thu | Bằng chứng trong tests/test_placement_v2.py |
|---|---|
| DAG, cycle, >5, DAG thứ hai | test_dag_bounds_cycle_and_second |
| Critical path 4 template × 3 mạng | test_exact_critical_path; test_diamond_max_not_sum |
| CPU/queue monotonic, hai chiều placement | test_contention_and_both_placement_directions; test_queue_monotonic_same_trace |
| Bandwidth và contention link | test_bandwidth_delay_and_shared_link |
| Initial topo, mid-episode, masks/padding | test_mid_episode_topo_and_masks; test_all_unplaced_keep_blocked_and_masks_reject_bad_input |
| PENDING/retry/REJECTED | test_pending_reject_and_workflow_error |
| PREPARING/GRACE vẫn phục vụ | test_migration_serves_during_preparing_and_grace; test_target_serves_after_source_loss_in_grace |
| Rollback và drain nguồn | test_migration_rollback_and_source_ready; test_slow_workflow_source_held_until_drained |
| Faults, overload, giữ raw usage, MOVE out | test_fault_conservation; test_ram_capacity_fault_no_silent_eviction |
| Workflow ID, dependency, terminal/SLA một lần | test_dependency_and_completed_workflow_no_duplicate; test_join_fail_once_and_timeout_censor |
| Queue/RAM/link-zero/cluster lỗi | test_explicit_failures_or_censored |
| Trace reproducibility/ranges/capacity feasibility | test_randomization_range_seed_and_capacity_initial; test_initial_capacity_conditional_sample; test_scenario_trace |
| Actor local/critic global, V1↔V2/fingerprint rejection | test_schema_local_global_loader |
| Policy reproducibility | test_policies_reproducible_shared_trace |

Smoke 192 episode SIMULATED dùng 12 shared traces, bốn policy chỉ là heuristics. Conservation được assert sau từng event advance và cuối episode; tổng arrivals/completed/failed/unfinished và số invocation tách riêng. Không tune theo test 30001–30005. [Thông số/freeze/trace](../../results/task3/dag_v2_20261109_05/smoke/metadata.json).

Tái hiện từ workspace (thư mục output phải mới):

```powershell
.\.venv-task2\Scripts\python.exe -X utf8 -m cli.task3 --output results/task3/<run_moi> --test-python .venv/Scripts/python.exe
.\.venv-task2\Scripts\python.exe -X utf8 -m pytest tests/test_placement_v2.py -q
```

CLI `--stage smoke`/`--stage validate` tạo stage tương ứng mới và từ chối ghi đè; `all` từ chối root đã tồn tại. `.venv-task2` không có FastAPI/PyYAML/Gymnasium nên regression dùng `.venv` đã có đủ package. Run _01 dừng ở serialize numpy, _02 dừng vì alias ramp-up, _03 smoke đủ nhưng collection regression thiếu package; giữ nguyên các bằng chứng thử đó. Run dag_v2_20261109_05 là kết quả cần đọc. Nếu sửa code/schema, tạo run mới để fingerprint khớp, không sửa artifacts đã đóng băng.

Đối chiếu độc lập sau chạy: [artifact_verification.json](../../results/task3/dag_v2_20261109_05/artifact_verification.json) xác nhận conservation theo từng workflow ID, invocation không trùng (workflow,service), shared trace/hash và 286 feature rows; 232 file được bảo vệ không đổi. Bốn lệnh CLI ghi lại trong [nonoverwrite_checks.json](../../results/task3/dag_v2_20261109_05/nonoverwrite_checks.json) đều từ chối stage đã tồn tại. Run _04 đạt 204 test trước hai test hồi quy cuối; run _05 mới là bản nghiệm thu 206 test.
