# Khả năng đo từng feature V2

Cluster A đã Ready và SSH thành công theo kiểm tra thủ công của người dùng (REAL / USER_REPORTED_MANUAL), chưa được agent xác minh độc lập. **A4 PENDING** vì thiếu snapshot UTC, owner chain/inventory requests/limits toàn cụm, raw Metrics API và shadow replay mới; không kết luận Cluster A offline. Workload calibration Running là kết quả ở lần kiểm tra trước. closed_loop_ready=false vì checklist chưa đủ và B/C chưa có hạ tầng thật. Xem [H6](../task2/H6_CLOSEOUT_REPORT.md).

CSV [SCHEMA_REAL_FEASIBILITY.csv](SCHEMA_REAL_FEASIBILITY.csv) có 286 hàng, một hàng cho **mỗi feature có thứ tự ở mỗi scope**, bao gồm nguồn, đơn vị, scale, trạng thái archive/live và phương án khi thiếu. Không gắn REAL cho số giả lập.

Tham chiếu archive H5: [archived_packets.json](../../results/task2/placement_v1_20261109_03/shadow/archived_packets.json), [readiness.json](../../results/task2/placement_v1_20261109_03/shadow/readiness.json), dữ liệu gốc [cluster-a-real-003](../../data/runs/cluster-a-real-003/). CPU/RAM node/pod lịch sử có đơn vị/window, không phải telemetry hôm nay. Archive thiếu full cluster reservations, Deployment identity và ownerReferences, queue length và WAN bandwidth chưa đo được. Không thay archive cho A4 fresh.

Queue length cần gauge ở app/Prometheus hoặc bỏ khỏi actor live. DAG dependency/bytes cần cấu hình có version và distributed tracing theo workflow ID. WAN/bandwidth cần kế hoạch đo riêng; ở lượt này không tự probe/thử tải. Readiness phục vụ cần EndpointSlice/Pod Ready + cluster availability/health, độc lập trạng thái migration. Derived overload/OOM flag phụ thuộc đủ usage/capacity/inventory; thiếu dữ liệu thì fail closed cho PLACE/MOVE.

Đây là khảo sát feasibility, chưa có adapter V2 operational. Kết quả schema parity và smoke không chứng minh real readiness. A4 chỉ được DONE sau đủ snapshot REAL UTC, owner chain, inventory requests/limits toàn cụm, Metrics API và shadow replay V1 với dữ liệu tươi.
