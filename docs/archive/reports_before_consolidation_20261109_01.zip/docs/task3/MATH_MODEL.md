# Mô hình toán học DAG V2

Simulator V2 mô hình hóa bốn mục tiêu của đề cương trong một episode có tối đa một controlled DAG và năm service. Toàn bộ episode là **SIMULATED**. Calibration V1 cung cấp tham chiếu low-load cho lớp Sample API; các service DAG, B/C và WAN là giả định. Đây là mô hình chuẩn bị Task 4, chưa phải controller đa cụm thực.

## Hạ tầng, ứng dụng và trạng thái

Tập cụm C={A,B,C}, năng lực CPU Kᶜ (core), RAM Mᶜ (byte), ma trận RTT Lᵢⱼ (giây), bandwidth Bᵢⱼ (byte/giây), trọng số pᵢⱼ (cost/byte). `None` biểu diễn bandwidth vô hạn, 0 biểu diễn link không truyền dữ liệu. Các liên kết có hướng và chia sẻ bandwidth giữa các transfer hoạt động; jitter thay đổi từng giây theo trace đã lưu.

Workflow G=(V,E) là DAG. Service v có CPU request rᵥ, RAM request mᵥ, CPU limit ℓᵥ, work wᵥ (core-second), concurrency và queue limit. Cạnh (u,v) có dᵤᵥ byte/workflow. Mỗi service được gọi đúng một lần cho một workflow ID; mặc định gọi đồng bộ fork-join, mọi nhánh bắt buộc, lỗi là fail-fast và hủy công việc còn lại. Không retry request ngầm. DAG/cạnh/payload/concurrency/deadline cấu hình được qua dataclass; lựa chọn async/optional-branch chưa thuộc phiên bản này.

Một service có một placement logic xᵥᶜ∈{0,1}, Σᶜxᵥᶜ=1 khi READY. Trong migration, nguồn và đích cùng giữ reservation trong khoảng overlap, nhưng workflow pin endpoint theo ID và mỗi invocation chỉ chạy một lần. Trước triển khai có UNPLACED/PENDING, sau từ chối có REJECTED nên chưa có placement; không ép ràng buộc một cụm cho những trạng thái này.

Initial PLACE theo topo: service chỉ được đặt sau khi tiền nhiệm đã có endpoint được cấp phát. Node chưa đủ điều kiện tự vào PENDING, mỗi decision tick thử lại; quá số retry hoặc timeout thì REJECTED. PREPARING là chờ endpoint Ready. MOVE là PREPARING → GRACE → READY, có cooldown, giới hạn số lần và số MOVE đồng thời; rollback khi target mất khả dụng hoặc prepare timeout. Release nguồn đợi hết grace và mọi invocation/transfer đã pin nguồn được drain.

**Lifecycle không phải readiness phục vụ.** PREPARING khi migration vẫn có thể phục vụ ở nguồn; GRACE phục vụ được ở đích hoặc nguồn còn Ready. Endpoint hợp lệ cần Ready, cluster available và service health. Workflow được admit khi mọi service bắt buộc có endpoint phục vụ hợp lệ; node chỉ enqueue sau khi dependency của chính workflow đó hoàn tất. Thiếu endpoint thì queue có giới hạn/timeout; REJECTED gây lỗi workflow. Mất cluster khi job đã pin đang chạy gây fail-fast, không chuyển job sang endpoint khác hoặc đếm invocation mới ngầm. Transfer đợi link/endpoint phục hồi hoặc workflow timeout.

## Thời gian và contention

Không tranh chấp:

`finish(v) = max_{u∈pred(v)}[finish(u)+transfer(u,v)] + queue(v) + service(v)`.

`transfer(u,v) = L[x(u),x(v)] + d_uv/B[x(u),x(v)]` khi khác cụm; cùng cụm dùng `intra_latency_s`, không tính WAN bytes. `service(v)=w_v/min(ℓ_v,CPU khả dụng)` trong trường hợp đơn lẻ. E2E = thời điểm mọi sink hoàn tất − workflow arrival. Max ở join tránh cộng hai nhánh song song. Thời gian triển khai/readiness chỉ đi vào E2E nếu request phải đợi deployment; không cộng lại latency đã tích phân.

Trong simulator, background CPU là tải ngoại sinh tuyệt đối. CPU còn lại `max(0,K-background)` được water-fill công bằng cho các invocation hoạt động, có CPU limit mỗi endpoint chia đều cho invocation cùng service. Concurrency giới hạn queue riêng theo endpoint. Giảm capacity hoặc tăng background khiến service rate giảm, queue có thể tăng. Hàm critical_path chỉ là cận không tranh chấp; event engine tính thời gian thực với queue và chia sẻ CPU.

Transfer chịu RTT một lần, sau đó mỗi flow được B/n khi có n flow cùng link có hướng đã hết RTT. Byte được ghi đúng khi truyền, có thể chỉ truyền một phần trước lỗi/timeout. Hai chiều link độc lập. CPU và mạng có thể chạy song song; không cộng thời gian transfer hai lần. Đặt chung có thể chậm hơn vì contention, tách cụm có thể chậm hơn vì WAN; không có placement luôn thắng.

## Capacity và fault

Capacity CPU/RAM ban đầu được lấy mẫu có điều kiện trong dải cấu hình sao cho capacity ≥ reservation ban đầu. Nếu không có giá trị khả thi trong dải thì báo lỗi. Initial placement do trace ngoài cung cấp cũng phải qua kiểm tra. Khởi tạo trống trong smoke nên điều kiện này tự thỏa mãn. Capacity không giảm ngẫu nhiên giữa episode; thay đổi chỉ qua fault tường minh có log. Background CPU có thể đổi từng giây, RAM nền cố định theo trace.

Reservation tính cả endpoint đích đang chuẩn bị và nguồn chưa release. Usage CPU, RAM, reservation và tỷ lệ thô không bị ép về 1. Khi vượt capacity, gắn OVERLOADED, chặn PLACE/MOVE vào cụm, vẫn cho MOVE ra. Không xóa workload hay eviction ngầm. CPU throttling là chia sẻ phần CPU khả dụng kể trên. RAM usage = background RAM + baseline các endpoint + memory mỗi invocation queued/running. Khi RAM/capacity=q>1, progress rate chia cho `1 + ram_latency_penalty×(q−1)`; invocation mới bắt đầu có xác suất lỗi `min(.95, ram_error_coefficient×(q−1))`, dùng hash(seed, workflow ID, service) cố định thay vì RNG phụ thuộc policy. `oom_risk` là cờ q>1; không mô phỏng OOM-kill/eviction. Việc RAM lỗi/timeout gây lỗi workflow và được ghi loại lỗi. Các cơ chế này là ASSUMPTION, chưa kiểm chứng thực tế.

## Bốn mục tiêu và conservation

- E2E mean/p95/p99 chỉ trên workflow completed; kèm số mẫu, failed và unfinished, không diễn giải 0 khi không có mẫu là latency tốt.
- Traffic bytes = tổng byte thực đã qua cạnh khác cụm; traffic cost = Σ bytesᵢⱼ×pᵢⱼ. Byte từng link được giữ riêng. Migration state transfer không nằm trong DAG traffic; chi phí đó chưa được hiệu chuẩn.
- Load balance = trung bình theo thời gian của std giữa ba cụm, riêng CPU usage/capacity và RAM usage/capacity; báo thêm reservation std, utilization, waste = trung bình phần dương reservation ratio − usage ratio từng tài nguyên/cụm/thời điểm. Usage có cả background; waste là proxy toàn cụm, không phải chi phí cấp phát thực tế.
- SLA violation resolved = (workflow completed quá deadline + workflow failed)/(completed+failed). Failure là violation ngay cả khi chưa quá deadline; unfinished báo censored riêng, không tự kết luận thành công. Khi resolved=0 trả 0 kèm denominator/censored; phải đọc cùng counts.

Reward cấu hình bốn trọng số: `−[w1×E2E_mean/SLA + w2×Δtraffic_cost + w3×(CPU_std+RAM_std) + w4×SLA_resolved]`. Đây là reward tham chiếu dùng thống kê lũy kế, chưa tune/train; Task 4 cần xem lại credit assignment và reward theo interval. Constraint admission dựa trên `max(reservation,usage)+request≤capacity` và cluster availability, cooldown/readiness; các đề xuất đồng thời được kiểm tra lại theo topo để không vượt headroom.

Tại mọi thời điểm: `workflow_arrivals = completed + failed + unfinished`. `service_invocations = invocation_completed + invocation_failed + invocation_cancelled + invocation_live`. Workflow ID liên kết mọi nhánh, transfer, binding và terminal; completion/failure/SLA mỗi workflow chỉ ghi một lần. Không cộng số service calls để suy tổng workflow request. Error theo loại, queue delay, migration count/latency/downtime, OVERLOADED/PENDING ticks và thời gian được báo riêng.

## Tham số và miền hiệu lực

`smoke/parameter_provenance.json` liệt kê mọi tham số config với nguồn. Profile V1 low-load REAL đầu vào → CALIBRATED latency 5,5397 ms, RAM 32.378.368 byte; dùng latency×giả định 1 core làm work proxy 0,0055397 core-second và RAM baseline/reference request 32 MiB làm tỷ lệ proxy là ASSUMPTION khi nhân rộng DAG/B/C. Không dùng CPU OLS để suy causal demand hay capacity. CPU validation error 60,86%, saturation null, không có profile mới khi A5 chưa duyệt. Capacity budgets, queues, SLA, payload cạnh, dải randomization, giá mạng và RAM pressure đều chưa xác minh. Tất cả giá trị lấy mẫu lưu trong trace, không lấy seed test cũ để tune.
