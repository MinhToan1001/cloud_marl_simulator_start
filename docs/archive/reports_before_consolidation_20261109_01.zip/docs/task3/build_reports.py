"""Tạo báo cáo Markdown/CSV từ artifact có thật; từ chối ghi đè tài liệu đã có."""
import csv
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from placement.io import write_csv,write_json,file_hash
from placement_v2.schema import manifest,code_fingerprints

ROOT=Path(__file__).resolve().parents[2]
DOCS=Path(__file__).parent


def write(name,text):
    p=DOCS/name
    with p.open('x',encoding='utf-8') as f: f.write(text.rstrip()+'\n')


def main(run_id):
    run=ROOT/'results/task3'/run_id
    meta=json.loads((run/'smoke/metadata.json').read_text(encoding='utf-8'))
    validation=json.loads((run/'validation/status.json').read_text(encoding='utf-8'))
    assert validation['exit_code']==0 and meta['code_fingerprints']==code_fingerprints()
    tree=ET.parse(run/'validation/junit.xml'); suites=tree.getroot().findall('testsuite')
    count=sum(int(s.get('tests','0')) for s in suites)
    assert sum(int(s.get('failures','0'))+int(s.get('errors','0')) for s in suites)==0
    schema=manifest(); features=[]
    for scope,key in [('actor','actor_features'),('critic','critic_features')]:
        for index,f in enumerate(schema[key]):
            name=f['name']; source='Cấu hình/controller'; state='Chưa có adapter V2 live'; plan='Dùng cấu hình có version và đối chiếu identity'
            if any(x in name for x in ('cpu_capacity','ram_capacity','cpu_request','memory_request','cpu_limit')):
                source='Node allocatable; Pod resources.requests/limits, toàn bộ pod'
                state='Archive H5 chỉ selected pod/node; thiếu full inventory'; plan='Thu snapshot A4; trừ system/background reservations; fail closed khi thiếu'
            elif any(x in name for x in ('cpu_usage','ram_usage')):
                source='Metrics API node/pod, window timestamp'; state='Archive H5 có CPU/RAM A ở quá khứ'
                plan='Kiểm freshness/window và identity; B/C unavailable cho đến khi có metrics'
            elif 'reservation' in name:
                source='Kubernetes Pod list toàn cụm; init/sidecar/overhead đúng semantics'
                state='Archive H5 thiếu inventory toàn cụm'; plan='Không suy headroom từ selected pods; bỏ MOVE khi thiếu'
            elif any(x in name for x in ('overloaded','oom_risk')):
                source='Derived từ capacity/usage/reservations; Node conditions/OOM events bổ trợ'
                state='Chưa xác minh đầy đủ'; plan='Không dùng flag mô phỏng thay OOM thực; bổ sung telemetry'
            elif 'queue_length' in name:
                source='App /metrics hoặc Prometheus custom queue gauge'; state='Chưa đo được'
                plan='Bỏ khỏi actor live hoặc proxy in-flight có cờ missing; không gán 0 như đã đo'
            elif 'network.' in name:
                source='WAN RTT: probe có kiểm soát; bandwidth: đo active được duyệt/telemetry link; price: cấu hình'
                state='Chưa đo được liên cụm, B/C chưa tồn tại thật'
                plan='Bỏ khỏi actor live hoặc dùng prior/proxy gắn ASSUMPTION; không thực hiện probe/tải ở lượt này'
            elif 'bytes' in name:
                source='DAG/application config và distributed tracing bytes/workflow'
                state='Chưa có DAG app thật/tracing theo workflow ID'; plan='Cấu hình payload là ASSUMPTION cho đến khi instrument tracing'
            elif 'endpoint_ready' in name or 'has_ready_endpoint' in name or '.available' in name:
                source='Pod/EndpointSlice Ready, Node Ready, app health'; state='Archive H5 có selected pod Ready, chưa đủ service/Deployment mapping'
                plan='EndpointSlice và ownerReferences chain; đối chiếu app identity, không suy từ tên pod'
            elif '.active.' in name:
                source='Deployment → ReplicaSet → Pod ownerReferences và node→cluster mapping'
                state='Archive H5 đã scrub ownerReferences/Deployment'; plan='Thu identity tươi A4, không suy tên Deployment từ pod prefix'
            elif 'work' in name:
                source='CALIBRATED low-load latency V1 × giả định 1 core'
                state='Tham chiếu low-load lịch sử; không đo causal CPU demand'
                plan='Giữ proxy SIMULATED; fit lại ngoài mẫu sau A5 được duyệt'
            features.append({'scope':scope,'index':index,**f,'measurement_source':source,'archive_status':state,
                'A4_live_status':'PENDING — Cluster A phục hồi theo kiểm tra thủ công; feature chưa xác minh bằng snapshot mới',
                'B_C_status':'ASSUMPTION(SIMULATED)','missing_feature_plan':plan})
    write_csv(DOCS/'SCHEMA_REAL_FEASIBILITY.csv',features)
    write_json(DOCS/'schema_v2.json',schema)
    write('SCHEMA_V2.md',f'''# Schema placement-v2 cho CTDE

Actor observation có {len(schema['actor_features'])} feature/agent, padding thành `(5,{len(schema['actor_features'])})`. Critic global_state có {len(schema['critic_features'])} feature. Dtype float32, số chiều cố định. Schema hash: `{schema['schema_hash']}`. Danh sách thứ tự, đơn vị và scale đầy đủ ở [schema_v2.json](schema_v2.json), bản đóng băng theo run ở [contract](../../results/task3/{run_id}/smoke/contract.json).

Actor nhận trạng thái của chính service, CPU/RAM/capacity/availability toàn cụm, vị trí và payload cạnh của các láng giềng trực tiếp, tóm tắt outgoing RTT/bandwidth. Không nhận chi tiết service không kề. Critic nhận mọi service, mọi cạnh DAG, tài nguyên cụm, ma trận mạng đầy đủ và giá. Global_state không tiết lộ trace tương lai; summary queue chưa đủ mô tả mọi job residual nên chưa khẳng định vector là Markov đầy đủ. Task 4 cần đánh giá lịch sử quan sát/recurrent policy nếu cần.

Service role ID là vị trí topo ổn định trong DAG, chuẩn hóa `(index+1)/5`, kèm metadata tên service trong DAG. ID không chứng minh vai trò cùng ngữ nghĩa giữa các DAG; Task 4 có thể mở rộng role embedding có version.

`agent_mask` bật khi DAG đã đến và slot là service thật. `decision_mask` chỉ bật cho UNPLACED/READY có ít nhất một action hợp lệ. Padding trước/sau MAX_SERVICES và PREPARING/MIGRATING/PENDING/REJECTED không vào inference, action_mask toàn false, không gửi action. `obs` padding là zero. Busy service thật vẫn giữ reservation theo lifecycle; padding không có workload hay reservation.

Action 0 KEEP, 1/2/3 là chọn A/B/C. UNPLACED chọn cụm được log PLACE; đã đặt chọn cụm khác được log MOVE. UNPLACED không có KEEP; cụm hiện tại không có MOVE-to-self. READY có KEEP ngay cả khi cluster đang lỗi để giữ placement logic; việc request có được phục vụ vẫn xét endpoint. Không có WAIT. Đề xuất đồng thời được kiểm tra lại theo topo; bị xung đột headroom thì log proposal_rejected, không tự thực hiện action không hợp lệ.

Feature ratio không clip ở 1: overload vẫn hiện tỷ lệ >1 và có flag. Scale là phép chia ghi trong manifest, không tự suy từ batch. Bandwidth None mã hóa 0, critic có unlimited flag; actor chỉ có bandwidth trung bình, 0 không phân biệt zero/unlimited nên adapter live phải bỏ/proxy có missing semantics trước khi huấn luyện. Đây là giới hạn được công khai của tóm tắt actor.

`save_contract/load_contract` lưu schema đầy đủ và hash từng source file V2; version/hash/code mismatch đều bị từ chối. Artifact V1 (checkpoint torch placement-v1) không được V2 nạp; loader V1 cũng từ chối contract V2. Contract chỉ là giao kèo metadata chuẩn bị Task 4, chưa có V2 trained policy. Đổi schema/code phải version lại và tạo run mới; không dùng checkpoint V1 với action/obs V2.
''')
    write('SCHEMA_REAL_FEASIBILITY.md',f'''# Khả năng đo từng feature V2

Cluster A đã Ready và SSH thành công theo kiểm tra thủ công của người dùng (REAL / USER_REPORTED_MANUAL), chưa được agent xác minh độc lập. **A4 PENDING** vì thiếu snapshot UTC, owner chain/inventory requests/limits toàn cụm, raw Metrics API và shadow replay mới; không kết luận Cluster A offline. Workload calibration Running là kết quả ở lần kiểm tra trước. closed_loop_ready=false vì checklist chưa đủ và B/C chưa có hạ tầng thật. Xem [H6](../task2/H6_CLOSEOUT_REPORT.md).

CSV [SCHEMA_REAL_FEASIBILITY.csv](SCHEMA_REAL_FEASIBILITY.csv) có {len(features)} hàng, một hàng cho **mỗi feature có thứ tự ở mỗi scope**, bao gồm nguồn, đơn vị, scale, trạng thái archive/live và phương án khi thiếu. Không gắn REAL cho số giả lập.

Tham chiếu archive H5: [archived_packets.json](../../results/task2/placement_v1_20261109_03/shadow/archived_packets.json), [readiness.json](../../results/task2/placement_v1_20261109_03/shadow/readiness.json), dữ liệu gốc [cluster-a-real-003](../../data/runs/cluster-a-real-003/). CPU/RAM node/pod lịch sử có đơn vị/window, không phải telemetry hôm nay. Archive thiếu full cluster reservations, Deployment identity và ownerReferences, queue length và WAN bandwidth chưa đo được. Không thay archive cho A4 fresh.

Queue length cần gauge ở app/Prometheus hoặc bỏ khỏi actor live. DAG dependency/bytes cần cấu hình có version và distributed tracing theo workflow ID. WAN/bandwidth cần kế hoạch đo riêng; ở lượt này không tự probe/thử tải. Readiness phục vụ cần EndpointSlice/Pod Ready + cluster availability/health, độc lập trạng thái migration. Derived overload/OOM flag phụ thuộc đủ usage/capacity/inventory; thiếu dữ liệu thì fail closed cho PLACE/MOVE.

Đây là khảo sát feasibility, chưa có adapter V2 operational. Kết quả schema parity và smoke không chứng minh real readiness. A4 chỉ được DONE sau đủ snapshot REAL UTC, owner chain, inventory requests/limits toàn cụm, Metrics API và shadow replay V1 với dữ liệu tươi.
''')
    report=(run/'REPORT.md').read_text(encoding='utf-8')
    table=report[report.index('| Heuristic'):report.index('\nTrung bình')]
    with (run/'smoke/metrics.csv').open(encoding='utf-8',newline='') as f: metrics=list(csv.DictReader(f))
    total=lambda k:sum(int(r[k]) for r in metrics)
    write('SIMULATOR_V2_REPORT.md',f'''# Báo cáo Simulator DAG V2

Run nghiệm thu: [results/task3/{run_id}](../../results/task3/{run_id}/REPORT.md). **{count} test đạt**, gồm 156 test cũ và {count-156} test V2; 192 episode smoke SIMULATED. Không huấn luyện MAPPO/IPPO trong Task 3, không đổi hạ tầng. Task 2B chưa nghiệm thu đầy đủ do A4 PENDING (Cluster A đã phục hồi thủ công, thiếu bằng chứng); phần B hoàn thành độc lập với A4/A5.

{table}

Đây là trung bình 48 episode mỗi heuristic, không phải benchmark MARL hoặc Task 5. Traffic-aware giảm traffic và E2E trong bộ smoke này nhưng RAM std cao hơn RR; SLA không đồng thời tốt hơn mọi cách. Không chọn policy bằng các seed test cũ. Seed mới 51001/51002; bốn DAG × sáu scenario dùng trace chung theo scenario/seed. Latency completed-only phải đọc cùng thất bại/censored.

Tổng trên mọi episode: arrivals={total('workflow_arrivals')}, completed={total('workflow_completed')}, failed={total('workflow_failed')}, unfinished={total('workflow_unfinished')}, service invocations={total('service_invocations')}. Đây là tổng qua nhiều episode độc lập, không phải duy nhất request thật. Mỗi episode có assert workflow conservation và invocation conservation; ledger liên kết bằng workflow ID. Không lấy tổng service calls làm tổng workflow arrivals.

## Chức năng đã xây dựng

Module mới `src/placement_v2/` có DAG tối đa năm service, bốn template, initial topo placement, DAG đến giữa episode khi cụm có tải nền, PENDING/retry/REJECTED, KEEP/PLACE/MOVE, prepare/grace/drain/rollback/cooldown. Workflow admission dùng endpoint Ready và dependency, không chặn theo nhãn MIGRATING. Mỗi request tới ứng dụng không tạo deployment mới.

Event engine tính fork-join max, CPU fair sharing/queue, RAM pressure, link RTT/bandwidth contention và bytes/cost riêng. Capacity randomization có điều kiện initial feasibility; capacity fault log tường minh; overload giữ workload/raw ratios, chặn inbound, cho MOVE out. Workflow timeout/failure/cancellation và censored được báo riêng. Schema actor/critic cố định, masks/padding và loader fingerprint là giao kèo Task 4.

## Bằng chứng và giới hạn

[Mô hình toán](MATH_MODEL.md), [schema](SCHEMA_V2.md), [feasibility từng feature](SCHEMA_REAL_FEASIBILITY.csv), [validation](VALIDATION_REPORT.md), [lý thuyết](THEORY_NOTES.md). Mỗi run có config/provenance, profile hash, code/schema fingerprints, runtime freeze, trace seed/hash, decision/event/resource/workflow/invocation ledgers và JUnit. Hai runtime được ghi riêng: .venv-task2 chạy smoke; .venv đầy đủ chạy regression API/Gymnasium. Không cài thêm hay thay package của runtime cũ.

Profile V1 chỉ low-load, CPU relative MAE 60,86%, saturation null. Các node DAG dùng cùng Sample API class proxy, không phải calibration từng microservice. Capacity/queues/RAM pressure/WAN/prices/background/readiness đều là giả định chưa xác minh miền. Một DAG/episode, không optional branch/async/retry, không state-transfer traffic của migration, không OOM-kill, không MARL training. Reward tham chiếu dùng thống kê lũy kế; actor network summary có giới hạn ghi trong schema. Hạ tầng thật chưa sẵn sàng closed loop.

Task 4: MAPPO CTDE, masked rollout/loss, reward và credit assignment, huấn luyện ngoài mẫu; nhiều DAG đồng thời nếu cần phải mở rộng entity schema. Task 5: GA, Single-Agent RL, K8s-default-like với cùng constraints và budget. A5 là lượt thử tải riêng sau phê duyệt đúng file/mức RPS.
''')
    write('VALIDATION_REPORT.md',f'''# Kiểm thử và tái hiện V2

**{count}/{count} test đạt**, không failure/error. Bộ cũ 156 test vẫn đạt; thêm {count-156} test V2. [JUnit](../../results/task3/{run_id}/validation/junit.xml), [console](../../results/task3/{run_id}/validation/pytest.txt), [status/fingerprints](../../results/task3/{run_id}/validation/status.json). Kiểm thử cũ có fixture huấn luyện nhỏ trong tmp như trước; không huấn luyện lại checkpoint nghiên cứu.

| Nhóm nghiệm thu | Bằng chứng trong tests/test_placement_v2.py |
|---|---|
| DAG, cycle, >5, DAG thứ hai | test_dag_bounds_cycle_and_second |
| Critical path 4 template × 3 mạng | test_exact_critical_path; test_diamond_max_not_sum |
| CPU/queue monotonic, hai chiều placement | test_contention_and_both_placement_directions; test_queue_monotonic_same_trace |
| Bandwidth và contention link | test_bandwidth_delay_and_shared_link |
| Initial topo, mid-episode, masks/padding | test_mid_episode_topo_and_masks; test_all_unplaced_keep_blocked_and_masks_reject_bad_input |
| PENDING/retry/REJECTED | test_pending_reject_and_workflow_error |
| PREPARING/GRACE vẫn phục vụ | test_migration_serves_during_preparing_and_grace; test_target_serves_after_source_loss_in_grace |
| Rollback và drain nguồn | test_migration_rollback_and_source_ready; test_slow_workflow_source_held_until_drained |
| Faults, overload, giữ raw usage, MOVE out | test_fault_conservation; test_ram_capacity_fault_no_silent_eviction |
| Workflow ID, dependency, terminal/SLA một lần | test_dependency_and_completed_workflow_no_duplicate; test_join_fail_once_and_timeout_censor |
| Queue/RAM/link-zero/cluster lỗi | test_explicit_failures_or_censored |
| Trace reproducibility/ranges/capacity feasibility | test_randomization_range_seed_and_capacity_initial; test_initial_capacity_conditional_sample; test_scenario_trace |
| Actor local/critic global, V1↔V2/fingerprint rejection | test_schema_local_global_loader |
| Policy reproducibility | test_policies_reproducible_shared_trace |

Smoke 192 episode SIMULATED dùng 12 shared traces, bốn policy chỉ là heuristics. Conservation được assert sau từng event advance và cuối episode; tổng arrivals/completed/failed/unfinished và số invocation tách riêng. Không tune theo test 30001–30005. [Thông số/freeze/trace](../../results/task3/{run_id}/smoke/metadata.json).

Tái hiện từ workspace (thư mục output phải mới):

```powershell
.\\.venv-task2\\Scripts\\python.exe -X utf8 -m cli.task3 --output results/task3/<run_moi> --test-python .venv/Scripts/python.exe
.\\.venv-task2\\Scripts\\python.exe -X utf8 -m pytest tests/test_placement_v2.py -q
```

CLI `--stage smoke`/`--stage validate` tạo stage tương ứng mới và từ chối ghi đè; `all` từ chối root đã tồn tại. `.venv-task2` không có FastAPI/PyYAML/Gymnasium nên regression dùng `.venv` đã có đủ package. Run _01 dừng ở serialize numpy, _02 dừng vì alias ramp-up, _03 smoke đủ nhưng collection regression thiếu package; giữ nguyên các bằng chứng thử đó. Run {run_id} là kết quả cần đọc. Nếu sửa code/schema, tạo run mới để fingerprint khớp, không sửa artifacts đã đóng băng.
''')
    print(f'Đã tạo báo cáo cho {run_id}, {count} tests, {len(features)} feature rows.')


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8'); main(sys.argv[1])
