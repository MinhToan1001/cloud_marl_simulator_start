# H2 Phân tích dữ liệu và calibration

Đã chạy pipeline cục bộ trên bộ dữ liệu REAL `cluster-a-real-003`. Có profile đáp ứng CPU/RAM/latency ở tải thấp và đánh giá sai số khi replay simulator theo cùng số request/cửa sổ. **Maximum capacity, saturation threshold và queue capacity chưa xác định. CPU fit còn bất định lớn.**

Nguồn: [calibration.json](../../results/task2/placement_v1_20261109_03/calibration/calibration.json), [profile.json](../../results/task2/placement_v1_20261109_03/calibration/profile.json), [full simulator replay](../../results/task2/placement_v1_20261109_03/calibration/full_simulator_low_load_replay.csv), [purged validation](../../results/task2/placement_v1_20261109_03/calibration/purged_validation.json). Mã: [src/placement/calibration.py:86](../../src/placement/calibration.py#L86), [src/placement/calibration.py:54](../../src/placement/calibration.py#L54).

## Chất lượng và nguồn dữ liệu

- Đọc lại 18 raw snapshot và tái tạo 54 metrics records; tất cả typed fields khớp CSV cũ, gồm identity/source/run/workload hash. Int `0` và float `0.0` được so theo giá trị kiểu schema, không so chuỗi JSON.
- 152 request phía client, 0 lỗi. Có 8 cửa sổ hợp lệ và 10 cửa sổ loại: 1 warmup, 5 không có complete latency window, 4 reused cached resource sample.
- Cùng pod UID, cùng cấu hình work và budget: CPU limit 0.25 cores, RAM limit 100663296 bytes = 96 MiB. Node capacity 2 cores là scope khác, không thay vào mẫu app pod.
- Timestamps có timezone UTC; client bắt đầu 2026-11-08T17:44:33.276581+00:00, request cuối 2026-11-08T17:46:33.904481+00:00. Raw snapshots từ 2026-11-08T17:44:28.398220+00:00 đến 2026-11-08T17:47:31.184605+00:00; collection còn kéo dài sau tải.
- Tải quan sát 0.2733–3.2988 req/s; CPU 0.001456–0.026319 cores, tối đa 10.53% pod CPU limit. Đây không phải dữ liệu gần bão hòa.
- Pod memory 32325632–32464896 bytes. Server mean latency theo cửa sổ 5.045–6.485 ms.
- Client mean 47.691 ms, p95 124.007 ms gồm Windows/network/SSH. Không gộp với successful server work latency hoặc dùng trực tiếp làm WAN/base latency.

## Profile và replay

CPU response `idle + coefficient * completed_rps`, RAM và latency dùng hằng số trong miền low-load. Hệ số là mô tả quan sát, không phải định luật nhân quả hay ước lượng maximum service rate.

| Tham số | Giá trị | Phạm vi |
|---|---:|---|
| CPU idle response | 0.001648117 cores | fitted pod window |
| CPU coefficient | 0.005507892 cores/(req/s) | fitted pod window |
| RAM baseline | 32378368 bytes | constant low-load profile |
| Server latency mean | 5.539730 ms | constant low-load profile |

Full simulator replay: A được đặt đúng scope pod limit, không background/WAN; B/C không có arrivals; phân bổ integer request theo thời lượng cửa sổ thật, tính CPU-window theo phần giây cuối. FIFO/conservation vẫn chạy, không thay completion bằng số giả. Mỗi fold fit các cửa sổ khác rồi replay cửa sổ held-out; [CSV](../../results/task2/placement_v1_20261109_03/calibration/full_simulator_low_load_replay.csv) lưu arrivals/window/unfinished.

## Sai số và giới hạn thống kê

Validation cơ bản giữ lại 4 block liên tiếp, mỗi block 2 cửa sổ. Kiểm tra bổ sung loại mọi training window trong 30 giây quanh held-out timestamps: max resource window 19.796s cộng alignment skew rồi làm tròn. Cách purge giảm leakage do CPU smoothing; vẫn chỉ có một run ngắn, không phải external validation độc lập.

| Đại lượng | Grouped MAE | Grouped RMSE | Purged MAE | Purged RMSE | Purged relative MAE |
|---|---:|---:|---:|---:|---:|
| CPU cores | 0.002959 | 0.004068 | 0.005436 | 0.008378 | 60.865% |
| RAM bytes | 79701.333333 | 83109.585060 | 102400.000000 | 106927.127334 | 0.316% |
| Server latency ms | 0.311167 | 0.423649 | 0.336167 | 0.455379 | 6.068% |
| Completed req/s | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000% |
| Error percentage points | 0.000000 | 0.000000 | 0.000000 | 0.000000 | N/A zero denominator |

Mỗi chỉ số dùng n=8. Relative MAE = MAE / mean(abs(real)), không lấy MAPE trên các cửa sổ có zero denominator. Throughput/error khớp ở tải thấp chỉ phản ánh healthy flow và không có observed failure; không chứng minh saturation hoặc mô hình lỗi chính xác. CPU purged relative MAE khoảng 60.9% cho thấy chưa có CPU calibration đáng tin để extrapolate.

So sánh mô hình cũ trong `old_model_analytic_low_load_errors` là expectation gần tải thấp với budget A cũ 2 cores/512 MB khác pod thật; chỉ dùng chẩn đoán scope mismatch, không dùng tuyên bố phần trăm cải thiện toàn cluster. Không suy memory-per-queued-request từ RAM-vs-RPS.

![Calibration heldout](../../results/task2/placement_v1_20261109_03/figures/calibration_holdout.png)

## Kết quả áp dụng và việc cần thêm dữ liệu

Profile mới và config placement được ghi ở đường dẫn mới; config/dataset/routing checkpoints cũ giữ nguyên. Simulator placement dùng response profile nhưng capacity/CPU work cost, queue size, B/C, WAN/background/readiness và workload bổ sung vẫn là assumptions có nhãn SIMULATED trong [provenance](../../results/task2/placement_v1_20261109_03/provenance.json). Không lấy extrapolation CPU limit làm maximum capacity thật.

Đã lập [CONTROLLED_LOAD_TEST_PLAN.md](CONTROLLED_LOAD_TEST_PLAN.md) nhưng không chạy live load test. Cần run độc lập có nhiều mức tải và cửa sổ ổn định dài hơn trước khi tuyên bố CPU/capacity accuracy hoặc saturation threshold.
