# Kế hoạch thu thêm dữ liệu calibration

Trạng thái: kế hoạch tham khảo, **chưa thực thi**. Task 2 hiện tại không có quyền tạo tải thật hoặc thay đổi hạ tầng. Không có script nào trong deliverable tự kích hoạt kế hoạch này.

Mục đích: thu run độc lập để kiểm tra CPU response, mở rộng miền tải có kiểm soát và quan sát quan hệ latency/CPU. Không cam kết xác định maximum capacity trong giới hạn an toàn này.

1. Trước thử nghiệm phải xác minh hai hop SSH, namespace/pod UID/Deployment owner, resource requests/limits, phiên bản app và cấu hình work không đổi. Chỉ dùng workload đã được đồng ý; không đổi VM/flavor/networking hoặc scale replica để đạt tải.
2. Đồng bộ clocks và ghi timestamp UTC cho client/server/resource samples. Lưu run ID mới, workload/config hash, raw snapshots, app event sequence, client request trace, window lengths và collector errors. Không ghi vào `cluster-a-real-003`.
3. Tải mở theo từng mức 0.5, 1, 2, 4, 8, 16 req/s; mỗi mức tối đa 60 giây. Warmup 30 giây và recovery 60 giây ở 0.5 req/s. Tổng tối đa 450 giây và 2000 requests; không tự tăng giới hạn nếu chưa quan sát bão hòa. Phải đo offered RPS thật, không coi số Locust users là RPS.
4. Chỉ tăng mức nếu mức trước ổn định. Dừng và giảm tải khi error rate >1% trong 30 giây, server p95 >100 ms trong 30 giây, app CPU >85% limit trong 20 giây, RAM >80% limit, pod restart/NotReady hoặc DevStack/VM có áp lực tài nguyên. Các ngưỡng là đề xuất cần xét theo hạ tầng trước khi chạy.
5. Thu resource metrics mỗi 5 giây nhưng lưu đúng Metrics API window, loại cached samples trùng; lưu application event windows độc lập để có p95/p99 đúng population. Không lấy percentile của mean windows.
6. Tối thiểu ba run độc lập, có idle baseline, thời gian ổn định đủ dài và recovery. Tách các run thành fit/validation; temporal purge theo metrics window và alignment skew. Không đưa test run vào chọn hệ số.
7. Báo miền tải đạt được, các mức bị dừng, SLO/errors/restarts, scope pod/node và uncertainty. Chỉ có observed healthy throughput lower bound nếu chưa saturation; không gọi đó là maximum capacity.

Điều kiện tiếp tục kế hoạch: người dùng cho phép riêng một buổi thử tải thật sau khi xem kết quả Task 2. Yêu cầu thực hiện toàn bộ Task 2 hiện tại vẫn giữ giới hạn không thay đổi hạ tầng và không tự stress test.
