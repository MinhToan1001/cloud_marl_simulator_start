# H3 Simulator placement và schema đã triển khai

Thiết kế đã được người dùng duyệt bằng yêu cầu thực hiện toàn bộ Task 2. Module mới `src/placement/` giải placement cho ba workload stateless mô phỏng; routing v1 trong `src/cloud_sim/` và `src/marl/` được giữ nguyên.

## State và action đã chốt

Version `placement-v1`, action kind `workload_placement`, observation **123 features float32**, clip [0,10]. Ba agent `service_0/1/2`, mỗi agent sở hữu một workload. Actions: 0 KEEP, 1 MOVE_A, 2 MOVE_B, 3 MOVE_C. Không reuse output routing. Full ordered feature/units/scales/masks ở [schema.json](../../results/task2/placement_v1_20261109_03/schema.json); schema SHA-256 `bacc255d57fbb1b405f55470a25e17f3e3c0085e338824851ebcdb95357996ab`.

Mỗi cluster có 16 features: availability, CPU/RAM capacity, CPU/RAM usage ratios, CPU/RAM reservation ratios, arrival/completion rates, mean/p95 latency, error fraction, resource/app validity, age và reservation validity. Mỗi service có 24 features: active/target/source one-hots, phase one-hot, timers, demand, requests, readiness, completed move count, validity và SLO. Ba own-workload one-hots kết thúc vector. Tổng 48+72+3=123; không có future-horizon feature. Nguồn: [src/placement/schema.py:23](../../src/placement/schema.py#L23), [src/placement/schema.py:40](../../src/placement/schema.py#L40).

## Lifecycle và constraints

Transition chính: PREPARING giữ serving source → target Ready rồi GRACE phục vụ đích và drain backlog nguồn → giải phóng nguồn. Target failure/timeout hoặc failure trong grace rollback; backlog không teleport. Request còn lại khi gỡ nguồn trở thành release error; cuối episode giữ unfinished/censored rõ ràng.

Validator thuần dùng chung cho env RR/LL/IPPO và shadow, shadow thêm identity requirement. Kiểm tra legality, availability/freshness, workload identity, CPU/RAM headroom, reservations, cooldown, move-attempt cap và concurrency. Usage và reservations dùng max khi kiểm tra headroom để không cộng đúp workload; arbiter xoay service order, reserve target ngay khi nhận action. Proposed/validated/executed/reason đều được log. Nguồn: [src/placement/validator.py:4](../../src/placement/validator.py#L4), [src/placement/env.py:287](../../src/placement/env.py#L287), [src/placement/env.py:141](../../src/placement/env.py#L141).

Physics một giây, decisions mỗi 5s, readiness mặc định 5s có randomization, timeout 30s, grace 5s, cooldown 30s; concurrency 1. CPU response không được vượt workload CPU limit; tổng usage bị chặn bởi cluster budget. Queue FIFO hữu hạn, không drain ảo ở episode end. Đây là model giả định ở tải cao; max concurrency thật của app và scheduler Kubernetes chưa được mô phỏng đầy đủ.

## Resource scope và randomization

Budgets A .5 cores/256 MiB, B .75 cores/384 MiB, C 1 core/512 MiB là resource pools mô phỏng, không phải capacity đo thật của nodes. Requests mỗi workload .1 core/64 MiB, CPU limit .25 core, work cost .005 core-seconds/request, queue limit 80 là config thử nghiệm. Profile CPU/RAM/server mean có nguồn Task 1 ở miền low-load; không áp nhãn REAL cho toàn physics.

Config domain randomization: CPU performance factor [0.8, 1.2], background CPU fraction [0.1, 0.65], network factor [0.8, 1.3], readiness factor [0.6, 1.6]; faults hữu hạn theo seed. Trace arrivals, background, availability, network và readiness được tạo trước độc lập policy RNG, hash cùng body; mọi method replay cùng trace. Nguồn: [src/placement/trace.py:9](../../src/placement/trace.py#L9) và [config/provenance](../../results/task2/placement_v1_20261109_03/provenance.json).

## Reward, metrics và kiểm thử

Shared reward gồm success, mean latency/SLO, errors, resolved SLO violations, reserved-resource waste, accepted move/overlap cost và failed moves. Cuối episode thêm unfinished penalty. Fraction trong decision window dùng arrivals cộng queue đầu window; SLO report dùng resolved cohort, unfinished báo censored. Coefficients cố định trong config trước held-out test; không tune bằng test. Nguồn: [src/placement/env.py:287](../../src/placement/env.py#L287), [src/placement/env.py:331](../../src/placement/env.py#L331).

Metrics gồm completion mean/p95/p99 histogram, throughput, errors theo loại, unresolved queue, CPU/RAM usage/reservation, waste, migration counts/latency/downtime, moves/phút và dwell approximation. Đọc histogram cùng failures/unfinished để tránh survivor bias. Mean dwell = tổng service-time / (completed moves + initial 3 intervals), là tóm tắt có cả boundary intervals, không phải phân phối dwell đầy đủ.

Bộ test hiện tại **156 passed**, gồm 135 test cũ và 21 test placement mới; [JUnit](evidence/task2-tests-final.xml). Tests kiểm readiness/overlap/release, preparation và grace rollback, timeout, unavailable service, shared arbitration, resource rejection, CPU limit, accounting mọi scenario, mask/GAE/PPO update, schema parity, legacy rejection, mismatch feature unit/config, replay thực, reproducibility và shadow fallback. Không thêm executor Kubernetes hoặc HTTP controller vào Task 2.
