# A5 — Yêu cầu phê duyệt thử tải có kiểm soát

**PENDING — chỉ lập kế hoạch, chưa chạy tải, chưa có profile v2.** Phê duyệt phải nêu rõ file này và các mức RPS được phép, bằng văn bản ở một lượt riêng. Phản hồi chung chung không phải phê duyệt. Không thay đổi cấu hình hạ tầng.

## Phạm vi và trình tự đề xuất

Chỉ Sample API trong namespace `cloud-calibration`, sau khi A4 xác minh sống identity Deployment/Pod, requests/limits, reservation toàn cụm và Metrics API. B/C không tham gia. Nếu identity, đồng hồ hay telemetry chưa hợp lệ thì không bắt đầu.

| Bước | Mức tải tổng tới Sample API | Thời lượng | Lặp |
|---|---:|---:|---:|
| Baseline không tải chủ động | 0 RPS | 120 giây | trước mỗi vòng |
| Warm-up | 0,5 RPS | 180 giây (3 phút) | mỗi vòng |
| Bậc 1 | 0,5 RPS | 120 giây | 3 vòng độc lập |
| Bậc 2 | 1 RPS | 120 giây | 3 vòng độc lập |
| Bậc 3 | 2 RPS | 120 giây | 3 vòng độc lập |
| Bậc 4 | 3 RPS | 120 giây | 3 vòng độc lập |
| Bậc 5, cần duyệt riêng mức này | 4 RPS | 120 giây | 3 vòng độc lập |
| Cool-down | 0 RPS chủ động | ít nhất 120 giây | sau mỗi vòng |

RPS ở bảng là tổng của toàn bộ worker, không nhân theo số worker. `/work` giữ payload tham chiếu `cpu_ms=5`, `memory_kib=64`, tối đa 2 request đồng thời như run cũ. Không tự tăng payload hoặc tải vượt mức duyệt để tìm saturation. Mức 4 RPS vượt miền dữ liệu cũ, có thể bị loại khỏi phê duyệt. Việc không thấy điểm gãy ở các mức này không chứng minh capacity tối đa.

Endpoint duy nhất được phép: `/health` trước/sau mỗi vòng và kiểm tra thưa tối đa 1 lần/10 giây, `/work` theo RPS được duyệt, `/metrics` thu mỗi 5 giây. Không gọi endpoint quản trị; không write Kubernetes/OpenStack API. Nếu đường dẫn/tham số thực tế khác thì phải xác minh trước lượt chạy.

## Đồng bộ và điều kiện dừng

Locust và Collector dùng UTC, lưu clock offset trước/sau; độ lệch tuyệt đối >1 giây thì chưa chạy hoặc dừng thu và đánh dấu không hợp lệ. Collector bắt đầu trước baseline 60 giây, ghi pod UID, restart count, timestamps, interval/window của Metrics API và client request ID; kết thúc sau cool-down 60 giây. Ghi run ID mới, marker từng bậc và request thành công/thất bại/unfinished; không sửa run cũ. Không cộng số invocation để tính workflow arrivals.

Dừng toàn bộ tải ngay khi một trong các điều kiện sau xảy ra:

- Error/timeout >1% trong cửa sổ 30 giây có ít nhất 30 request; hoặc 3 lỗi liên tiếp khi tải nhỏ.
- CPU pod ≥90% limit liên tục 15 giây; CPU throttling tăng mạnh; restart/OOM mới hoặc pod mất Ready.
- Node `MemoryPressure`, RAM available <15%, hoặc CPU node ≥90% trong 15 giây.
- p99 `/work` >250 ms trong hai cửa sổ 30 giây, hoặc health thất bại 3 lần liên tiếp.
- Metrics mất >15 giây, đồng hồ lệch >1 giây, mất liên lạc, OpenStack API/VM có dấu hiệu suy giảm hay người vận hành yêu cầu dừng.

Ngưỡng trên là **ASSUMPTION** cho kế hoạch bảo thủ, cần đối chiếu baseline/limit A4 trước khi duyệt; không phải kết quả đo. Theo dõi OpenStack qua kiểm tra chỉ đọc sẵn có, không tạo VM hay tài nguyên để thử.

## Phục hồi và đầu ra sau lượt được duyệt

Ngừng Locust trước, giữ Collector/health thưa để xác nhận trở về baseline ít nhất 120 giây. Không restart, scale, đổi request/limit hoặc can thiệp DevStack/K3s. Nếu chưa hồi phục thì dừng thí nghiệm và báo người vận hành; không tự sửa hạ tầng. Lưu cả run bị dừng và lý do.

Sau lượt thực tế được duyệt: fit profile có version mới ở thư mục mới, kiểm chứng fit run cũ → run mới và fit run mới → run cũ, tránh window chồng lấn. Báo CPU MAE/relative MAE (mốc cũ 60,86%), RAM, quan hệ RPS–latency và error. Chỉ ghi ngưỡng saturation khi quan sát điểm gãy có bằng chứng; nếu không, `maximum_capacity_rps=null`. Profile V1 giữ nguyên.
