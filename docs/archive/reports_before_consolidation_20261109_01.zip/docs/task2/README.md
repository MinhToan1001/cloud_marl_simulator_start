# Task 2 Calibration và placement MARL

Đã thực hiện PHẦN 0, H1–H5 trong phạm vi cục bộ/offline shadow. Người dùng đã duyệt tiếp tục toàn bộ Task 2; không còn chờ phê duyệt thiết kế. H1/proposal cũ được giữ làm lịch sử quyết định.

**Đọc một lần tại [báo cáo tổng hợp](../../results/task2/placement_v1_20261109_03/REPORT.md).** Run cuối: `results/task2/placement_v1_20261109_03`.

| Tài liệu | Nội dung |
|---|---|
| [ENVIRONMENT_AUDIT.md](ENVIRONMENT_AUDIT.md) | Snapshot môi trường ban đầu và SSH timeout |
| [H1_CODE_AUDIT.md](H1_CODE_AUDIT.md) | Routing/IPPO/schema/checkpoint audit ban đầu |
| [H2_CALIBRATION_REPORT.md](H2_CALIBRATION_REPORT.md) | Data quality, replay, holdout/purged errors và giới hạn low-load |
| [H3_IMPLEMENTATION_REPORT.md](H3_IMPLEMENTATION_REPORT.md) | Placement schema/lifecycle/constraints và tests |
| [H4_TRAINING_EVALUATION_REPORT.md](H4_TRAINING_EVALUATION_REPORT.md) | 900 episodes, 3 policy seeds, 150 evaluation runs |
| [H5_SIM_TO_REAL_READINESS.md](H5_SIM_TO_REAL_READINESS.md) | Archived shadow, shared validator và giới hạn readiness |
| [CONTROLLED_LOAD_TEST_PLAN.md](CONTROLLED_LOAD_TEST_PLAN.md) | Kế hoạch lấy thêm dữ liệu, chưa thực thi |
| [PLACEMENT_DESIGN_PROPOSAL.md](PLACEMENT_DESIGN_PROPOSAL.md) | Thiết kế đã được cho phép triển khai |

156 tests pass. Checkpoint/dataset/kết quả routing gốc được bảo toàn. Có calibration profile low-load nhưng CPU purged error còn lớn, maximum capacity chưa xác định và closed-loop readiness false. IPPO không vượt Least Loaded tổng thể; báo cáo không che giấu kết quả này.

Không thay đổi DevStack/K3s/networking, không chạy tải thật, không sử dụng AWS. `.venv-task2` cô lập có `pip check` sạch. Các script audit/bootstrap/purged/build_reports tại đây chỉ thao tác cục bộ; CLI thực nghiệm ở `src/cli/task2.py`.
