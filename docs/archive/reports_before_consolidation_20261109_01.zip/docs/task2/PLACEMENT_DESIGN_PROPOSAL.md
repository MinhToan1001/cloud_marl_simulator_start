# Đề xuất thiết kế placement cho Task 2

Trạng thái cập nhật: **ĐÃ ĐƯỢC PHÉP TRIỂN KHAI** qua yêu cầu tiếp theo của người dùng: “thực hiện toàn bộ task 2 … tôi kiểm tra 1 lần”. Nội dung dưới đây được giữ làm lịch sử thiết kế trước triển khai. Bản thực hiện và kết quả cuối nằm tại [README.md](README.md). Ngày 09/11/2026.

Mục tiêu là chuyển từ request routing sang inter-cluster placement có state/action tương ứng với một kế hoạch Kubernetes. Giữ môi trường routing v1 và kết quả cũ để truy nguyên. Task 2 chỉ triển khai, calibrate và đánh giá cục bộ; kiểm tra sim-to-real dừng ở offline/shadow plan. Không thực thi Kubernetes migration, sửa OpenStack/networking hoặc dùng AWS.

Điểm kiểm soát trong prompt được người dùng yêu cầu thực hiện:

> Trước khi thực hiện thay đổi lớn về state/action hoặc huấn luyện lại, trình bày thiết kế và yêu cầu tôi phê duyệt.

Prompt còn yêu cầu chưa thực hiện H2–H5 trước khi hoàn tất H1 và thống nhất thiết kế placement. H1 đã xác nhận action routing tại `src/marl/env.py:116–124`; checkpoint chỉ chứa model input 26/output 3 của routing v1 (`src/marl/ippo.py:43–49,161–182`). Vì vậy cần phê duyệt thay đổi ngữ nghĩa, không chỉ đổi tên action.

## 1. Quyết định kiến trúc cần duyệt

**Đề xuất: ba independent PPO agent, mỗi agent quản lý placement của một workload stateless riêng; mỗi workload có một cluster phục vụ chính.**

- Chuyển ownership từ ba agent gắn với cluster A/B/C sang ba agent gắn với workload `service_0`, `service_1`, `service_2`. Ba workload là ba đơn vị Deployment độc lập trong mô phỏng, không phải ba replica của một Deployment và không mặc định là ba microservice đã triển khai thật.
- Đây là thay đổi lớn trong ý nghĩa MARL. Mỗi workload có arrival trace, CPU/memory requests, SLO và cluster placement riêng. Các agent hợp tác qua shared reward và cạnh tranh headroom trên cùng ba cluster; actor/critic/optimizer vẫn độc lập.
- Task 1 chỉ có dữ liệu Sample API trên Cluster A. H2 có thể ước lượng profile cho workload đó trong phạm vi đã quan sát. Workload bổ sung và B/C chỉ là giả định mô phỏng có nhãn nguồn; không lấy bản sao profile làm bằng chứng đã calibrate ba dịch vụ hoặc ba cluster.
- Khi chỉ có một Deployment thật, adapter H5 chỉ dựng plan cho workload đã ánh xạ xác thực; các workload chưa ánh xạ không được tạo operation plan thực thi. Không triển khai thêm workload thật để đủ ba agent.
- Tách placement decision và dispatcher. Trong mỗi tick, request đi đến cluster serving của workload, dùng cùng dispatcher cố định cho mọi policy. IPPO không đồng thời quyết định tỷ lệ routing, tránh hai bài toán bị trộn.

Lý do chọn workload agents: mỗi action có một đối tượng sở hữu rõ ràng và thay đổi vị trí triển khai thật sự. Nếu giữ ba cluster agent cùng phát lệnh MOVE cho một Deployment duy nhất, phải phát minh cơ chế bầu chọn/đấu giá khác và action có thể xung đột; thiết kế đó không được ngầm coi là IPPO placement tương đương.

Tách module dự kiến: `placement` model/env/schema/validator/baselines/metrics và CLI riêng, giữ đường `cloud_sim`/`marl` routing hiện tại hoạt động. Tên file cụ thể là kế hoạch tạo mới, chưa tồn tại. Không dùng checkpoint cũ làm pretrained placement hoặc đổi env version của nó.

## 2. State và observation đề xuất

Version semantic mới: `placement-v1`; có manifest chứa ordered feature names, dtype, units, scaling/clipping, validity masks, cluster/service order, agent ownership và action enum. Tensor layout cụ thể được đóng băng, kiểm thử và hash trước khi bắt đầu training; kích thước không kế thừa 26. Mọi thay đổi sau đó cần version/fingerprint khác.

| Nhóm state | Trường và đơn vị | Nguồn/ý nghĩa |
|---|---|---|
| Identity/provenance | cluster IDs A/B/C, service IDs, source REAL/SIMULATED, schema version, config hash | Metadata đi kèm; nhãn nguồn không bị mất khi vector hóa |
| Cluster availability | API reachable, Node Ready, telemetry valid/fresh, timestamps/age giây | Trạng thái thật từ đọc status/metrics hoặc state mô phỏng; unknown khác available |
| Cluster resource budget | allocatable CPU cores/RAM bytes; background usage; workload reservations; measured utilization | Phân biệt usage với requests/reservations; không cộng đúp các đại lượng |
| Workload resources | CPU request cores, memory request bytes, CPU/memory limit nếu có, profile ID | Resource policy cho một Deployment đã chọn; profile ghi miền tải đã kiểm chứng |
| Demand/performance | arrival/completion req/s, sample count, latency mean/p95 ms, error fraction, SLO ms | Tách server/client population; không gộp latency khác scope |
| Placement | active/desired/target cluster, unplaced flag, ready replicas/desired replicas | Một primary serving cluster, có thể có target trong giai đoạn chuẩn bị |
| Lifecycle | IDLE/PREPARING/GRACE/ROLLBACK/UNPLACED, time in phase, remaining timeout/cooldown giây | Countdown có thể quan sát; chi phí không bị ẩn khỏi agent |
| Migration history | migration count, time since last completed move, per-step move event/cost | Phân biệt requested/accepted/completed/failed moves |
| Validity | metric masks theo nhóm/field, freshness, profile confidence/observed-range flag | Thiếu dữ liệu không bị diễn giải thành CPU=0 hoặc latency=0 |

Normalization: tỷ lệ utilization/headroom theo allocatable tương ứng; arrival/completion theo reference RPS của config, **không gọi reference là maximum capacity đã đo**; latency theo SLO/reference latency; thời gian theo policy horizon/cooldown scale; vị trí dùng one-hot với trạng thái NONE. Clipping và thresholds ghi trong manifest, kèm masks và tỷ lệ clipped trong evaluation. Không đưa thời gian còn lại của trace tương lai vào observation live.

Mỗi agent nhận state các cluster và workload theo cùng một thứ tự chuẩn, thêm own-workload ID để phân biệt vai trò. Không yêu cầu actor chỉ nhìn telemetry local. Full observation builder phải dùng chung giữa simulator và offline/shadow adapter để kiểm tra parity.

Thiếu CPU/RAM/freshness hoặc cluster unavailable làm MOVE tới đích đó không hợp lệ. Thiếu latency không tự trở thành latency=0 có ý nghĩa; vector có placeholder theo manifest cùng mask, reward/evaluation báo thiếu sample. Không suy availability B/C thật từ dữ liệu giả lập.

## 3. Action và validator

Action enum cho mỗi workload agent:

| Code | Action | Tác động placement |
|---|---|---|
| 0 | KEEP | Giữ serving placement hoặc tiếp tục transition đang chạy |
| 1 | MOVE_A | Đề nghị workload phục vụ tại Cluster A |
| 2 | MOVE_B | Đề nghị workload phục vụ tại Cluster B |
| 3 | MOVE_C | Đề nghị workload phục vụ tại Cluster C |

MOVE tới cluster đang phục vụ được canonicalize thành KEEP, không tăng migration count. KEEP không có nghĩa là workload healthy: nếu chưa placed hoặc cluster active unavailable thì request có thể fail và được tính vào outcome. Hệ thống không chuyển traffic đến endpoint chưa Ready để làm đẹp metrics.

Validator/action mask dùng cùng code cho IPPO/RR/LL. Kiểm tra target availability/freshness, resource requests/reservations, headroom, action legality, cooldown, transition đang chạy, max migration count và giới hạn move đồng thời. Chuẩn hóa một lần đơn vị cores/bytes trước kiểm tra.

Tranh chấp headroom giữa các agent: lấy đề xuất từ cùng pre-state, xử lý theo service order xoay vòng theo decision index (công bằng, tái lập), trừ reservation ngay khi chấp thuận. Policy không điều khiển thứ tự arbitration. Một action bị từ chối trở thành KEEP với reason code; log proposed/validated/executed riêng, không sửa silently. IPPO sample từ masked logits và lưu mask/log-prob đúng vào rollout; mọi policy đều qua validator cuối.

## 4. Lifecycle placement và request serving

Decision interval mặc định đề xuất 5 giây, simulator physics tick 1 giây; cooldown 30 giây, target readiness delay giả định 5 giây, readiness timeout 30 giây, grace 5 giây, tối đa 1 move đang chuẩn bị mỗi hệ thống. Đây là **tham số thử nghiệm mô phỏng chưa đo**, có provenance và phải được sensitivity analysis/domain randomization; không phải thay đổi cấu hình K3s.

1. MOVE được chấp thuận: reserve tài nguyên target, tạo PREPARING; source tiếp tục nhận request nếu còn available. Chưa tăng completed migration count.
2. Target đạt readiness và health mô phỏng trước timeout: đổi serving endpoint, bắt đầu GRACE. Hai footprint source/target cùng tồn tại và đều tính resource reservation/cost.
3. Hết grace: giải phóng source reservation, ghi completed move, bắt đầu cooldown. Không chuyển Pod đang chạy xuyên cluster; mô hình là chuẩn bị Deployment đích rồi đổi serving placement.
4. Target thất bại/timeout: release target reservation và rollback về source nếu còn available; log failed move và giữ nguyên outcome requests. Nếu cả source/target không available, tính unavailable errors, không tự tạo capacity.
5. Nếu source mất availability lúc chuẩn bị: requests chỉ phục vụ khi có target Ready; phần còn lại fail/queue theo quy tắc hữu hạn được cấu hình chung cho mọi policy. KEEP không tạo dịch vụ thay thế vô điều kiện.

Queue gắn với workload và cluster đang thực sự phục vụ; backlog nguồn được drain trong grace khi có thể, không teleport sang cluster đích. Khi source bị gỡ, request còn lại phải được ghi failure/unfinished theo một quy tắc cố định. Warmup không có traffic nhưng vẫn giữ footprint tài nguyên. Kết thúc episode phải báo unfinished requests và pending moves, không coi là completion.

Trong H3 phải kiểm thử conservation request, conservation reservation, không vượt allocatable vì accepted moves, không route tới unready target, no-op MOVE không tính migration, cooldown/rollback/grace và determinism under joint proposals.

## 5. Reward và metrics đề xuất

Shared team reward theo decision window; outcome tính theo request, không trung bình đều p95 của các tick. Cấu hình khởi đầu đề xuất, phải freeze trước held-out testing:

```text
r = +1.0 * success_fraction
    -0.2 * min(completed_mean_latency_ms / reference_slo_ms, 10)
    -2.0 * error_fraction
    -1.0 * slo_violation_fraction
    -0.1 * reserved_resource_waste_fraction
    -0.1 * accepted_move_cost_normalized
    -0.5 * failed_move_fraction
```

Đây là trọng số thiết kế, chưa có kết quả chứng minh tối ưu. Thành phần mean latency chỉ tính trên completions có sample và luôn báo validity; không để thiếu latency xóa error/unfinished penalties. Resource waste là phần workload CPU/RAM **đã reserve nhưng không dùng** trong cửa sổ, có bounds và scope rõ; không coi mọi free capacity của cluster là waste. Move cost gồm startup/overlap footprint và move-event cost cấu hình; không lấy routing ratio delta làm migration cost. SLO denominator và error taxonomy phải được đóng băng, tránh đếm một request hai lần mà không khai báo.

Metrics bắt buộc cho báo cáo: offered/completed throughput, latency mean/p95/p99 từ completed request histogram, app/drop/unavailable errors, SLO violations, queue/unfinished tại cuối, CPU/RAM usage và reservation riêng, waste, accepted/completed/failed migration count, migration latency, downtime, moves/phút và placement dwell time. Latency completed-only luôn đi cùng failure/unfinished count để thấy censoring.

Mỗi request phải có outcome hoàn tất/lỗi/unfinished và SLO status. SLO violation gồm response thành công trễ deadline và lỗi/timeout theo định nghĩa đã công bố; request chưa hoàn tất tại cuối được báo riêng, không mặc định đạt SLO. Báo tỷ lệ trên cohort được theo dõi đủ deadline hoặc ghi rõ cohort censored.

## 6. Baseline cùng bài toán

- Placement Round Robin: ở mỗi decision epoch chọn target kế tiếp trong A/B/C, qua cùng mask/validator/cooldown. Nếu target trùng active placement thì KEEP. Chấp nhận rằng baseline có thể move nhiều; event cost được đo thật trong simulator.
- Placement Least Loaded: chọn feasible target theo reserved/available CPU-RAM headroom và measured load; giữ placement nếu cải thiện không vượt hysteresis cấu hình. Tie-break cố định. Không dùng future workload hay capacity thật chưa biết.
- IPPO: KEEP/MOVE proposals từ observation cùng snapshot và cùng constraints. Không dùng routing checkpoint để phát proposals placement.
- Một run gồm cùng initial placements, resource budgets, background/network/readiness random traces và workload trace cho cả ba method. Exogenous RNG tách khỏi action RNG để số lần move khác nhau không làm thay đổi workload/availability ngẫu nhiên giữa thuật toán.

Định nghĩa RR/LL và hysteresis được lưu trong experiment manifest trước test; không tune bằng held-out outcomes để tạo lợi thế giả cho MARL.

## 7. H2 sau khi duyệt

1. Kiểm định `cluster-a-real-003`: identity/source, timestamp timezone, run/workload hashes, pod UID, các window thiếu/cache, latency population và quan hệ client/server. Giữ nguyên raw/processed gốc; kết quả phân tích ghi thư mục mới.
2. Phân biệt usage node với usage/limit của app pod; chuyển cores/bytes/MB/MiB tường minh. Xác định biến đo đủ để fit, không lấy RAM-vs-RPS làm memory-per-queued-request.
3. Reproduce profile trong miền tải đã quan sát; replay cùng trace/cùng time aggregation và scope để so CPU/RAM, completion, latency, errors. MAE/RMSE/relative error chỉ tính trên các cặp có nghĩa; báo denominator, valid samples và phạm vi tải.
4. Low-load không xác định maximum capacity, queue capacity hoặc saturation threshold. Không dùng CPU-limit extrapolation trong helper cũ làm capacity đã chứng minh. Nếu không định danh được service-rate/capacity thì ghi unknown/assumed, không giả báo cáo calibrated.
5. Profile/config đề xuất ghi đường dẫn mới cùng provenance/observed range/uncertainty. Tham số không có bằng chứng giữ nhãn giả định; tuyệt đối không overwrite `configs/simulation.json` hoặc dataset cũ.
6. Nếu cần data thêm: chỉ lập kế hoạch load test có giới hạn, stop conditions và thu metrics; không chạy trên live infrastructure theo quyền hiện tại.

Nếu dữ liệu không đủ, Task 2 có thể tạo được simulator/policy thử nghiệm và báo cáo giới hạn, nhưng không được tuyên bố đã đạt calibration accuracy hoặc capacity thật ngoài miền đo. Gate khoa học này độc lập với việc code/tests pass.

## 8. H3 và schema compatibility

Implement môi trường placement/module riêng, observation builder, validator, lifecycle, baselines và metrics. Domain randomization có config cho resource performance profile, background load, readiness delay, network latency và availability; labels phân biệt empirical bounds và exploratory assumptions. Giữ held-out randomization conditions tách train/validation.

Checkpoint placement lưu algorithm/env version, action kind `workload_placement`, ordered feature manifest hash, agent ownership/service catalog, action enum, reward/normalization/transition/config fingerprints, resource profile provenance, seeds, optimizer/RNG, package versions và code fingerprints. Loader phải từ chối routing checkpoint hoặc manifest mismatch ngay cả khi tensor dimensions tình cờ trùng.

Tests phải kiểm tra schema order/units/masks, simulator↔adapter parity, illegal action fallback, resource contention, source/target failure, readiness/cooldown, rollback, request accounting, p95/p99/SLO semantics, same exogenous trace cho mọi policy và bảo toàn checkpoint/dataset cũ.

## 9. H4 và giới hạn training đề xuất

Sau khi duyệt kiến trúc và cho phép training: kiểm tra CPU/RAM/disk và dùng venv cô lập; không cài/chỉnh dependencies global. Chạy pilot nhỏ ở thư mục mới để đo thời gian, kiểm tra loss/gradient/reward và xác nhận estimate trước chạy ma trận chính.

Đề xuất ma trận khởi đầu: **3 policy initialization seeds (7,17,27)**, train workload seeds riêng, validation seeds riêng và 5 held-out testing seeds (30001–30005); workload stable, ramp-up, spike, recovery, periodic, shift. Các test traces/background/network/readiness conditions ghép cặp giữa RR/LL/IPPO. Không dùng test để chọn best checkpoint hoặc tune reward.

Ngân sách xin duyệt: CPU cục bộ, pilot tối đa 2 episode/seed, run chính tối đa 300 episode/seed và tổng wall time tối đa 30 phút. Đây là cap, chưa phải cam kết 300 episode đủ hội tụ hoặc 30 phút đủ ma trận. Nếu pilot/kiểm tra tài nguyên cho thấy vượt cap, báo estimate và xin mở rộng trước khi vượt. Không AWS/GPU thuê ngoài hoặc training trên Ubuntu/K3s.

Lưu từng seed/config/checkpoint vào versioned run directory mới; tổng hợp policy-seed variability riêng với workload-seed variability. Báo paired differences và uncertainty; không chọn chỉ run đẹp hoặc mặc định MARL thắng. Kết quả routing cũ vẫn mang nhãn routing/simulation và không tính vào số lần train placement.

## 10. H5 và phạm vi kiểm thử thật

Offline adapter dựng observation từ snapshot thật với timestamp/source/masks, đối chiếu manifest, tạo action proposal và operation plan thuần dữ liệu. Một plan hợp lệ gồm target identity/resource check → prepare target → wait Ready/health → switch endpoint → grace → release source, cùng rollback prerequisites. Task 2 không chạy các operation này.

Với một Cluster A thật và B/C chưa triển khai, readiness report phải tách:

- Schema/logic compatibility có thể kiểm thử offline bằng fixtures và snapshot hợp lệ.
- Mapping Sample API A chỉ xác nhận được khi có identity/status/metrics thật phù hợp.
- MOVE_B/MOVE_C chỉ là plan mô phỏng, không xác nhận thực thi thật; toàn hệ thống chưa closed-loop ready.

Nếu SSH lại hỏi mật khẩu, người dùng tự nhập; không yêu cầu gửi mật khẩu trong chat. Chỉ đọc status/metrics cần thiết khi có kết nối. Quyền hiện tại không bao gồm rollout, scale, traffic switching, migration hoặc sửa networking.

## 11. Nội dung phê duyệt

Đề nghị duyệt cùng một phương án cụ thể:

1. Chuyển ownership của ba IPPO agent từ cluster sang ba workload mô phỏng độc lập, triển khai môi trường placement riêng với KEEP/MOVE_A/B/C và lifecycle/validator nêu trên.
2. Cho phép làm H2–H3 cục bộ, ghi artifacts/config mới và giữ nhãn giới hạn dữ liệu; không thực thi tải/migration thật.
3. Cho phép H4 training lại CPU theo ngân sách và ma trận nêu ở mục 9, sau khi H2/H3 và kiểm tra tài nguyên đạt yêu cầu; H5 chỉ logic/offline/shadow plan.

Nếu chưa duyệt phần training, có thể chỉ duyệt H2–H3 trước. Không có approval ngầm từ việc hết thời gian chờ hoặc từ việc loader đọc được checkpoint routing.
