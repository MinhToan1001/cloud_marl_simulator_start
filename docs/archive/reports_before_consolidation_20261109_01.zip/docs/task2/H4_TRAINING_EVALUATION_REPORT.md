# H4 Training và đánh giá placement

Đã hoàn thành **3 policy seeds × 300 episodes = 900 episodes**, không dùng routing checkpoint để pretrain. Final run: [results/task2/placement_v1_20261109_03](../../results/task2/placement_v1_20261109_03/). Data source **SIMULATED**, chỉ response profile low-load có dữ liệu thật.

## Runtime và training

Runtime `.venv-task2` cô lập, không system site-packages, được sao chép offline các dependency cần thiết từ package đã cài; không sửa global packages. `pip check`: No broken requirements found. [Freeze](../../results/task2/placement_v1_20261109_03/runtime-freeze.txt) và [resource precheck](../../results/task2/placement_v1_20261109_03/runtime.json). Code/normalization/action/reward/profile fingerprints được lưu và kiểm tra khi load.

Pilot 2 episode/seed trước run chính; elapsed cuối bao gồm pilot và main khoảng **153.12s**, nhỏ hơn cap 1800s. CPU một torch thread, hidden 32, Adam .0003, gamma .99, GAE .95, PPO clip .2, entropy .02, 4 update epochs, minibatch 64. Mỗi policy có ba actor-critic và optimizer riêng; actor input 123, output 4 có mask; critic cùng trunk.

Train workload seeds 1000–1299, validation 20001–20003; test 30001–30005. Validation có isolated RNG và chọn best, test không dùng để chọn checkpoint. Nguồn: [src/placement/training.py:193](../../src/placement/training.py#L193), [src/placement/training.py:173](../../src/placement/training.py#L173).

| Policy seed | Episodes | Best episode | Validation mean reward | Main elapsed s |
|---|---:|---:|---:|---:|
| 7 | 300 | 240 | 0.625590 | 49.562 |
| 17 | 300 | 180 | 0.643886 | 49.719 |
| 27 | 300 | 140 | 0.536810 | 49.656 |

Weights đã thay đổi ở cả ba workload models của mọi policy seed. Training seed 27 có validation biến động; vẫn được giữ trong báo cáo. `best.pt` chọn theo validation và `last.pt` chứa optimizer/RNG/history; chưa cung cấp CLI resume placement và không tuyên bố exact resume đã kiểm chứng cho module mới.

![Training](../../results/task2/placement_v1_20261109_03/figures/training_curves.png)

## Thiết kế đánh giá

6 scenarios stable/ramp-up/spike/recovery/periodic/shift × 5 workload seeds = **30 unique traces**. Có 60 baseline runs và 90 IPPO runs = **150 runs**. Baseline chỉ chạy một lần/trace; không nhân bản theo policy seeds để tạo pseudoreplication. Cùng demand, initial placements, cluster budgets, exogenous trace, validator/arbitration/cooldown và dispatcher cho mọi method.

RR quay cluster theo decision với same validator; LL chọn pressure/latency heuristic với hysteresis .1; IPPO phát cùng KEEP/MOVE interface. [Metadata/hash manifest](../../results/task2/placement_v1_20261109_03/evaluation/metadata.json), [traces](../../results/task2/placement_v1_20261109_03/evaluation/traces.json), [events](../../results/task2/placement_v1_20261109_03/evaluation/events.csv). Nguồn: [src/placement/experiments.py:31](../../src/placement/experiments.py#L31), [src/placement/policies.py:4](../../src/placement/policies.py#L4).

## Kết quả

Các số dưới đây là macro mean của từng run, cân bằng scenarios/workload seeds; IPPO còn lấy mean qua 3 policy seeds. P95/P99 là mean của các percentile từng run, không phải percentile của toàn bộ population trộn.

| Thuật toán | Throughput req/s | Mean ms | P95 ms | P99 ms | Error % | SLO violation % | Completed moves |
|---|---:|---:|---:|---:|---:|---:|---:|
| round_robin | 60.384 | 157.00 | 780.48 | 1320.23 | 5.508 | 23.440 | 11.500 |
| least_loaded | 61.553 | 105.90 | 479.61 | 858.20 | 3.688 | 19.127 | 9.867 |
| ippo | 60.172 | 170.11 | 886.38 | 1492.69 | 5.613 | 23.645 | 10.078 |


IPPO có số migration thấp hơn Round Robin, nhưng **kém cả hai baseline về các chỉ số hiệu năng tổng hợp** trong ma trận cuối này. Validation reward cải thiện không chứng minh khả năng generalize: validation hiện chỉ dùng mixed workload, trong khi testing có sáu scenarios. Không chọn bỏ seed/scenario hoặc tune bằng held-out outcomes để kết luận MARL thắng. Kết quả từng scenario có thể khác: xem [comparison.csv](../../results/task2/placement_v1_20261109_03/evaluation/comparison.csv) và [paired_differences.csv](../../results/task2/placement_v1_20261109_03/evaluation/paired_differences.csv).

![Comparison](../../results/task2/placement_v1_20261109_03/figures/placement_comparison.png)

`comparison.csv` tách policy-seed SD (mean qua workloads trước), workload-seed SD (mean qua policy seeds trước), valid sample counts. Với 3 policy seeds và 5 workload seeds, SD chỉ mô tả biến thiên, không phải bằng chứng thống kê mạnh hoặc kết quả hệ thống thật.

Latency population chỉ gồm completions; failure/unfinished báo riêng. SLO violations gồm errors và completions trễ deadline, denominator là resolved cohort; cuối run còn unfinished được báo censored. CPU/RAM means là trung bình ratios các cluster/tick, không trọng số theo phần cứng. Toàn bộ 150 runs đã kiểm tra request conservation, move accounting và SLO bounds.

## Giới hạn nghiên cứu

Đa số workload thí nghiệm vượt miền low-load thật; capacity/background/WAN/readiness/availability và hai workload bổ sung là simulated assumptions. CPU purged relative error còn lớn; chưa có external calibration validation. Không dùng throughput/p99 ở bảng này khẳng định hiệu năng OpenStack/AWS thật. Nếu muốn tối ưu tiếp, cần tập validation rộng hơn, seed budget lớn hơn và dữ liệu mới trước tuning; không tune bằng held-out table vừa báo cáo.
