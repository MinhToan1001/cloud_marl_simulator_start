# Kiểm tra môi trường Task 2

Ghi chú cập nhật: đây là snapshot môi trường trước triển khai H2–H5. Runtime cô lập và kết quả thực hiện sau phê duyệt được ghi trong [báo cáo hiện tại](README.md); nội dung dưới đây giữ lại bằng chứng ban đầu.

Ngày kiểm tra: 09/11/2026, múi giờ Asia/Saigon. Phạm vi đã thực hiện: PHẦN 0 và H1. **Task 2 chưa hoàn thành toàn bộ**; H2–H5 chờ thống nhất thiết kế placement theo prompt.

## Kết luận

Workspace có đầy đủ simulator, IPPO, baseline, training/evaluation, hai checkpoint và bộ dữ liệu `cluster-a-real-003` để bắt đầu audit offline. Bộ test hiện có chạy thành công. Môi trường Python dùng chung system packages và có dependency conflicts; khả năng tái lập môi trường cần cải thiện trước lượt training nghiên cứu mới. SSH đến Ubuntu timeout nên chưa xác minh được trạng thái hạ tầng hiện tại.

Simulator hiện giải **request routing**, chưa giải microservice placement. Xem [H1_CODE_AUDIT.md](H1_CODE_AUDIT.md) và [PLACEMENT_DESIGN_PROPOSAL.md](PLACEMENT_DESIGN_PROPOSAL.md).

## Nguồn yêu cầu và phạm vi

- Workspace thực tế: `D:\HocTap\hk7\VMWare\cloud_marl_simulator_start`.
- Prompt được đọc: `C:\Users\ADMIN\.codex\attachments\72f40405-5426-451f-9dd6-cfdfcdd1beb0\Pasted text.txt`. Người dùng đã yêu cầu thực hiện prompt trong lượt trao đổi tiếp theo.
- ROADMAP thực tế: `C:\Users\ADMIN\Downloads\ROADMAP.docx`. Không có `docs/ROADMAP.docx` trong workspace; không tự giả định đó là đường dẫn tồn tại.
- Đã đọc nội dung OOXML, gồm đầy đủ Task 2. Không sửa DOCX; không đánh giá hình thức dàn trang. Bản trích Task 2 và hash hai đầu vào được lưu trong [evidence](evidence/h1_20261109_01/inputs.json).
- Prompt yêu cầu PHẦN 0 và H1 trước, thống nhất thiết kế placement rồi mới H2–H5. ROADMAP yêu cầu calibration, nhiều seed, schema sim-to-real; chưa có bằng chứng để đánh dấu các tiêu chí này hoàn thành.
- Không tìm thấy `AGENTS.md` tại workspace/các thư mục cha đã kiểm tra hoặc trong danh sách file dự án. Workspace không có thư mục `.git`; `git status --short` báo không phải Git repository. Không tạo Git repo mới.

## Bản đồ source và artifact đã xác minh

| Chức năng | Đường dẫn | Vai trò đã kiểm tra |
|---|---|---|
| Mô hình cluster | `src/cloud_sim/config.py`, `model.py` | Cấu hình CPU/RAM, capacity, FIFO, latency và accounting |
| Simulator | `src/cloud_sim/engine.py`, `workload.py` | Tick một giây; workload bốn phase; transition và summary |
| Baseline | `src/cloud_sim/policies.py`, `experiments.py` | Round Robin, Least Loaded và paired experiments |
| RL environment | `src/marl/env.py`, `config.py` | Ba agent, 26 features, 3 action routing mỗi agent, reward |
| IPPO | `src/marl/ippo.py` | Actor/critic riêng, PPO, GAE, đọc/ghi checkpoint |
| Training | `src/marl/training.py`, `src/cli/train.py` | Rollout, validation, resume và CLI |
| Evaluation | `src/marl/evaluation.py`, `src/cli/evaluate.py` | Cùng trace/engine cho RR, LL, IPPO; held-out seeds |
| Pipeline | `src/cli/pipeline.py` | Có bước training; không chạy pipeline trong audit này |
| API | `src/cloud_api/app.py`, `src/cli/serve.py` | API kết quả mô phỏng hiện có; không phải placement controller |
| Integration | `src/integration/{collector,parser,schema,preprocess,calibration,export}.py` | Thu metrics, schema, căn chỉnh, calibration và xuất dữ liệu |
| Sample API/load | `src/apps/sample_api/server.py`, `src/loadtests/{profile,locustfile}.py` | Ứng dụng và bộ tạo tải sẵn có; không chạy tải thật |
| Config chính | `configs/simulation.json`, `configs/marl.json` | Tài nguyên giả lập, workload, hyperparameters/reward |
| Config integration | `configs/integration/collector.example.json`, `load-safe.json`, `load-smoke.json` | Các file mẫu; không tự coi là cấu hình kết nối đã xác minh |
| Manifest | `deploy/k3s/{namespace,deployment,service,collector-rbac}.yaml` | File cục bộ; không apply lên Kubernetes |
| Checkpoint | `results/training/checkpoints/best.pt`, `last.pt` | Lần lượt episode 20 và 300; nạp được với routing v1 |
| Training artifacts | `results/training/{metadata.json,report.md,csv/,figures/}` | Kết quả mô phỏng cũ, giữ nguyên |
| Evaluation artifacts | `results/evaluation/{metadata.json,report.md,csv/,figures/}` | Kết quả routing cũ; 5 testing seeds, 5 scenarios, 3 methods |
| Baseline artifacts | `results/baseline/{metadata.json,report.md,csv/,figures/}` | Kết quả mô phỏng cũ, giữ nguyên |
| Dữ liệu thật được chỉ định | `data/runs/cluster-a-real-003/` | Có đủ client, collector, processed; chưa thực hiện H2 |
| Dữ liệu/lịch sử khác | `data/runs/cluster-a-real-001/`, `data/validation/`, `data/archive/af-experiments.zip`, `legacy/` | Không thay thế bộ dữ liệu chính bằng fixture hoặc dữ liệu lịch sử |

Danh sách đầy đủ file đã kiểm tra và SHA-256: [protected_before.json](evidence/h1_20261109_01/protected_before.json). Không duyệt `.ssh`, `.aws` hay nội dung secrets/private keys.

### Bộ dữ liệu chính có trên đĩa

| File trong `data/runs/cluster-a-real-003/` | Bytes |
|---|---:|
| `client/requests.csv` | 22973 |
| `client/workload.json` | 1048 |
| `collector/metrics.csv` | 29613 |
| `collector/raw.jsonl` | 93921 |
| `collector/session.json` | 1174 |
| `processed/aligned.csv` | 3691 |
| `processed/quality.json` | 1419 |

Đây là kiểm kê hiện diện/kích thước và hash, chưa phải kiểm định chất lượng dữ liệu H2. ROADMAP ghi nhận 152 request, 18 snapshot, 8 cửa sổ hợp lệ và dữ liệu low-load; cần kiểm tra lại từ nguồn ở H2, không coi các con số trong tài liệu là phép đo mới.

## Python và dependencies

Bằng chứng: [environment.json](evidence/h1_20261109_01/environment.json), [pip_check.txt](evidence/h1_20261109_01/pip_check.txt), `.venv/pyvenv.cfg`, `pyproject.toml`, `requirements.txt`, `requirements/integration.txt`.

| Thành phần | Kết quả |
|---|---|
| Interpreter được dùng | `.venv\Scripts\python.exe`, Python 3.11.5 |
| Venv | `include-system-site-packages = true` |
| Project distribution | `cloud-marl-simulator==1.0.0`; `cloud_sim`, `marl`, `integration` import được trước khi audit thêm `src` vào path |
| Core | NumPy 2.2.6, PyTorch 2.5.1+cu121, Gymnasium 1.3.0, matplotlib 3.10.6 |
| API | FastAPI 0.121.3, Uvicorn 0.38.0, httpx 0.28.1 |
| Tests/load support | pytest 9.0.2, Locust 2.47.0, PyYAML 6.0.3 |
| Build | setuptools 65.5.0, thấp hơn build requirement `setuptools>=68` trong `pyproject.toml:2` |
| `pip check` | Exit code 1; 10 dòng conflict trong file bằng chứng |

Các conflict gồm protobuf 7.34.1 với các package Google/gRPC/OpenTelemetry/Streamlit/YOLO, urllib3 2.6.3 với Kubernetes SDK 34.1.0, setuptools với yolov5. Đây là package hiện diện trong môi trường dùng chung, không phải tất cả đều là dependency của dự án. `src/integration/collector.py:26–38` dùng subprocess `kubectl`, không dùng Kubernetes Python SDK. Core tests vẫn pass, nhưng không thể kết luận toàn bộ environment dependency-consistent.

Đề xuất sau khi duyệt thiết kế: dùng venv mới cô lập cho thí nghiệm H4, kiểm tra `pip check`, lưu package manifest và interpreter cùng từng run. Không sửa/cài/hạ phiên bản package trong môi trường hiện tại ở lượt audit này. PyTorch đang có build CUDA nhưng đường inference/training hiện hành khởi tạo model trên CPU (`src/marl/ippo.py:68`); audit không thực hiện benchmark GPU hay đánh giá ngân sách training mới.

## Kiểm tra kết nối chỉ đọc

Thông tin do người dùng cung cấp: Ubuntu `nguyenminhtoan@192.168.107.128`; Cluster A `172.24.4.16`; key trên Ubuntu `~/.ssh/openstack_key`.

Lệnh đã thử:

```powershell
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=5 -o ConnectionAttempts=1 -o LogLevel=ERROR nguyenminhtoan@192.168.107.128 uname -srmo
```

- Trong sandbox: báo `Permission denied` ở bước mở kết nối. Đây không phải bằng chứng sai mật khẩu.
- Thử lại cùng lệnh với quyền mạng ngoài sandbox: `connect to host 192.168.107.128 port 22: Connection timed out`, exit 1.
- Timeout trước bước xác thực; chưa nhận password prompt và không gửi/đọc mật khẩu.
- Chưa vào được Ubuntu, vì vậy chưa kiểm tra SSH key trên Ubuntu, hop tới `172.24.4.16`, node Ready, Metrics API hoặc app hiện tại. Không suy ra Cluster A bị hỏng từ timeout của hop đầu.
- Username SSH của VM K3s chưa được xác minh; không mặc định đó là `ubuntu` hoặc username Ubuntu VMware.

Khi cần kiểm chứng live ở giai đoạn sau: xác minh lại hop đầu, để người dùng tự nhập mật khẩu nếu SSH yêu cầu, rồi chỉ đọc identity/status/metrics đã được cho phép trên Cluster A. Không chỉnh firewall, networking, host keys, khởi động VM hay restart service để xử lý timeout.

## Kiểm chứng và bảo toàn

- Lần kiểm tra trước khi thêm tài liệu: `.venv\Scripts\python.exe -m pytest -q` → **135 passed in 34.53s**.
- Audit bổ sung: 2 checkpoint nạp bằng `weights_only=True`, strict model restore và một tick routing inference; 27 tổ hợp joint action kiểm tra conservation và observation spaces. Đây là diagnostic H1, không phải đánh giá hiệu năng H4.
- Script tái lập: [audit_h1.py](audit_h1.py). Script từ chối output đã tồn tại và chỉ ghi trong `docs/task2/evidence/`; không gọi SSH, train, collector hay load generator.
- SHA-256 trước/sau audit: **163 file hiện có không đổi**; xem [preservation.json](evidence/h1_20261109_01/preservation.json). Cache Python không nằm trong manifest. Bản kiểm tra sau bộ test cuối được lưu cùng evidence.
- Bộ test hiện có chứa training nhỏ trong thư mục tạm của pytest để kiểm tra resume/weights. Không gọi training nghiên cứu mới và không ghi vào checkpoint sản phẩm cũ.

## Những điểm còn thiếu để hoàn thành Task 2

1. Phê duyệt thiết kế placement và thay đổi vai trò agent/state/action trước H2–H5.
2. Xác minh kết nối hai hop khi công việc live cần đến; chưa kiểm chứng quyền/readiness hiện tại.
3. H2: kiểm định raw/processed, scope pod/node/cluster, đơn vị và tải đã quan sát; chưa có calibration hoặc MAE/RMSE mới.
4. H3–H4: implement placement riêng, kiểm thử invariants, chuẩn bị venv/tài nguyên, training nhiều policy seed và evaluation trên trace ghép cặp.
5. H5: schema manifest có version, validator và operation plan chỉ đọc/shadow; không thực thi migration thật. B/C vẫn là simulated cho đến giai đoạn triển khai tương ứng trong ROADMAP.
