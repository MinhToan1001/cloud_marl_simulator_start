# H6 Đóng các thiếu sót Task 2B

**Cluster A đã phục hồi theo kiểm tra thủ công. Task 2B chưa nghiệm thu đầy đủ: A4 PENDING vì còn thiếu snapshot và bằng chứng theo checklist. Task 3 đã hoàn thành độc lập với A4/A5.**

| Hạng mục | Trạng thái | Kết quả |
|---|---|---|
| A1 | DONE | Phân tích đủ 6 scenario, policy/workload SD và paired differences từ run gốc |
| A2 | DONE | Tái tạo telemetry tài nguyên 150 run, xác minh summary khớp; không bịa trường bị thiếu |
| A3 | DONE | 3 checkpoint, CPU 1 thread, warmup 100, 1000 mẫu, mean/p95/p99 |
| A4 | PENDING | Cluster A Ready/SSH thành công theo kiểm tra thủ công; còn thiếu snapshot UTC, identity/inventory, raw Metrics API và shadow replay mới |
| A5 | PENDING | Chỉ có kế hoạch yêu cầu phê duyệt bằng văn bản; không phát tải thật |
| A6 | DONE | Phân biệt reward/randomization V1 với phần bổ sung V2/Task 4 |

## A1 Kết quả theo scenario

Số là mean từng run; SD policy được tính sau mean qua workload, SD workload sau mean qua policy. Không xem 15 run IPPO là 15 policy seed độc lập.

| Scenario | Method | Throughput ± SD policy / workload | P99 ms ± SD policy / workload | SLA resolved ± SD policy / workload |
|---|---|---|---|---|
| periodic | round_robin | 72.5600 ± N/A / 0.7094 | 1754.5600 ± N/A / 441.4224 | 0.2249 ± N/A / 0.0299 |
| periodic | least_loaded | 73.4533 ± N/A / 1.9694 | 1068.7800 ± N/A / 603.9700 | 0.1719 ± N/A / 0.0718 |
| periodic | ippo | 70.8607 ± 0.8498 / 1.5712 | 2405.8667 ± 499.1876 / 1004.5043 | 0.2571 ± 0.0305 / 0.0587 |

periodic, IPPO − round_robin: throughput -1.6993 req/s; p99 +651.3067 ms; SLA +0.0322. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


periodic, IPPO − least_loaded: throughput -2.5926 req/s; p99 +1337.0867 ms; SLA +0.0852. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| ramp_up | round_robin | 74.7378 ± N/A / 2.8371 | 1731.2400 ± N/A / 1055.4132 | 0.1697 ± N/A / 0.0838 |
| ramp_up | least_loaded | 76.4067 ± N/A / 1.3969 | 1161.9000 ± N/A / 466.4237 | 0.1139 ± N/A / 0.0239 |
| ramp_up | ippo | 74.5789 ± 1.6905 / 2.2477 | 2198.0667 ± 1054.4823 / 578.3716 | 0.1785 ± 0.0552 / 0.0472 |

ramp_up, IPPO − round_robin: throughput -0.1589 req/s; p99 +466.8267 ms; SLA +0.0089. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


ramp_up, IPPO − least_loaded: throughput -1.8278 req/s; p99 +1036.1667 ms; SLA +0.0647. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| recovery | round_robin | 68.0100 ± N/A / 1.0688 | 1166.6800 ± N/A / 395.5244 | 0.4351 ± N/A / 0.0347 |
| recovery | least_loaded | 69.1289 ± N/A / 0.5290 | 1010.6600 ± N/A / 378.7451 | 0.4124 ± N/A / 0.0232 |
| recovery | ippo | 66.7226 ± 2.0550 / 2.2260 | 1522.6800 ± 407.7395 / 560.2586 | 0.4563 ± 0.0274 / 0.0315 |

recovery, IPPO − round_robin: throughput -1.2874 req/s; p99 +356.0000 ms; SLA +0.0212. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


recovery, IPPO − least_loaded: throughput -2.4063 req/s; p99 +512.0200 ms; SLA +0.0438. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| shift | round_robin | 73.7256 ± N/A / 1.1275 | 1000.0200 ± N/A / 491.8217 | 0.1045 ± N/A / 0.0683 |
| shift | least_loaded | 73.9189 ± N/A / 1.2492 | 707.9400 ± N/A / 1273.7185 | 0.0487 ± N/A / 0.0581 |
| shift | ippo | 73.7611 ± 1.1489 / 1.0256 | 1109.9733 ± 762.1261 / 446.0805 | 0.0803 ± 0.0413 / 0.0275 |

shift, IPPO − round_robin: throughput +0.0356 req/s; p99 +109.9533 ms; SLA -0.0242. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


shift, IPPO − least_loaded: throughput -0.1578 req/s; p99 +402.0333 ms; SLA +0.0316. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| spike | round_robin | 49.2856 ± N/A / 3.7765 | 2231.1000 ± N/A / 869.4323 | 0.4683 ± N/A / 0.0742 |
| spike | least_loaded | 52.3556 ± N/A / 1.6490 | 1162.2000 ± N/A / 445.6883 | 0.3995 ± N/A / 0.0672 |
| spike | ippo | 51.1181 ± 0.8341 / 2.1373 | 1681.8267 ± 446.7367 / 408.1394 | 0.4426 ± 0.0200 / 0.0460 |

spike, IPPO − round_robin: throughput +1.8326 req/s; p99 -549.2733 ms; SLA -0.0257. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


spike, IPPO − least_loaded: throughput -1.2374 req/s; p99 +519.6267 ms; SLA +0.0431. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.

| stable | round_robin | 23.9878 ± N/A / 0.4830 | 37.7800 ± N/A / 0.1789 | 0.0040 ± N/A / 0.0089 |
| stable | least_loaded | 24.0544 ± N/A / 0.3418 | 37.7200 ± N/A / 0.1924 | 0.0012 ± N/A / 0.0026 |
| stable | ippo | 23.9889 ± 0.0195 / 0.4806 | 37.7133 ± 0.0945 / 0.1820 | 0.0040 ± 0.0008 / 0.0088 |

stable, IPPO − round_robin: throughput +0.0011 req/s; p99 -0.0667 ms; SLA -0.0000. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


stable, IPPO − least_loaded: throughput -0.0656 req/s; p99 -0.0067 ms; SLA +0.0028. Throughput dương tốt hơn; latency/SLA âm tốt hơn. Không quy thành một người thắng mọi mục tiêu.


## A2 Cân bằng tài nguyên

File timeseries gốc chỉ có arrival/processed/errors/waiting/placements, không có CPU/RAM. Vì vậy không thể tính đúng các std yêu cầu chỉ từ file đó. Closeout replay frozen V1 để ghi `offline/resource_timeseries_reconstructed.csv`; mọi summary gốc khớp trong 1e-9. Không huấn luyện hoặc sửa file gốc.

| Method | CPU usage std | RAM usage std | CPU reservation std | RAM reservation std | CPU mean | RAM mean | Waste |
|---|---:|---:|---:|---:|---:|---:|---:|
| round_robin | 0.177752 | 0.062582 | 0.102535 | 0.128169 | 0.528023 | 0.305491 | 0.381419 |
| least_loaded | 0.129023 | 0.060231 | 0.099083 | 0.123853 | 0.526926 | 0.299507 | 0.357060 |
| ippo | 0.181311 | 0.060748 | 0.099236 | 0.124045 | 0.522047 | 0.301541 | 0.368799 |

## A3 Thời gian inference

| Policy seed | Mean ms | P95 ms | P99 ms |
|---|---:|---:|---:|
| 7 | 1.5659 | 2.5586 | 4.7292 |
| 17 | 1.3123 | 1.8850 | 2.8848 |
| 27 | 1.2143 | 1.7958 | 3.1852 |

Đây là benchmark local CPU, không phải latency controller/live Kubernetes; tải máy có thể ảnh hưởng tail. Cấu hình máy và phạm vi đo ở `offline/inference.json`.

## A4 và A5

Cluster A đã khởi động và phục hồi theo **kiểm tra thủ công do người dùng cung cấp**. Không còn xem Cluster A là offline. Nguyên nhân người dùng xác định: VM `k3s-a` từng SHUTOFF, sau khi bật lại K3s phục hồi. Nguồn REAL / USER_REPORTED_MANUAL; agent chưa xác minh độc lập. Không có timestamp UTC của các lệnh gốc; thời gian ghi nhận không được dùng thay giờ đo.

| Kết quả thủ công | Giá trị người dùng báo |
|---|---|
| Node | `k3s-a` Ready, `v1.37.2+k3s1` |
| CoreDNS | 1/1 Running; Deployment Available 1/1 |
| Metrics Server | 1/1 Running |
| Local Path Provisioner | 1/1 Running |
| Calibration workload | 1/1 Running ở lần kiểm tra trước; chưa xác nhận lại trong snapshot mới |
| Node CPU | 196m (9%) |
| Node RAM | 1180Mi (60%) |
| SSH | Ubuntu VMware, user `stack` → `ubuntu@172.24.4.16`: thành công theo người dùng |

A4 = **PENDING — chờ hoàn thiện bằng chứng**, chưa DONE. Các số liệu trên xác nhận phục hồi ở mức báo cáo thủ công, chưa thay thế snapshot/identity/inventory và shadow replay. Không suy allocatable/capacity từ phần trăm CPU/RAM đã làm tròn, không coi Pod Running là bằng chứng EndpointSlice Ready phục vụ request.

| Checklist A4 | Bằng chứng hiện có | Còn thiếu để nghiệm thu |
|---|---|---|
| Node và timestamp UTC | Tên, Ready, version do người dùng báo | Node JSON, UID, allocatable/conditions và capture UTC |
| Namespace `cloud-calibration` | Workload calibration được báo ở lần trước | Namespace JSON và trạng thái ở snapshot mới |
| Pod/Deployment identity | CoreDNS Available, workload Running ở mức mô tả | UID, ownerReferences Deployment → ReplicaSet → Pod; identity calibration hiện tại |
| Reservation toàn cụm | Chưa có inventory mới | Toàn bộ Pod requests/limits, init/sidecar/overhead để tính reservation |
| Metrics API | Metrics Server Running; node CPU/RAM do người dùng báo | Phản hồi raw node/pod metrics có timestamp/window và mapping UID |
| Shadow replay V1 | Chưa chạy trên snapshot mới | Replay schema placement-v1, feature availability và readiness report |

Chẩn đoán quyền key/sudo trước đây được giữ làm lịch sử, không dùng để kết luận Cluster A offline sau phục hồi. Các file `connectivity.json`, `closeout_audit.json` và `REPORT.md` trong run closeout cũ giữ nguyên trạng thái tại lần kiểm tra trước; cập nhật hiện hành ở [A4_STATUS.json](A4_STATUS.json) và bản ghi thủ công bên dưới, không sửa kết quả lịch sử. Không thay SSH key, sudoers hoặc cấu hình OpenStack. B/C vẫn thiếu hạ tầng thật, vì vậy `closed_loop_ready=false` kể cả khi A4 sau này đủ bằng chứng. A5 vẫn PENDING, chưa phát tải thật.

[Bản ghi kiểm tra thủ công](../../results/task2/placement_v1_20261109_03_closeout/manual_recovery_20261109_01/manual_observation.json). [Kế hoạch A5](A5_LOAD_TEST_APPROVAL_REQUEST.md).

## A6 Phần đã có và còn thiếu

V1 đã có success, latency/SLO, error, SLO violation, resource waste, migration/overlap cost, failed moves; randomization CPU factor, background CPU, network factor, readiness và faults. V1 actor nhìn toàn bộ 123 features, chưa phải actor local/critic global CTDE.

V2 bổ sung DAG, bốn mục tiêu gồm cân bằng CPU/RAM, traffic bytes/cost theo cạnh, ma trận RTT/bandwidth, CPU/RAM capacity randomization, bandwidth jitter, và schema tách actor/critic. Các miền randomization vẫn ASSUMPTION(SIMULATED), chưa được xác minh thực nghiệm. MAPPO/MADDPG/QMIX training, GA/Single-Agent RL/K8s-default-like benchmarks và nhiều controlled DAG đồng thời để Task 4/5.

Calibration vẫn profile V1 low-load, CPU purged relative MAE 60,86%; maximum capacity null. Không có profile mới vì A5 chưa được duyệt/chạy.

## Bằng chứng và tái hiện

[Closeout artifacts](../../results/task2/placement_v1_20261109_03_closeout/), source `src/cli/task2b.py`; `python -m cli.task2b --output <thư mục mới>` tạo stage offline mới và từ chối ghi đè. Seed/trace/config/code fingerprints, runtime freeze, JUnit được lưu cùng run.

## Diễn giải A1 theo paired mean

Các nhận xét sau so với baseline trong cùng scenario/trace; chưa phải kết luận có ý nghĩa thống kê.

- periodic, IPPO so với round_robin: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- periodic, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- ramp_up, IPPO so với round_robin: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- ramp_up, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- recovery, IPPO so với round_robin: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- recovery, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- shift, IPPO so với round_robin: throughput tốt hơn, p99 kém hơn, SLA tốt hơn.
- shift, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- spike, IPPO so với round_robin: throughput tốt hơn, p99 tốt hơn, SLA tốt hơn.
- spike, IPPO so với least_loaded: throughput kém hơn, p99 kém hơn, SLA kém hơn.
- stable, IPPO so với round_robin: throughput tốt hơn, p99 tốt hơn, SLA tốt hơn.
- stable, IPPO so với least_loaded: throughput kém hơn, p99 tốt hơn, SLA kém hơn.

Kiểm toán cuối: 232 file gốc khớp hash; xem `closeout_audit.json`. `junit.xml` là bản sao bộ regression thực 206 test (156 cũ + 50 V2); A4 hiện PENDING sau báo cáo phục hồi thủ công; chưa có snapshot fresh hoặc shadow replay mới đủ bằng chứng. Kết quả kiểm toán/JUnit nêu trên là lần nghiệm thu trước, không phải lần chạy mới.
