"""Build the review packet from measured Task 2 artifacts (no training/network)."""
import argparse
import csv
import json
from pathlib import Path
import statistics
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT/"docs/task2"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def source(path, token):
    lines = (ROOT/path).read_text(encoding="utf-8").splitlines()
    line = next(i for i, value in enumerate(lines, 1) if token in value)
    return f"[{path}:{line}](../../{path}#L{line})"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    run = args.run.resolve()
    rel = run.relative_to(ROOT).as_posix()
    link = "../../"+rel
    cal, profile = read(run/"calibration/calibration.json"), read(run/"calibration/profile.json")
    purge = read(run/"calibration/purged_validation.json")
    training, evaluation, shadow = read(run/"training/manifest.json"), read(run/"evaluation/metadata.json"), read(run/"shadow/readiness.json")
    schema, config = read(run/"schema.json"), read(run/"placement_config.json")
    suites = list(ET.parse(DOCS/"evidence/task2-tests-final.xml").getroot().iter("testsuite"))
    tests = sum(int(s.attrib['tests']) for s in suites)
    assert all(int(s.attrib['failures']) == 0 and int(s.attrib['errors']) == 0 for s in suites)
    with (run/"evaluation/summary.csv").open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    means = {}
    for method in ("round_robin", "least_loaded", "ippo"):
        group = [r for r in rows if r['method'] == method]
        means[method] = {k: statistics.mean(float(r[k]) for r in group) for k in ("throughput_rps", "latency_mean_ms", "latency_p95_ms", "latency_p99_ms", "error_fraction", "slo_violation_fraction_resolved", "completed_moves", "cpu_utilization", "memory_utilization", "resource_waste_fraction")}
    table = "| Thuật toán | Throughput req/s | Mean ms | P95 ms | P99 ms | Error % | SLO violation % | Completed moves |\n|---|---:|---:|---:|---:|---:|---:|---:|\n"
    for name, values in means.items():
        table += f"| {name} | {values['throughput_rps']:.3f} | {values['latency_mean_ms']:.2f} | {values['latency_p95_ms']:.2f} | {values['latency_p99_ms']:.2f} | {100*values['error_fraction']:.3f} | {100*values['slo_violation_fraction_resolved']:.3f} | {values['completed_moves']:.3f} |\n"
    h2 = f"""# H2 Phân tích dữ liệu và calibration

Đã chạy pipeline cục bộ trên bộ dữ liệu REAL `cluster-a-real-003`. Có profile đáp ứng CPU/RAM/latency ở tải thấp và đánh giá sai số khi replay simulator theo cùng số request/cửa sổ. **Maximum capacity, saturation threshold và queue capacity chưa xác định. CPU fit còn bất định lớn.**

Nguồn: [calibration.json]({link}/calibration/calibration.json), [profile.json]({link}/calibration/profile.json), [full simulator replay]({link}/calibration/full_simulator_low_load_replay.csv), [purged validation]({link}/calibration/purged_validation.json). Mã: {source('src/placement/calibration.py', 'def calibrate_run')}, {source('src/placement/calibration.py', 'def replay_pod_window')}.

## Chất lượng và nguồn dữ liệu

- Đọc lại {cal['snapshot_count']} raw snapshot và tái tạo {cal['record_count']} metrics records; tất cả typed fields khớp CSV cũ, gồm identity/source/run/workload hash. Int `0` và float `0.0` được so theo giá trị kiểu schema, không so chuỗi JSON.
- {cal['request_count']} request phía client, {cal['client_failures']} lỗi. Có {cal['aligned_windows']} cửa sổ hợp lệ và {len(cal['rejected_windows'])} cửa sổ loại: 1 warmup, 5 không có complete latency window, 4 reused cached resource sample.
- Cùng pod UID, cùng cấu hình work và budget: CPU limit {profile['pod_budget_cpu_cores']} cores, RAM limit {profile['pod_budget_memory_bytes']} bytes = 96 MiB. Node capacity 2 cores là scope khác, không thay vào mẫu app pod.
- Timestamps có timezone UTC; client bắt đầu {cal['client_start_utc']}, request cuối {cal['last_client_request_utc']}. Raw snapshots từ {cal['first_snapshot_utc']} đến {cal['last_snapshot_utc']}; collection còn kéo dài sau tải.
- Tải quan sát {profile['observed_rps_range'][0]:.4f}–{profile['observed_rps_range'][1]:.4f} req/s; CPU {cal['cpu_usage_cores_range'][0]:.6f}–{cal['cpu_usage_cores_range'][1]:.6f} cores, tối đa {cal['cpu_limit_utilization_max_pct']:.2f}% pod CPU limit. Đây không phải dữ liệu gần bão hòa.
- Pod memory {cal['memory_usage_bytes_range'][0]}–{cal['memory_usage_bytes_range'][1]} bytes. Server mean latency theo cửa sổ {cal['server_latency_mean_ms_range'][0]:.3f}–{cal['server_latency_mean_ms_range'][1]:.3f} ms.
- Client mean {cal['client_latency_mean_ms']:.3f} ms, p95 {cal['client_latency_p95_ms']:.3f} ms gồm Windows/network/SSH. Không gộp với successful server work latency hoặc dùng trực tiếp làm WAN/base latency.

## Profile và replay

CPU response `idle + coefficient * completed_rps`, RAM và latency dùng hằng số trong miền low-load. Hệ số là mô tả quan sát, không phải định luật nhân quả hay ước lượng maximum service rate.

| Tham số | Giá trị | Phạm vi |
|---|---:|---|
| CPU idle response | {profile['response']['cpu_idle_cores']:.9f} cores | fitted pod window |
| CPU coefficient | {profile['response']['cpu_cores_per_rps']:.9f} cores/(req/s) | fitted pod window |
| RAM baseline | {profile['response']['memory_baseline_bytes']:.0f} bytes | constant low-load profile |
| Server latency mean | {profile['response']['service_latency_mean_ms']:.6f} ms | constant low-load profile |

Full simulator replay: A được đặt đúng scope pod limit, không background/WAN; B/C không có arrivals; phân bổ integer request theo thời lượng cửa sổ thật, tính CPU-window theo phần giây cuối. FIFO/conservation vẫn chạy, không thay completion bằng số giả. Mỗi fold fit các cửa sổ khác rồi replay cửa sổ held-out; [CSV]({link}/calibration/full_simulator_low_load_replay.csv) lưu arrivals/window/unfinished.

## Sai số và giới hạn thống kê

Validation cơ bản giữ lại 4 block liên tiếp, mỗi block 2 cửa sổ. Kiểm tra bổ sung loại mọi training window trong {purge['margin_s']} giây quanh held-out timestamps: max resource window {purge['max_resource_window_s']:.3f}s cộng alignment skew rồi làm tròn. Cách purge giảm leakage do CPU smoothing; vẫn chỉ có một run ngắn, không phải external validation độc lập.

| Đại lượng | Grouped MAE | Grouped RMSE | Purged MAE | Purged RMSE | Purged relative MAE |
|---|---:|---:|---:|---:|---:|
"""
    for key, label in (("cpu_usage_cores", "CPU cores"), ("memory_usage_bytes", "RAM bytes"), ("latency_mean_ms", "Server latency ms"), ("completed_rps", "Completed req/s"), ("error_rate_pct", "Error percentage points")):
        a, b = cal['full_simulator_low_load_errors'][key], purge['errors'][key]
        relative = f"{b['relative_mae_pct']:.3f}%" if b['relative_mae_pct'] is not None else "N/A zero denominator"
        h2 += f"| {label} | {a['mae']:.6f} | {a['rmse']:.6f} | {b['mae']:.6f} | {b['rmse']:.6f} | {relative} |\n"
    h2 += f"""
Mỗi chỉ số dùng n=8. Relative MAE = MAE / mean(abs(real)), không lấy MAPE trên các cửa sổ có zero denominator. Throughput/error khớp ở tải thấp chỉ phản ánh healthy flow và không có observed failure; không chứng minh saturation hoặc mô hình lỗi chính xác. CPU purged relative MAE khoảng {purge['errors']['cpu_usage_cores']['relative_mae_pct']:.1f}% cho thấy chưa có CPU calibration đáng tin để extrapolate.

So sánh mô hình cũ trong `old_model_analytic_low_load_errors` là expectation gần tải thấp với budget A cũ 2 cores/512 MB khác pod thật; chỉ dùng chẩn đoán scope mismatch, không dùng tuyên bố phần trăm cải thiện toàn cluster. Không suy memory-per-queued-request từ RAM-vs-RPS.

![Calibration heldout]({link}/figures/calibration_holdout.png)

## Kết quả áp dụng và việc cần thêm dữ liệu

Profile mới và config placement được ghi ở đường dẫn mới; config/dataset/routing checkpoints cũ giữ nguyên. Simulator placement dùng response profile nhưng capacity/CPU work cost, queue size, B/C, WAN/background/readiness và workload bổ sung vẫn là assumptions có nhãn SIMULATED trong [provenance]({link}/provenance.json). Không lấy extrapolation CPU limit làm maximum capacity thật.

Đã lập [CONTROLLED_LOAD_TEST_PLAN.md](CONTROLLED_LOAD_TEST_PLAN.md) nhưng không chạy live load test. Cần run độc lập có nhiều mức tải và cửa sổ ổn định dài hơn trước khi tuyên bố CPU/capacity accuracy hoặc saturation threshold.
"""
    (DOCS/"H2_CALIBRATION_REPORT.md").write_text(h2, encoding='utf-8')
    h3 = f"""# H3 Simulator placement và schema đã triển khai

Thiết kế đã được người dùng duyệt bằng yêu cầu thực hiện toàn bộ Task 2. Module mới `src/placement/` giải placement cho ba workload stateless mô phỏng; routing v1 trong `src/cloud_sim/` và `src/marl/` được giữ nguyên.

## State và action đã chốt

Version `{schema['env_version']}`, action kind `workload_placement`, observation **{schema['size']} features float32**, clip [0,10]. Ba agent `service_0/1/2`, mỗi agent sở hữu một workload. Actions: 0 KEEP, 1 MOVE_A, 2 MOVE_B, 3 MOVE_C. Không reuse output routing. Full ordered feature/units/scales/masks ở [schema.json]({link}/schema.json); schema SHA-256 `{training['schema_hash']}`.

Mỗi cluster có 16 features: availability, CPU/RAM capacity, CPU/RAM usage ratios, CPU/RAM reservation ratios, arrival/completion rates, mean/p95 latency, error fraction, resource/app validity, age và reservation validity. Mỗi service có 24 features: active/target/source one-hots, phase one-hot, timers, demand, requests, readiness, completed move count, validity và SLO. Ba own-workload one-hots kết thúc vector. Tổng 48+72+3=123; không có future-horizon feature. Nguồn: {source('src/placement/schema.py', 'def manifest')}, {source('src/placement/schema.py', 'def vectorize')}.

## Lifecycle và constraints

Transition chính: PREPARING giữ serving source → target Ready rồi GRACE phục vụ đích và drain backlog nguồn → giải phóng nguồn. Target failure/timeout hoặc failure trong grace rollback; backlog không teleport. Request còn lại khi gỡ nguồn trở thành release error; cuối episode giữ unfinished/censored rõ ràng.

Validator thuần dùng chung cho env RR/LL/IPPO và shadow, shadow thêm identity requirement. Kiểm tra legality, availability/freshness, workload identity, CPU/RAM headroom, reservations, cooldown, move-attempt cap và concurrency. Usage và reservations dùng max khi kiểm tra headroom để không cộng đúp workload; arbiter xoay service order, reserve target ngay khi nhận action. Proposed/validated/executed/reason đều được log. Nguồn: {source('src/placement/validator.py', 'def validate_packet')}, {source('src/placement/env.py', 'def step')}, {source('src/placement/env.py', 'def _lifecycle')}.

Physics một giây, decisions mỗi {config['decision_s']}s, readiness mặc định {config['readiness_s']}s có randomization, timeout {config['timeout_s']}s, grace {config['grace_s']}s, cooldown {config['cooldown_s']}s; concurrency {config['max_concurrent_moves']}. CPU response không được vượt workload CPU limit; tổng usage bị chặn bởi cluster budget. Queue FIFO hữu hạn, không drain ảo ở episode end. Đây là model giả định ở tải cao; max concurrency thật của app và scheduler Kubernetes chưa được mô phỏng đầy đủ.

## Resource scope và randomization

Budgets A .5 cores/256 MiB, B .75 cores/384 MiB, C 1 core/512 MiB là resource pools mô phỏng, không phải capacity đo thật của nodes. Requests mỗi workload .1 core/64 MiB, CPU limit .25 core, work cost .005 core-seconds/request, queue limit 80 là config thử nghiệm. Profile CPU/RAM/server mean có nguồn Task 1 ở miền low-load; không áp nhãn REAL cho toàn physics.

Config domain randomization: CPU performance factor {config['capacity_factor']}, background CPU fraction {config['background_fraction']}, network factor {config['network_factor']}, readiness factor {config['readiness_factor']}; faults hữu hạn theo seed. Trace arrivals, background, availability, network và readiness được tạo trước độc lập policy RNG, hash cùng body; mọi method replay cùng trace. Nguồn: {source('src/placement/trace.py', 'def make_trace')} và [config/provenance]({link}/provenance.json).

## Reward, metrics và kiểm thử

Shared reward gồm success, mean latency/SLO, errors, resolved SLO violations, reserved-resource waste, accepted move/overlap cost và failed moves. Cuối episode thêm unfinished penalty. Fraction trong decision window dùng arrivals cộng queue đầu window; SLO report dùng resolved cohort, unfinished báo censored. Coefficients cố định trong config trước held-out test; không tune bằng test. Nguồn: {source('src/placement/env.py', 'def step')}, {source('src/placement/env.py', 'def summary')}.

Metrics gồm completion mean/p95/p99 histogram, throughput, errors theo loại, unresolved queue, CPU/RAM usage/reservation, waste, migration counts/latency/downtime, moves/phút và dwell approximation. Đọc histogram cùng failures/unfinished để tránh survivor bias. Mean dwell = tổng service-time / (completed moves + initial 3 intervals), là tóm tắt có cả boundary intervals, không phải phân phối dwell đầy đủ.

Bộ test hiện tại **{tests} passed**, gồm 135 test cũ và 21 test placement mới; [JUnit](evidence/task2-tests-final.xml). Tests kiểm readiness/overlap/release, preparation và grace rollback, timeout, unavailable service, shared arbitration, resource rejection, CPU limit, accounting mọi scenario, mask/GAE/PPO update, schema parity, legacy rejection, mismatch feature unit/config, replay thực, reproducibility và shadow fallback. Không thêm executor Kubernetes hoặc HTTP controller vào Task 2.
"""
    (DOCS/"H3_IMPLEMENTATION_REPORT.md").write_text(h3, encoding='utf-8')
    h4 = f"""# H4 Training và đánh giá placement

Đã hoàn thành **3 policy seeds × 300 episodes = 900 episodes**, không dùng routing checkpoint để pretrain. Final run: [{rel}]({link}/). Data source **SIMULATED**, chỉ response profile low-load có dữ liệu thật.

## Runtime và training

Runtime `.venv-task2` cô lập, không system site-packages, được sao chép offline các dependency cần thiết từ package đã cài; không sửa global packages. `pip check`: No broken requirements found. [Freeze]({link}/runtime-freeze.txt) và [resource precheck]({link}/runtime.json). Code/normalization/action/reward/profile fingerprints được lưu và kiểm tra khi load.

Pilot 2 episode/seed trước run chính; elapsed cuối bao gồm pilot và main khoảng **{training['training_wall_s']:.2f}s**, nhỏ hơn cap 1800s. CPU một torch thread, hidden 32, Adam .0003, gamma .99, GAE .95, PPO clip .2, entropy .02, 4 update epochs, minibatch 64. Mỗi policy có ba actor-critic và optimizer riêng; actor input 123, output 4 có mask; critic cùng trunk.

Train workload seeds 1000–1299, validation 20001–20003; test 30001–30005. Validation có isolated RNG và chọn best, test không dùng để chọn checkpoint. Nguồn: {source('src/placement/training.py', 'def train')}, {source('src/placement/training.py', 'def load_policy')}.

| Policy seed | Episodes | Best episode | Validation mean reward | Main elapsed s |
|---|---:|---:|---:|---:|
"""
    for row in training['runs']:
        h4 += f"| {row['policy_seed']} | {row['episodes']} | {row['best_episode']} | {row['best_score']:.6f} | {row['elapsed_s']:.3f} |\n"
    h4 += f"""
Weights đã thay đổi ở cả ba workload models của mọi policy seed. Training seed 27 có validation biến động; vẫn được giữ trong báo cáo. `best.pt` chọn theo validation và `last.pt` chứa optimizer/RNG/history; chưa cung cấp CLI resume placement và không tuyên bố exact resume đã kiểm chứng cho module mới.

![Training]({link}/figures/training_curves.png)

## Thiết kế đánh giá

6 scenarios stable/ramp-up/spike/recovery/periodic/shift × 5 workload seeds = **{evaluation['unique_trace_count']} unique traces**. Có 60 baseline runs và 90 IPPO runs = **{evaluation['run_count']} runs**. Baseline chỉ chạy một lần/trace; không nhân bản theo policy seeds để tạo pseudoreplication. Cùng demand, initial placements, cluster budgets, exogenous trace, validator/arbitration/cooldown và dispatcher cho mọi method.

RR quay cluster theo decision với same validator; LL chọn pressure/latency heuristic với hysteresis .1; IPPO phát cùng KEEP/MOVE interface. [Metadata/hash manifest]({link}/evaluation/metadata.json), [traces]({link}/evaluation/traces.json), [events]({link}/evaluation/events.csv). Nguồn: {source('src/placement/experiments.py', 'def evaluate')}, {source('src/placement/policies.py', 'class PlacementBaseline')}.

## Kết quả

Các số dưới đây là macro mean của từng run, cân bằng scenarios/workload seeds; IPPO còn lấy mean qua 3 policy seeds. P95/P99 là mean của các percentile từng run, không phải percentile của toàn bộ population trộn.

{table}

IPPO có số migration thấp hơn Round Robin, nhưng **kém cả hai baseline về các chỉ số hiệu năng tổng hợp** trong ma trận cuối này. Validation reward cải thiện không chứng minh khả năng generalize: validation hiện chỉ dùng mixed workload, trong khi testing có sáu scenarios. Không chọn bỏ seed/scenario hoặc tune bằng held-out outcomes để kết luận MARL thắng. Kết quả từng scenario có thể khác: xem [comparison.csv]({link}/evaluation/comparison.csv) và [paired_differences.csv]({link}/evaluation/paired_differences.csv).

![Comparison]({link}/figures/placement_comparison.png)

`comparison.csv` tách policy-seed SD (mean qua workloads trước), workload-seed SD (mean qua policy seeds trước), valid sample counts. Với 3 policy seeds và 5 workload seeds, SD chỉ mô tả biến thiên, không phải bằng chứng thống kê mạnh hoặc kết quả hệ thống thật.

Latency population chỉ gồm completions; failure/unfinished báo riêng. SLO violations gồm errors và completions trễ deadline, denominator là resolved cohort; cuối run còn unfinished được báo censored. CPU/RAM means là trung bình ratios các cluster/tick, không trọng số theo phần cứng. Toàn bộ 150 runs đã kiểm tra request conservation, move accounting và SLO bounds.

## Giới hạn nghiên cứu

Đa số workload thí nghiệm vượt miền low-load thật; capacity/background/WAN/readiness/availability và hai workload bổ sung là simulated assumptions. CPU purged relative error còn lớn; chưa có external calibration validation. Không dùng throughput/p99 ở bảng này khẳng định hiệu năng OpenStack/AWS thật. Nếu muốn tối ưu tiếp, cần tập validation rộng hơn, seed budget lớn hơn và dữ liệu mới trước tuning; không tune bằng held-out table vừa báo cáo.
"""
    (DOCS/"H4_TRAINING_EVALUATION_REPORT.md").write_text(h4, encoding='utf-8')
    h5 = f"""# H5 Tương thích sim to real ở chế độ offline shadow

Đã kiểm thử vector/action interface, validator và operation plan offline. **Closed-loop readiness = false**. Không gọi Kubernetes write API, không chạy migration, không đổi networking/DevStack/K3s hoặc tạo AWS resources.

## Kiểm tra đã thực hiện

- Manifest version `placement-v1`, {schema['size']} ordered features và action enum KEEP/MOVE_A/B/C dùng chung giữa env và adapter; normalization/masks/schema hash được kiểm tra trước inference.
- Routing `best.pt` bị loader placement từ chối; config/feature-unit mismatch cũng có negative tests. Code fingerprint đổi làm loader fail, kể cả tensor shape không đổi.
- Replay 18 snapshot REAL lịch sử của Cluster A tại capture clock, kiểm node identity/app-pod identity/UID và CPU/RAM units, giữ B/C unavailable/unknown. Suy active A từ pod/app đã xác minh; không suy Deployment identity từ prefix tên Pod.
- Chạy shadow cho cả ba policy seeds: 54 snapshot-policy pairs, 162 workload proposals, đều không thực thi operation. Các masks chỉ cho KEEP do thiếu mapping/inventory B/C; KEEP ở đây chứng minh fallback, không chứng minh policy tối ưu hoặc ready cho thực thi.
- Synthetic fixture kiểm kế hoạch sáu bước prepare → wait Ready/health → switch → grace → release, có rollback prerequisites. Fixture luôn mang nhãn simulated; operation plan có `executable=false` và module không có executor.
- Mọi policy dùng shared validator; shadow yêu cầu thêm Deployment identity verified, full reservation inventory và fresh metrics. Service không ánh xạ/cluster unavailable/missing data đều fail closed.

Nguồn: {source('src/placement/shadow.py', 'def archived_packets')}, {source('src/placement/shadow.py', 'def operation_plan')}, {source('src/placement/validator.py', 'def validate_packet')}, [readiness]({link}/shadow/readiness.json), [all-policy shadow matrix]({link}/shadow-matrix.json), [packets]({link}/shadow/archived_packets.json), [fixture plan]({link}/shadow/synthetic_fixture_plan.json).

## Những điều chưa được xác minh

1. SSH `nguyenminhtoan@192.168.107.128:22` kiểm tra lại vẫn timeout trước xác thực. Chưa vào Ubuntu/hop `172.24.4.16`, chưa xác nhận live node/service/metrics. Không đọc private key hay mật khẩu.
2. B/C chưa có hạ tầng thật theo phạm vi Task 2. MOVEs tới B/C chỉ được kiểm logic bằng simulated fixture.
3. Archive đã scrub Deployment/ownerReferences và chỉ chứa selected pods, không có cluster-wide reservations. Deployment mapping và toàn bộ headroom inventory chưa xác minh.
4. Hai workload mô phỏng thêm chưa có identity thật. Resource budgets/placement domain khác pod A thật; thêm valid masks không tự biến policy thành model đã validate ngoài miền train.
5. Profile latency/RAM chỉ low-load; CPU/capacity uncertainty không được giải quyết bằng schema parity.

Snapshot history không phải trạng thái fresh hôm nay. Readiness report phân biệt interface compatibility đã kiểm và real operational readiness chưa có. Các thiếu hụt trên thuộc dữ liệu/live verification cần cho giai đoạn controller sau, không được lấp bằng synthetic data gắn nhãn REAL.
"""
    (DOCS/"H5_SIM_TO_REAL_READINESS.md").write_text(h5, encoding='utf-8')
    report = f"""# Task 2 Kết quả calibration và placement IPPO

Đã thực hiện PHẦN 0 và H1–H5 theo phạm vi cục bộ/offline shadow được người dùng phê duyệt. Có simulator placement riêng, calibration profile, ba policy seeds mới, 150 lượt đánh giá và báo cáo sim-to-real. **Chưa có bằng chứng capacity tối đa hoặc closed-loop deployment readiness. CPU calibration chưa đủ ổn định để khẳng định accuracy ngoài miền low-load.**

## Những gì đã hoàn thành

| Hạng mục | Kết quả | Bằng chứng |
|---|---|---|
| H1 audit | routing v1 được phân biệt khỏi placement | [H1](../../../docs/task2/H1_CODE_AUDIT.md) |
| H2 calibration | raw replay khớp, 8 windows, temporal holdout và simulator replay | [H2](../../../docs/task2/H2_CALIBRATION_REPORT.md) |
| H3 implementation | 3 workload agents, 123 features, KEEP/MOVE, validator/lifecycle/masks | [H3](../../../docs/task2/H3_IMPLEMENTATION_REPORT.md) |
| H4 training | 3 seeds × 300 episodes, 30 traces, 150 evaluation runs | [H4](../../../docs/task2/H4_TRAINING_EVALUATION_REPORT.md) |
| H5 shadow | version checks/negative cases, 3-policy archived replay, no writes | [H5](../../../docs/task2/H5_SIM_TO_REAL_READINESS.md) |
| Tests | {tests} passed | [JUnit](../../../docs/task2/evidence/task2-tests-final.xml) |

## Kết quả cần đọc trước

RAM/latency low-load có response profile và error estimates; CPU temporal-purged relative MAE {purge['errors']['cpu_usage_cores']['relative_mae_pct']:.2f}% cho thấy dữ liệu còn yếu. Maximum capacity vẫn `null`, không extrapolate từ CPU thấp. Xem [calibration](calibration/calibration.json), [purged validation](calibration/purged_validation.json), [profile](calibration/profile.json).

So sánh sau đây là **SIMULATED placement**, không phải đo live OpenStack/AWS:

{table}

IPPO không thắng Least Loaded tổng thể; báo cáo giữ đủ seed/scenario. Các percentile là mean của từng run; xem [CSV đầy đủ](evaluation/comparison.csv) để đọc riêng biến thiên policy/workload seeds và [paired differences](evaluation/paired_differences.csv).

![Placement comparison](figures/placement_comparison.png)

## Kiểm tra sản phẩm

- [Config](placement_config.json), [schema](schema.json), [provenance](provenance.json), [runtime](runtime.json), [freeze](runtime-freeze.txt).
- [Training manifest](training/manifest.json), checkpoints [seed 7](training/seed_7/best.pt), [seed 17](training/seed_17/best.pt), [seed 27](training/seed_27/best.pt); từng thư mục còn có last.pt/training.csv/validation.csv.
- [Evaluation metadata](evaluation/metadata.json), [per-run summary](evaluation/summary.csv), [events](evaluation/events.csv), [timeseries](evaluation/timeseries.csv), [latency histograms](evaluation/latency_histogram.csv).
- [Shadow matrix](shadow-matrix.json), [readiness](shadow/readiness.json), [safety/preservation verification](verification.json).
- [Mã simulator](../../../src/placement/), [CLI](../../../src/cli/task2.py), [tests](../../../tests/placement/test_placement.py).

## Chạy lại

Từ workspace, dùng output mới để giữ nguyên mọi kết quả cũ:

```powershell
.\\.venv-task2\\Scripts\\python.exe -m cli.task2 --output results/task2/my_new_run
.\\.venv-task2\\Scripts\\python.exe docs/task2/purged_validation.py --run results/task2/my_new_run
.\\.venv\\Scripts\\python.exe -m pytest -q
```

CLI `--stage` cho phép calibrate/train/evaluate/shadow/plots riêng, mỗi stage từ chối ghi đè thư mục kết quả đã tồn tại. Runtime mới có thể dựng offline bằng [bootstrap_runtime.py](../../../docs/task2/bootstrap_runtime.py) khi các dependencies gốc hiện diện; [requirements/task2.txt](../../../requirements/task2.txt) liệt kê top-level dependencies để dựng trên máy khác. Model loader kiểm tra implementation fingerprint nên sửa physics/reward/schema cần run/checkpoint mới.

## Giới hạn còn lại

SSH Ubuntu timeout; chưa có live verification của A và B/C chưa triển khai. H5 chỉ logic/offline shadow, `closed_loop_ready=false`; không có operation thực thi. Chưa có external-run calibration, saturated-load data hoặc kiểm chứng CPU fit ổn định. Có [kế hoạch thu dữ liệu bổ sung](../../../docs/task2/CONTROLLED_LOAD_TEST_PLAN.md), chưa chạy tải thật.

Các draft `_01`/`_02` được giữ với `SUPERSEDED.md`; **run chính thức để kiểm tra là `{run.name}`**. Dataset, checkpoint routing và kết quả gốc không bị sửa hoặc ghi đè.
"""
    (run/"REPORT.md").write_text(report, encoding='utf-8')
    (DOCS/"README.md").write_text(f"""# Task 2 Calibration và placement MARL

Đã thực hiện PHẦN 0, H1–H5 trong phạm vi cục bộ/offline shadow. Người dùng đã duyệt tiếp tục toàn bộ Task 2; không còn chờ phê duyệt thiết kế. H1/proposal cũ được giữ làm lịch sử quyết định.

**Đọc một lần tại [báo cáo tổng hợp]({link}/REPORT.md).** Run cuối: `{rel}`.

| Tài liệu | Nội dung |
|---|---|
| [ENVIRONMENT_AUDIT.md](ENVIRONMENT_AUDIT.md) | Snapshot môi trường ban đầu và SSH timeout |
| [H1_CODE_AUDIT.md](H1_CODE_AUDIT.md) | Routing/IPPO/schema/checkpoint audit ban đầu |
| [H2_CALIBRATION_REPORT.md](H2_CALIBRATION_REPORT.md) | Data quality, replay, holdout/purged errors và giới hạn low-load |
| [H3_IMPLEMENTATION_REPORT.md](H3_IMPLEMENTATION_REPORT.md) | Placement schema/lifecycle/constraints và tests |
| [H4_TRAINING_EVALUATION_REPORT.md](H4_TRAINING_EVALUATION_REPORT.md) | 900 episodes, 3 policy seeds, 150 evaluation runs |
| [H5_SIM_TO_REAL_READINESS.md](H5_SIM_TO_REAL_READINESS.md) | Archived shadow, shared validator và giới hạn readiness |
| [CONTROLLED_LOAD_TEST_PLAN.md](CONTROLLED_LOAD_TEST_PLAN.md) | Kế hoạch lấy thêm dữ liệu, chưa thực thi |
| [PLACEMENT_DESIGN_PROPOSAL.md](PLACEMENT_DESIGN_PROPOSAL.md) | Thiết kế đã được cho phép triển khai |

{tests} tests pass. Checkpoint/dataset/kết quả routing gốc được bảo toàn. Có calibration profile low-load nhưng CPU purged error còn lớn, maximum capacity chưa xác định và closed-loop readiness false. IPPO không vượt Least Loaded tổng thể; báo cáo không che giấu kết quả này.

Không thay đổi DevStack/K3s/networking, không chạy tải thật, không sử dụng AWS. `.venv-task2` cô lập có `pip check` sạch. Các script audit/bootstrap/purged/build_reports tại đây chỉ thao tác cục bộ; CLI thực nghiệm ở `src/cli/task2.py`.
""", encoding='utf-8')
    print(f"Built H2-H5 and {run/'REPORT.md'}")


if __name__ == '__main__':
    main()
