# H5 Tương thích sim to real ở chế độ offline shadow

Đã kiểm thử vector/action interface, validator và operation plan offline. **Closed-loop readiness = false**. Không gọi Kubernetes write API, không chạy migration, không đổi networking/DevStack/K3s hoặc tạo AWS resources.

## Kiểm tra đã thực hiện

- Manifest version `placement-v1`, 123 ordered features và action enum KEEP/MOVE_A/B/C dùng chung giữa env và adapter; normalization/masks/schema hash được kiểm tra trước inference.
- Routing `best.pt` bị loader placement từ chối; config/feature-unit mismatch cũng có negative tests. Code fingerprint đổi làm loader fail, kể cả tensor shape không đổi.
- Replay 18 snapshot REAL lịch sử của Cluster A tại capture clock, kiểm node identity/app-pod identity/UID và CPU/RAM units, giữ B/C unavailable/unknown. Suy active A từ pod/app đã xác minh; không suy Deployment identity từ prefix tên Pod.
- Chạy shadow cho cả ba policy seeds: 54 snapshot-policy pairs, 162 workload proposals, đều không thực thi operation. Các masks chỉ cho KEEP do thiếu mapping/inventory B/C; KEEP ở đây chứng minh fallback, không chứng minh policy tối ưu hoặc ready cho thực thi.
- Synthetic fixture kiểm kế hoạch sáu bước prepare → wait Ready/health → switch → grace → release, có rollback prerequisites. Fixture luôn mang nhãn simulated; operation plan có `executable=false` và module không có executor.
- Mọi policy dùng shared validator; shadow yêu cầu thêm Deployment identity verified, full reservation inventory và fresh metrics. Service không ánh xạ/cluster unavailable/missing data đều fail closed.

Nguồn: [src/placement/shadow.py:22](../../src/placement/shadow.py#L22), [src/placement/shadow.py:82](../../src/placement/shadow.py#L82), [src/placement/validator.py:4](../../src/placement/validator.py#L4), [readiness](../../results/task2/placement_v1_20261109_03/shadow/readiness.json), [all-policy shadow matrix](../../results/task2/placement_v1_20261109_03/shadow-matrix.json), [packets](../../results/task2/placement_v1_20261109_03/shadow/archived_packets.json), [fixture plan](../../results/task2/placement_v1_20261109_03/shadow/synthetic_fixture_plan.json).

## Những điều chưa được xác minh

1. SSH `nguyenminhtoan@192.168.107.128:22` kiểm tra lại vẫn timeout trước xác thực. Chưa vào Ubuntu/hop `172.24.4.16`, chưa xác nhận live node/service/metrics. Không đọc private key hay mật khẩu.
2. B/C chưa có hạ tầng thật theo phạm vi Task 2. MOVEs tới B/C chỉ được kiểm logic bằng simulated fixture.
3. Archive đã scrub Deployment/ownerReferences và chỉ chứa selected pods, không có cluster-wide reservations. Deployment mapping và toàn bộ headroom inventory chưa xác minh.
4. Hai workload mô phỏng thêm chưa có identity thật. Resource budgets/placement domain khác pod A thật; thêm valid masks không tự biến policy thành model đã validate ngoài miền train.
5. Profile latency/RAM chỉ low-load; CPU/capacity uncertainty không được giải quyết bằng schema parity.

Snapshot history không phải trạng thái fresh hôm nay. Readiness report phân biệt interface compatibility đã kiểm và real operational readiness chưa có. Các thiếu hụt trên thuộc dữ liệu/live verification cần cho giai đoạn controller sau, không được lấp bằng synthetic data gắn nhãn REAL.
