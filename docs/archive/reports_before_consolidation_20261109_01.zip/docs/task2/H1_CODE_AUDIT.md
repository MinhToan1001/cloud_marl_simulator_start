# Audit Simulator và IPPO cho Task 2

Ghi chú cập nhật: đây là snapshot H1 trước khi người dùng cho phép triển khai toàn bộ Task 2. H2–H5 đã được thực hiện sau đó; xem [báo cáo hiện tại](README.md). Các kết luận routing/checkpoint trong audit này vẫn giữ nguyên.

Ngày 09/11/2026. Kết luận: **hệ thống hiện tại là bộ điều phối request theo tỷ lệ, không phải microservice placement**. Checkpoint hiện có tương thích routing v1, không thể dùng trực tiếp cho KEEP/MOVE trên Kubernetes. Chưa thay đổi production code, state/action/reward, configs hoặc checkpoint.

Đã hoàn tất PHẦN 0 và các mục audit H1 trong prompt. Thiết kế cần duyệt nằm ở [PLACEMENT_DESIGN_PROPOSAL.md](PLACEMENT_DESIGN_PROPOSAL.md). H2–H5 chưa thực hiện theo điểm kiểm soát của prompt.

## 1. Kiến trúc và đường đi của một quyết định

```text
simulation.json -> make_workload(seed) -> demand hiện tại
                                        |
                   +--------------------+---------------------+
                   |                                          |
       Dispatcher RR / Least Loaded                MultiClusterEnv + 3 IPPO policies
       cấp số request trực tiếp                    action -> ratios -> integer counts
                   |                                          |
                   +--------------------+---------------------+
                                        |
                         SimulationSession.step(demand, counts)
                                        |
                            3 Cluster.step(assigned)
                                        |
                        FIFO, processed/drop/queue, CPU/RAM/latency
```

Đường gọi baseline: `cloud_sim.engine.simulate():108–118` → `Dispatcher.allocate():17–40` → `SimulationSession.step():47–85` → `Cluster.step():33–65`. Đường MARL: `MultiClusterEnv.step():108–153` → cùng `SimulationSession.step()`. Không tồn tại class/method tên `Simulator.step()` trong source hiện tại; hai lớp engine/model trên là nơi thực hiện transition.

IPPO có ba actor-critic riêng, mỗi actor nhận 26 features và phát 3 logits (`marl/ippo.py`, `ActorCritic:43–61`, `IPPO.__init__:64–70`). Cả ba agent quan sát cả ba cluster; thứ tự được xoay để cluster của mình ở đầu (`marl/env.py`, `_observe:85–106`). Đây là independent policies với thông tin toàn cục, không phải ba policy chỉ nhìn local metrics.

## 2. State nội bộ và semantics tài nguyên

`Cluster` chỉ giữ `config`, FIFO `_arrivals` chứa timestamp giây và `second` (`cloud_sim/model.py:19–27`). `SimulationSession` giữ ba cluster, rows, timeseries, histogram, tổng received/processed/dropped (`engine.py:38–45`). `MultiClusterEnv` bổ sung workload, current second, routing ratios và episode reward (`env.py:62–83`). Không có service ID, Deployment/replica, vị trí workload, pending target, ready state, cooldown hay migration counter trong state này.

Các công thức hiện tại (`cloud_sim/config.py`, `ClusterConfig:21–60`):

```text
memory_slots = floor((memory_mb - idle_memory_mb) / memory_per_request_mb)
cpu_capacity = cpu_cores * requests_per_core
effective_capacity = min(capacity, floor(cpu_capacity), memory_slots)
max_queue = min(queue_limit, memory_slots - effective_capacity)
```

| Cluster | capacity hiệu dụng req/s | CPU giả lập | RAM giả lập MB | idle MB | max_queue request | base latency ms |
|---|---:|---:|---:|---:|---:|---:|
| A | 60 | 2 cores | 512 | 128 | 120 | 40 |
| B | 90 | 3 cores | 768 | 192 | 180 | 45 |
| C | 120 | 4 cores | 1024 | 256 | 240 | 50 |

Nguồn cấu hình: `configs/simulation.json:2–13`; giá trị suy ra đã được kiểm tra trong [routing_probe.json](evidence/h1_20261109_01/routing_probe.json). Tổng capacity 270 req/s là giả định mô hình, chưa phải capacity đo từ Cluster A/B/C thật.

Mỗi tick là một giây. Workload được tạo trước, bốn phase 45 giây, jitter ±15% có seed (`cloud_sim/workload.py:9–22`, `SimulationConfig.seconds:95–97`). Jitter chỉ randomize arrival; không randomize capacity, background load hay network.

Transition `Cluster.step()` (`model.py:33–65`): nhận tối đa `capacity + max_queue - queue_before`, drop phần vượt, phục vụ FIFO tối đa capacity. Latency của completion ở slot `k` là `wait_seconds*1000 + (k+1)*1000/effective_capacity + base_latency_ms`. CPU = `100*processed/cpu_capacity`; RAM = idle + `(processed+queue_after)*memory_per_request_mb`, tức đỉnh trước phục vụ, không phải average RAM. Không có CPU idle/background, app failure hoặc lỗi mạng; error là overflow drop.

`engine.py:71–72,92–93` kiểm tra conservation từng tick và cả run. Queue cuối được ghi `waiting_at_end`, không tự drain; latency chỉ thuộc request đã hoàn tất (`engine.py:87–105`). CPU/RAM summary là trung bình đều giữa cluster/tick (`engine.py:101–102`), không trọng số theo tổng cores/bytes.

## 3. Observation 26 chiều chính xác

Version: `parallel-ratios-v1`; `Box(low=0, high=10, shape=(26,), dtype=float32)` (`marl/env.py:16–17,50–54`). Mọi feature cuối cùng được clip vào `[0,10]`, không phải tất cả đều nằm trong `[0,1]`.

Gọi `C = sum(effective_capacity)`, `Q_i = max_queue_i`, `L = reward.latency_scale_ms` (mặc định 1000 ms), `t = second`, `T = len(workload)`. Với agent có cluster index `own`, ba block tám feature theo thứ tự `own`, `(own+1)%3`, `(own+2)%3` (`_observe:85–106`). Vì config theo thứ tự A/B/C:

| Agent | Index 0–7 | Index 8–15 | Index 16–23 |
|---|---|---|---|
| `cluster_A` | A | B | C |
| `cluster_B` | B | C | A |
| `cluster_C` | C | A | B |

Trong mỗi block bắt đầu tại `b`:

| Index | Feature | Công thức trước clip | Đơn vị gốc / nguồn | Khi reset |
|---|---|---|---|---|
| `b+0` | CPU utilization | `last_row.cpu_utilization_pct/100` | % từ `Cluster.step()` tick trước | 0 |
| `b+1` | Memory utilization | `last_row.memory_utilization_pct/100` | % peak RAM tick trước | `idle_memory_mb/memory_mb` |
| `b+2` | Backlog normalized | `current_queue/max(1,Q_i)` | request trong FIFO | 0 |
| `b+3` | Assigned normalized | `last_row.assigned/C` | số request gán ở tick trước | 0 |
| `b+4` | Mean latency normalized | `(last_row.latency_mean_ms or 0)/L` | ms, completed request tick trước | 0 |
| `b+5` | Load index | `(last_row.processed+current_queue)/effective_capacity_i` | request / req-per-tick | 0 |
| `b+6` | Capacity share | `effective_capacity_i/C` | capacity giả lập cố định | A=2/9, B=1/3, C=4/9 |
| `b+7` | Routing share | `ratios[i]` | tỷ lệ không đơn vị | 1/3 |
| `24` | Demand normalized | `workload[t]/C`, hoặc 0 sau hết trace | request hiện tại / req-per-tick | phụ thuộc workload hiện tại |
| `25` | Remaining fraction | `(T-t)/T` | tỷ lệ thời lượng còn lại | 1 |

Nguồn từng feature là `marl/env.py:86–105`, không phải collector hay Kubernetes API. Hàng metrics dùng tick đã qua, còn demand là arrival batch của tick sắp xử lý. `env.reset(options={'workload':...})` cho replay trace (`env.py:62–75`).

Các giới hạn sim-to-real từ schema này:

- Latency không có completion bị thay bằng 0, không có validity mask (`env.py:96`); không thể phân biệt thiếu metric và latency thật bằng 0.
- Capacity chuẩn hóa, max_queue và FIFO nội bộ không có adapter suy ra đáng tin cậy từ Kubernetes hiện tại (`config.py:45–60`, `env.py:86–102`, `integration/schema.py:51–75`).
- Remaining fraction biết trước độ dài episode; controller chạy liên tục không mặc nhiên biết thời điểm kết thúc (`env.py:102`).
- `MetricRecord` có version cho dữ liệu nhưng chưa có vectorizer chung với `_observe`; pipeline export/calibration không tạo observation placement (`integration/schema.py:32–75`, `integration/export.py:12–48`, `integration/calibration.py:29–100`). Version của metrics không thay thế version của policy observation.
- CPU/RAM node, pod budget và workload cost là các scope khác nhau. Manifest cục bộ chỉ định app một replica, requests 50m/32Mi, limits 250m/96Mi (`deploy/k3s/deployment.yaml:7,46–52`); không được dùng trực tiếp thay cho 2 cores/512 MB giả lập rồi tuyên bố đã calibrate. Manifest không chứng minh cấu hình live hiện tại.

## 4. Action thực sự làm gì

Mỗi agent dùng `Discrete(3)` (`env.py:53`):

| Mã | Tác động trước chuẩn hóa | Ý nghĩa |
|---|---|---|
| 0 | `log(ratio_i) -= action_step` | giảm trọng số routing tương đối |
| 1 | giữ `log(ratio_i)` | giữ trọng số của agent trước tác động agent khác |
| 2 | `log(ratio_i) += action_step` | tăng trọng số routing tương đối |

`MultiClusterEnv.step():116–124` cộng các delta vào log-ratios, clip log odds tương đối vào `[-8,0]`, softmax lại, rồi `ratios_to_counts():20–31` dùng largest remainder để bảo toàn integer demand. `action_step=0.03` (`configs/marl.json:18`). Đây không phải delta trực tiếp ±0.03 vào probability.

Ngay cả action 1 của một agent cũng không bảo đảm ratio của nó giữ nguyên nếu agent khác đổi action. Ba agent cùng 0, cùng 1 hoặc cùng 2 sẽ giữ cùng vector ratio vì delta chung bị triệt tiêu khi normalize. Tỷ lệ vẫn dương; rounding có thể cho một cluster 0 request ở demand thấp. Không có action hard-disable cluster hoặc move Deployment.

Diagnostic từ trạng thái reset, demand 270, một tick:

| Joint actions A/B/C | Ratios sau action | Counts A/B/C |
|---|---|---|
| 0/0/0 | 0.333333 / 0.333333 / 0.333333 | 90 / 90 / 90 |
| 1/1/1 | 0.333333 / 0.333333 / 0.333333 | 90 / 90 / 90 |
| 2/2/2 | 0.333333 / 0.333333 / 0.333333 | 90 / 90 / 90 |
| 2/1/0 | 0.343382 / 0.333233 / 0.323385 | 93 / 90 / 87 |

Bằng chứng: [routing_probe.json](evidence/h1_20261109_01/routing_probe.json), đủ cả 27 tổ hợp. Tất cả giữ tổng counts=270 và observation nằm trong space. Đây không phải thí nghiệm đánh giá policy hay dữ liệu thật.

**Không được ánh xạ action 0/1/2 thành MOVE_A/MOVE_B/MOVE_C.** Không có placement state/transition để chứng minh ánh xạ đó và còn thiếu KEEP/readiness/constraints. Kích thước output giống nhau trong một thiết kế khác cũng không chứng minh cùng ngữ nghĩa.

## 5. Reward

Reward team giống nhau cho cả ba agent (`env.py:128–150`). Mặc định từ `marl/config.py:10–24`, `configs/marl.json:20–23`:

| Thành phần | Công thức đóng góp mỗi tick |
|---|---|
| Throughput | `+2.0 * processed / C` |
| Latency | `-0.4 * min((latency_mean_ms or 0)/1000, 10)` |
| Error | `-4.0 * error_rate_pct/100` |
| Queue | `-0.5 * mean(queue_after_i/max(1,Q_i))` |
| Overload | `-0.2 * mean(max(0,cpu_pct_i-90)/10)` |
| Imbalance | `-0.3 * population_std((processed_i+queue_after_i)/capacity_i)` |
| Switching | `-0.1 * sum(abs(new_ratios-old_ratios))` |
| Terminal queue | `-1.0 * total_queue/max(1,sum(Q_i))` chỉ khi kết thúc workload tự nhiên |

Nguồn công thức: `env.py:131–141`; imbalance tính trong `engine.py:80–82`. Nếu truncate bởi `max_steps`, terminal queue term không được áp dụng (`env.py:126–139`), nên cần ghi rõ episode boundary khi đánh giá.

Reward có latency mean, overflow error và routing switching cost. **Switching cost không phải migration cost**: không có resource preparation, downtime, grace period, rollback hoặc deployment movement. Chưa có explicit SLO violation, p95/p99 reward, resource waste hay actual migration term. Overload/imbalance không thay thế các đại lượng này.

## 6. IPPO và training loop

- IDs theo cluster config: `cluster_A`, `cluster_B`, `cluster_C` (`env.py:50`). Mỗi model có trunk `26→32→32` với Tanh, actor `32→3`, critic `32→1`; **2052 parameters/agent** ở hidden size 32 (`ippo.py:43–57`, [checkpoints.json](evidence/h1_20261109_01/checkpoints.json)). Không weight sharing hoặc centralized critic; actor và critic của cùng agent dùng chung trunk.
- Optimizer Adam riêng, lr 0.0003, eps 1e-5 (`ippo.py:68–70`). Categorical sample lúc train, greedy hoặc sample lúc inference (`ippo.py:73–82`).
- Rollout collect một episode rồi update độc lập từng agent (`training.py:47–63,113–125`). Shared reward nhưng optimizer riêng. Chưa có action masks/placement conflict resolver.
- GAE bootstrap qua truncation, không bootstrap true termination; recursion dừng ở cả hai boundary (`ippo.py:28–40`). `collect_episode` lưu final observation value đúng cho transition cuối (`training.py:60–63`).
- PPO có clipped policy objective, value loss, entropy bonus, normalized advantages, minibatch shuffle và gradient clipping (`ippo.py:84–125`). `value_loss` đã có hệ số 0.5 trước khi nhân `value_coef`; effective coefficient theo config hiện tại là 0.25 trên squared error, cần giữ rõ khi so sánh implementation khác (`ippo.py:109–111`).
- Seed policy 7, 300 episode, train workloads 1000–1299; validation 20001/20002/20003; hidden 32, gamma .99, lambda .95, clip .2, 4 epochs, minibatch 64, validation interval 20 (`configs/marl.json:2–19`, `training.py:113–138`). Đây là **một policy initialization seed**, không phải ba seed độc lập chỉ vì có ba agent.
- Validation chọn best checkpoint theo mean step reward. Có thể chọn episode 0 nếu training không cải thiện (`training.py:38–44,94–112,126–135`). Validation sampling dùng isolated fixed torch RNG (`training.py:23–35`).
- Resume yêu cầu cùng simulation/hyperparameters, trừ tổng episode, và restore optimizer/RNG (`training.py:77–92`). Tests hiện có kiểm tra exact resume và weights thay đổi (`tests/marl/test_ippo.py`, `test_training_resume_matches_uninterrupted_and_updates_weights`). Không chạy resume vào artifact gốc trong audit.

## 7. Baseline có cùng bài toán không

**Có, trong phạm vi request routing. Không có baseline placement hiện tại.**

Round Robin phân số request đều và giữ cursor qua tick (`cloud_sim/policies.py:22–27`). Least Loaded cấp từng request theo `(full, estimated_finish, cluster_index)`, trong đó estimated finish = `(queue+allocated+1)/effective_capacity + base_latency_ms/1000` (`policies.py:29–37`). Vì vậy đây là heuristic backlog/capacity/latency, không chỉ chọn CPU thấp nhất.

`marl/evaluation.py:43–69` tạo một workload mỗi scenario/seed rồi replay cùng counts đầu vào cho cả ba method; chung `SimulationSession`/`Cluster`, config, tick, accounting và metrics. Kiểm tra tách train/validation/test seed ở `evaluation.py:44–47`. Hash trace/checkpoint lưu trong metadata (`evaluation.py:91–104`).

Giới hạn công bằng cần nêu: baseline chọn counts ngay lập tức, còn IPPO bị ràng buộc điều chỉnh log-ratio từng bước 0.03 và ratio dương (`policies.py:17–40` so với `env.py:116–124`). Chúng giải cùng routing objective trên cùng physics, nhưng khác control parameterization/khả năng phản ứng. Không được diễn giải khác biệt hiệu năng hoàn toàn là chất lượng học thuật toán. Khi làm placement phải xây lại baseline với cùng valid actions, cooldown, arbitration và quy tắc đo.

Kết quả có sẵn dùng 5 testing workload seeds × 5 scenarios × 3 methods; metadata chỉ có policy seed 7 (`results/evaluation/metadata.json`, các trường `testing_seeds`, `scenarios`, `policies`, `policy_seed`). Không coi đây là nhiều lần training độc lập. Không chạy lại H4 trong lượt này.

Metrics hiện có: mean/p95 completion latency, throughput, drop/error, CPU/RAM, imbalance, processed, dropped và waiting (`engine.py:94–104`, `experiments.py:18–22`). Chưa xuất p99, SLO violations, resource waste, migration count hay policy stability. Helper percentile có tham số fraction (`engine.py:14–24`) nhưng output summary chỉ gọi p95; không được tuyên bố đã có p99 chỉ vì helper hỗ trợ.

## 8. Đối chiếu checkpoint

Bằng chứng đọc trực tiếp: [checkpoints.json](evidence/h1_20261109_01/checkpoints.json). Mỗi file đã nạp bằng `torch.load(..., map_location='cpu', weights_only=True)`, `load_policy()`, strict state-dict restore và một tick inference chẩn đoán. Probe dùng greedy để kiểm tra tính hợp lệ, không thay đổi inference mode `sample` được lưu trong checkpoint.

| Thuộc tính | best.pt | last.pt |
|---|---|---|
| Episode / best episode | 20 / 20 | 300 / 20 |
| History rows | 20 | 300 |
| Schema / algorithm | 1 / IPPO | 1 / IPPO |
| Environment | parallel-ratios-v1 | parallel-ratios-v1 |
| Agents | cluster_A/B/C | cluster_A/B/C |
| Input / hidden / actor outputs | 26 / 32 / 3 | 26 / 32 / 3 |
| Current simulation/training config fingerprint | khớp / khớp | khớp / khớp |
| Routing load + one-step inference | pass | pass |
| Placement compatibility | **không** | **không** |

SHA-256:

```text
best.pt a6b191cf4b6b2c7583c8ac09dff562200be5e4015d21c3ea4b3107fb87166455
last.pt e8afb1f844bc09a59e6eafb9147439bfec1e0b8efe0e989eecd341c411adc38c
```

`read_checkpoint():161–168` kiểm tra schema/algorithm/env version; `load_policy():171–182` kiểm tra cluster resource config và IDs/tensor shapes thông qua restore. Chưa có manifest liệt kê thứ tự feature, đơn vị, normalization, action semantics, agent ownership hoặc hash transition/reward implementation. Nếu đổi nghĩa feature mà giữ version/shape, loader hiện tại không tự phát hiện. Placement cần version/schema manifest mới và từ chối checkpoint routing.

## 9. Phát hiện và phương án xử lý

| Mức | Phát hiện và bằng chứng | Phương án đề xuất, chưa implement |
|---|---|---|
| Chặn sim-to-real placement | Routing ratios, không workload placement state (`env.py:116–124`, `model.py:19–65`) | Tách môi trường placement, action KEEP/MOVE và workload lifecycle |
| Chặn reuse checkpoint | Input 26, output 3, routing v1; không có placement semantics (`ippo.py:43–49,161–182`) | Checkpoint/schema mới; training lại sau duyệt; giữ bản cũ |
| Cao | Thiếu availability/readiness/resource reservation/cooldown/rollback (`Cluster` và `MultiClusterEnv` state nêu ở mục 2) | Validator và transition lifecycle chung cho IPPO/RR/LL |
| Cao | Switching penalty đo ratio delta, thiếu SLO/waste/migration (`env.py:131–139`) | Reward placement có định nghĩa đo độc lập và cấu hình trọng số |
| Cao | Capacity cố định, CPU intercept 0, RAM peak, latency service-slot giả lập (`config.py:45–60`, `model.py:41–58`) | H2 xác minh scope/đơn vị và fit trong observed range; không suy capacity tối đa từ low-load |
| Cao | Chỉ một policy seed, kết quả cũ là routing (`results/training/metadata.json`, `evaluation.py:140`) | H4 nhiều policy seeds × paired test traces; không mặc định IPPO thắng |
| Trung bình | No p99/SLO/waste/migration/stability output (`engine.py:94–104`, `experiments.py:18–22`) | Completion histogram, failure/queue censoring và placement event logs |
| Trung bình | Baseline direct counts, MARL ratio slew (`policies.py:17–40`, `env.py:116–124`) | Cùng action interface/constraints cho nghiên cứu placement |
| Trung bình | Missing metric thành zero, horizon feature, schema manifest chưa đủ (`env.py:96,102`, `ippo.py:161–182`) | Validity masks/freshness, manifest versioned, loại future horizon khỏi live state |
| Vận hành | Shared site packages, pip conflicts, SSH timeout | Xem ENVIRONMENT_AUDIT; không tự sửa hạ tầng/dependencies hiện tại |

H1 chưa kết luận dữ liệu thật phù hợp để fit hệ số nào; đó là H2 sau khi duyệt thiết kế. Không chạy calibration helper tạo candidate mặc định: `integration/calibration.py:51–59` vẫn xuất CPU-limit extrapolation, và candidate capacity ở `:73–91` là observed lower bound có điều kiện, không tự chứng minh maximum capacity. Cần xem xét kỹ hai ý nghĩa này trong H2 trước khi dùng.

## 10. Kiểm chứng H1 và trạng thái bàn giao

- Tests hiện có: **135 passed in 34.53s** trước thay đổi tài liệu; bộ test cuối và JUnit được lưu trong evidence.
- Diagnostic 27 joint actions pass accounting/spaces. Hai checkpoint pass load/restore/inference cho routing v1.
- Script và evidence: [audit_h1.py](audit_h1.py), [evidence/h1_20261109_01](evidence/h1_20261109_01/).
- 163 file hiện có trong manifest không đổi sau audit. Không triển khai, restart, stress test, tạo AWS resource, sửa dataset/checkpoint hay training nghiên cứu.
- H1 hoàn tất kiểm tra cục bộ; PHẦN 0 có kết quả kiểm tra SSH nhưng kết nối chưa khả dụng. **Task 2 tổng thể đang ở checkpoint phê duyệt thiết kế**, chưa đạt tiêu chí calibration/multi-seed/sim-to-real trong ROADMAP.
