# Kiểm chứng bàn giao A → F

> Layout updated: executable commands use `python -m cli.<command>`; earlier pilot/smoke artifacts are stored in `data/archive/af-experiments.zip`. Original A-F/G delivery reports are retained verbatim in that archive.

Môi trường thực chạy: Windows/Python 3.11.5, PyTorch 2.5.1+cu121 nhưng sử dụng CPU một thread, Gymnasium 1.3.0, NumPy 2.2.6, FastAPI 0.121.3, Uvicorn 0.38.0, httpx 0.28.1, Matplotlib 3.10.6, pytest 9.0.2. Không dùng GPU hoặc cluster thật. `.venv` dùng system site packages vì pip bị chặn socket; cài dependency sạch qua mạng chưa kiểm chứng tại đây.

## Tests theo giai đoạn

Lần cuối trong pipeline smoke: **81 passed in 11.40s**. Tests sử dụng output tạm, không ghi đè kết quả bàn giao.

| Giai đoạn | File test | Số case | Nội dung |
|---|---|---:|---|
| A | test_simulator.py | 32 | FIFO/latency tính tay, conservation, tài nguyên, biên, seed, không nhìn trước |
| B | test_baselines.py | 11 | Paired workload, CSV tái lập, std, replay, legacy/zero plotting |
| C | test_marl_env.py | 15 | check_env, observation spaces, reset, action, reward, termination/truncation |
| D | test_ippo.py | 5 | GAE tính tay, tham số riêng, update thật, resume khớp tensor/log, validation RNG |
| E | test_evaluation.py | 2 | Seed split, fairness, conservation, tái lập, API tích hợp |
| F | test_api.py | 16 | Bốn endpoint, labels, kiểu số, filters, lỗi input/dataset, read-only, CORS |

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'
.\.venv\Scripts\python.exe -m pytest -q
Remove-Item Env:\PYTEST_DISABLE_PLUGIN_AUTOLOAD
```

## Training và resume thực

Đã smoke trước khi train. Hai pilot 300 episode/action_step=0.12 được giữ trong `results/training_greedy_pilot` và `results/training_large_step`; validation không chọn checkpoint đã học tốt hơn episode 0. Dựa trên validation, giảm action_step xuống 0.03, chạy 100 episode rồi **resume thật lên tổng 300**. Testing chưa được chạy lúc chọn cấu hình.

Run chính: 300 episode = 54.000 environment steps; training workload 1000–1299, policy seed 7, validation 20001–20003. Tổng thời gian thực 147,796 giây (đoạn 100 episode + đoạn resume, không gồm pilot). Best episode 20, mean step reward validation 0,5109455 so với ban đầu 0,4071912; last episode 300. Cả ba agent trong best có trọng số khác khởi tạo.

Training CSV 300 dòng; agent_training 900 dòng; validation 48 dòng (mốc 0 và mỗi 20 episode × 3 seed). Loss/entropy/reward hữu hạn. Best/last lưu model, optimizer, RNG, config và histories; load weights_only=True. Test resume khớp từng tensor và log với train liên tục tại ranh giới episode.

## Đánh giá và kiểm tra dữ liệu

Checkpoint khóa trước testing. Năm scenario × năm testing seed 30001–30005 × ba phương pháp = **75 run**. Recovery gồm Spike rồi Recovery.

| File evaluation/csv | Số dòng |
|---|---:|
| workload.csv | 2025 |
| cluster_metrics.csv | 18225 |
| timeseries.csv | 6075 |
| summary.csv | 75 |
| comparison.csv | 15 |
| paired_differences.csv | 50 |
| latency_histogram.csv | 36225 |

`src/cli/verify_results.py` kiểm tra conservation từng dòng, CPU/RAM/queue, assigned theo workload cho ba phương pháp, summary khớp raw metrics, mean/p95 khớp histogram và mean/std khớp run. Đã chạy lại toàn bộ evaluation trong thư mục tạm: **bảy CSV khớp byte**. Evidence: `data/validation/af-verification.json`.

20 PNG chính được xác nhận mở được, rộng ≥2000 px, cao ≥800 px, 200 DPI: baseline 7, training 5, evaluation 8. Đã xem trực quan các nhóm hình, nhãn simulation/đơn vị/legend. Hình vẽ từ CSV thực chạy.

## API và pipeline

`src/cli/verify_api.py` đã khởi động Uvicorn tạm trên loopback, gọi HTTP thật tới cả bốn endpoint, xác nhận 200/simulation labels; OpenAPI có bốn path; dừng server sau kiểm tra. Evidence: `data/validation/af-api_validation.json` và `.log`.

Đã chạy `python -m cli.pipeline --smoke --output results/pipeline_smoke` (run goc nam trong ZIP lich su): tự kiểm thử 81 cases, baseline, 2 episode IPPO, hai testing seed/scenario mixed, mọi hình/báo cáo. API khởi động riêng, không giữ server nền sau bàn giao.

```powershell
.\.venv\Scripts\python.exe -m cli.verify_results
.\.venv\Scripts\python.exe -m cli.verify_api
.\.venv\Scripts\python.exe -m cli.pipeline --smoke --output results/full_smoke_local
```

## File tạo/sửa và tương thích

Hash của `legacy/simulate.py`, `legacy/README.md`, ba CSV `legacy/output/` khớp bản đầu. Replay/plot schema cũ vẫn hoạt động. Lịch sử A+B: `validation-ab.md`; audit đầu vào: `audit.md`.

- Lõi: cập nhật `src/cloud_sim/config.py`, `engine.py`, `experiments.py`, `plotting.py`, `src/cli/plot.py` để dùng chung transition, aggregate ba policy và lọc scenario; giữ public simulate API.
- C/D: `src/marl/config.py`, `env.py`, `ippo.py`, `training.py`, `plotting.py`, `configs/marl.json`, cấu hình pilot và `src/cli/train.py`.
- E: `src/marl/evaluation.py`, `src/cli/evaluate.py`, CSV/report/PNG/metadata.
- F: `src/cloud_api/app.py`, `src/cli/serve.py`, API tests, `docs/api.md`.
- Bàn giao: `src/cli/pipeline.py`, `src/cli/verify_results.py`, `src/cli/verify_api.py`, `src/cli/package.py`, requirements đầy đủ/baseline, README và docs.

## Giới hạn

Không có test thất bại đang mở. Chưa chứng minh IPPO hội tụ, ý nghĩa thống kê hoặc thắng mọi baseline. Một training seed chính, chưa nhiều lần train độc lập. Chưa hiệu chỉnh cluster thật; error chỉ overflow, arrival batch, capacity cố định, không drain cuối trace và latency có censoring. React chỉ có hợp đồng tích hợp. Cài venv sạch qua mạng cần kiểm chứng trên máy cho phép tải package.
