# Sắp xếp source và bỏ file dư

Thư mục gốc giảm từ **19 xuống 5 file**: `README.md`, `pyproject.toml`, `requirements.txt`, `pytest.ini`, `.gitignore`. Mã nguồn được chia theo chức năng dưới `src/`; kết quả chính được tách thành `results/baseline/`, `results/training/`, `results/evaluation/`.

Toàn project giảm từ **333 xuống 153 file rời**, không tính venv/cache/metadata cài đặt; các file lịch sử được giữ trong một ZIP.

## File được dọn

- Bỏ 9 launcher ở gốc: `run_baselines.py`, `train_marl.py`, `evaluate_marl.py`, `plot_results.py`, `serve_api.py`, `run_pipeline.py`, `verify_api.py`, `verify_results.py`, `package_delivery.py`. Dùng `python -m cli.<command>`.
- Bỏ hai ZIP bàn giao cũ và hai file checksum tương ứng trong `dist/`; đây là các gói lặp lại source/kết quả đã có. Khi cần gói mới, chạy `python -m cli.package`.
- Bỏ `requirements-baseline.txt` lặp dependency. Dependency G chuyển vào `requirements/integration.txt`; file chính tham chiếu file này.
- Dọn cache Python/pytest và script tạm dùng cho lần di chuyển.
- Gom pilot, smoke, replay, legacy figures, demo và tài liệu lịch sử vào **một ZIP**, không để hàng chục thư mục chạy thử cạnh kết quả chính. Đã kiểm tra SHA-256 từng file trước khi gom; ZIP có **178 thành viên**, gồm cả báo cáo bàn giao gốc để đối chiếu.

## File và đường dẫn được cập nhật

| Thay đổi | Mục đích |
|---|---|
| Các package Python → `src/` | Một chỗ tìm code, các module vẫn chia theo chức năng |
| `pyproject.toml`, `pytest.ini`, requirements | Cài editable package và tìm source khi chạy tests |
| `src/cli/`, `src/cloud_api/app.py`, `src/loadtests/locustfile.py` | Sửa đường dẫn gốc, đường dẫn Locust, cách gọi subprocess và vị trí báo cáo kiểm tra |
| `results/csv`, `figures`, `metadata.json`, `report.md` → `results/baseline/` | Baseline cùng cấp training/evaluation, giữ nguyên byte |
| `simulate.py`, README cũ, `output/` → `legacy/` | Dữ liệu và simulator lịch sử ở cùng một chỗ |
| `DELIVERY.md`, `STAGE-G.md`, audit/validation → `docs/reports/` | Gom báo cáo; các bản đang đọc cập nhật link và lệnh |
| `tests/integration/test_cli.py`, tests dùng baseline/legacy | Kiểm tra 11 CLI thực, sửa đường dẫn dữ liệu fixture |
| README, mục lục docs, bản đồ project và hướng dẫn | Thống nhất layout, lệnh PowerShell và `PYTHONPATH` trên Ubuntu/K3s |
| `data/validation/` | Giữ bằng chứng kiểm tra cũ và ghi riêng kết quả sau sắp xếp |

## Bảo toàn và kiểm chứng

- **135 tests đạt trong 37,50 giây**, gồm 81 A–F và 54 integration. [JUnit](../../data/validation/tests.xml).
- **68 checksum khớp**, gồm kết quả chính, checkpoint best/last, legacy, source simulator/MARL, hai config chính và ZIP lịch sử. [Manifest](../../data/validation/preserved-files.json).
- Kiểm tra conservation, latency mean/p95, tổng hợp mean/std và 75 lượt đánh giá. Chạy evaluation kiểm chứng trong thư mục tạm: **7 CSV khớp byte**, 20 PNG chính hợp lệ. Không train lại. [Bằng chứng](../../data/validation/results.json).
- API chạy qua Uvicorn trên localhost: **4 endpoint và OpenAPI hợp lệ**, đã dừng server kiểm tra. [Bằng chứng HTTP](../../data/validation/api.json).
- G offline/localhost: 24 record fixture, 7 cửa sổ ghép, export 5.400 record simulation, 6 request HTTP thành công; real mode từ chối app local. Đầu ra smoke tạm được bỏ, giữ [bằng chứng nhỏ](../../data/validation/cluster-smoke.json).
- Đóng gói thử 153 file với CRC/SHA-256 manifest, xác nhận đủ source mới, legacy, checkpoint, kết quả và ZIP lịch sử. Gói thử được tạo trong thư mục tạm rồi bỏ để tránh thêm bản sao dư.

Logic mô hình, reward và cách chọn checkpoint giữ nguyên nội dung. Thay đổi API chỉ là đường dẫn đọc project sau khi chuyển vào `src/`. Chưa train lại MARL, chưa sửa React và chưa kết nối/đo Cluster A thật.

## Chạy sau khi tải bản mới

Từ thư mục gốc trên Windows, đăng ký lại đường dẫn source với môi trường đã có:

```powershell
.\.venv\Scripts\python.exe -m pip install -e . --no-deps --no-build-isolation
.\.venv\Scripts\python.exe -m cli.serve
```

Trên Ubuntu/K3s, collector chuẩn library có thể chạy không cần cài package vào hệ thống:

```bash
cd "$PROJECT_DIR"
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
python3 -m cli.cluster --help
```

Các lệnh khám phá, triển khai và thu metrics thật nằm ở [real-cluster-integration.md](../real-cluster-integration.md) và [k3s-deployment.md](../k3s-deployment.md). Không chạy lại pipeline training để thử collector.
