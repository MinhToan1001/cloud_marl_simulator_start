# Bàn giao Cloud MARL Simulator — A → F

> Layout updated: executable commands use `python -m cli.<command>`; earlier pilot/smoke artifacts are stored in `data/archive/af-experiments.zip`. Original A-F/G delivery reports are retained verbatim in that archive.

Đã hoàn thành simulator, baseline, môi trường ba agent, huấn luyện IPPO CPU, đánh giá nhiều seed và FastAPI theo phạm vi mô phỏng trên Windows. Không kết nối hoặc thay đổi OpenStack/K3s/AWS; không sửa React chưa có source. Mã và ba CSV gốc giữ nguyên SHA-256.

## Xem kết quả ngay

```powershell
.\.venv\Scripts\python.exe -m cli.serve
```

Mở `http://127.0.0.1:8000/docs`, hoặc đọc [báo cáo](../../results/evaluation/report.md), [biểu đồ tổng hợp](../../results/evaluation/figures/comparison.png), [so sánh scenario](../../results/evaluation/figures/scenario_comparison.png). API gắn nhãn simulation, không cần train lại.

## Kết quả thực chạy

Run chính: **300 episode, 54.000 steps trên CPU**, tổng 147,796 giây; có resume thật từ 100 lên 300. Best **episode 20**, chọn bằng validation 20001–20003, policy seed 7, training workload 1000–1299. Testing độc lập 30001–30005, năm scenario × ba phương pháp = **75 run**.

Trace hỗn hợp, mean ± sample std giữa năm testing seed:

| Phương pháp | Throughput req/s | Latency mean ms | Latency p95 ms | Error % |
|---|---:|---:|---:|---:|
| Round Robin | 169.80 ± 0.18 | 1031.26 ± 13.09 | 2837.44 ± 14.69 | 9.91 ± 0.17 |
| Least Loaded | 173.25 ± 0.34 | 1193.22 ± 14.63 | 2901.78 ± 6.94 | 8.40 ± 0.27 |
| MARL (IPPO) | 171.47 ± 1.52 | 1068.19 ± 85.94 | 2839.33 ± 41.06 | 9.26 ± 0.56 |

MARL tăng throughput 1,67 req/s, giảm error 0,65 điểm phần trăm so với Round Robin, nhưng latency mean cao hơn 36,93 ms. So với Least Loaded, MARL throughput thấp hơn 1,78 req/s, error cao hơn 0,86 điểm phần trăm, latency mean thấp hơn 125,03 ms. **Không kết luận MARL thắng mọi tiêu chí.** CPU/RAM, imbalance, completed và waiting có trong report/CSV.

## Thành phần bàn giao

| Giai đoạn | Thành phần |
|---|---|
| A | JSON, bốn pha/seed, FIFO hữu hạn, CPU/RAM, request/latency và invariants |
| B | Hai baseline cùng workload, năm seed, CSV, bảy PNG/report |
| C | Ba agent, 26 feature, action chuẩn hóa 100%, reward/config, Gymnasium adapter/tests |
| D | Ba actor-critic/optimizer riêng, CPU, smoke, best/last/RNG resume, log và năm learning curves |
| E | Năm testing seed độc lập, năm scenario, 75 run, mean/std/paired differences, tám PNG/report |
| F | Bốn FastAPI GET endpoints, filters/phân trang, labels, OpenAPI và React/CORS docs |

Checkpoint: [best.pt](../../results/training/checkpoints/best.pt), [last.pt](../../results/training/checkpoints/last.pt). Log: `results/training/csv/`; dữ liệu cuối: `results/evaluation/`. Pilot action_step 0.12 nằm trong `data/archive/af-experiments.zip`, với tên thành viên `results/training_greedy_pilot/`, `results/training_large_step/`. Cấu hình cuối step 0.03 được chọn bằng validation trước testing.

## Kiểm chứng

- **81 tests đạt**, gồm Gymnasium, GAE, RNG, update thật và resume khớp từng tensor/log.
- Pipeline smoke chạy trọn vẹn; các thành phần đầy đủ cũng đã chạy trên dữ liệu chính.
- Conservation, mean/p95 từ histogram và mean/std được đối chiếu cho 75 run; evaluation lặp có bảy CSV khớp byte.
- 20 PNG chính 200 DPI, đã kiểm tra mở và xem trực quan các nhóm.
- HTTP thật qua Uvicorn: bốn endpoint/OpenAPI hợp lệ; server kiểm thử đã dừng.
- ZIP bỏ venv/cache, kèm manifest SHA-256 được đọc lại kiểm tra.

Xem [validation](af-validation.md), [evidence kết quả](../../data/validation/af-verification.json), [evidence HTTP](../../data/validation/af-api_validation.json).

## Chạy lại

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m cli.pipeline --output results/reproduced
.\.venv\Scripts\python.exe -m cli.verify_results
.\.venv\Scripts\python.exe -m cli.verify_api
.\.venv\Scripts\python.exe -m cli.package
```

Output pipeline phải mới hoặc trống. Lệnh tạo venv/cài package, baseline, train/resume, evaluate/plot/API riêng ở [README](../../README.md), [Windows setup](../windows-setup.md). Config: `configs/simulation.json`, `configs/marl.json`. Chi tiết [MARL/reward](../marl.md), [kiến trúc](../architecture.md), [thí nghiệm](../experiments.md), [API](../api.md).

## Hạn chế trong báo cáo đồ án

Chưa hiệu chỉnh hạ tầng thật; arrival batch một giây, request đồng nhất, capacity cố định, error chỉ overflow. Không drain cuối run; latency chỉ cho request hoàn tất nên có censoring. Một training seed chính, chưa chứng minh hội tụ/ý nghĩa thống kê/ưu thế ngoài mô hình. React chỉ có hợp đồng tích hợp. Venv dùng package sẵn có qua system-site-packages do pip bị chặn; cài venv sạch qua mạng chưa kiểm chứng trong sandbox.
