# G — Kiểm tra đầu vào và kế hoạch

> Layout updated: executable commands use `python -m cli.<command>`; earlier pilot/smoke artifacts are stored in `data/archive/af-experiments.zip`. Original A-F/G delivery reports are retained verbatim in that archive.

## Đã kiểm tra trước triển khai

Đọc DELIVERY/README, architecture/API/MARL, cấu hình, lõi simulator, môi trường/reward, PPO/training/evaluation, CLI và tests hiện có. Source React và source backend Ubuntu `/api/system`, `/api/openstack/overview` không nằm trong workspace; không đoán schema hai endpoint đó.

- Conservation: mỗi tick và toàn run kiểm tra assigned/received = processed + dropped + waiting, FIFO không âm.
- Throughput chia completed cho thời lượng. Error hiện chỉ là overflow; không phải HTTP/application error thật.
- Latency theo timestamp FIFO, service slot và base latency mô phỏng; p95 nearest-rank theo request, chỉ gồm completed.
- Cuối episode không drain queue; waiting được ghi riêng. Dropped/waiting không có latency, nên có censoring.
- Reward là tổng có trọng số throughput/latency/error/queue/overload/imbalance/switching và terminal queue. Chọn best bằng mean step reward validation, có mốc 0; không chọn bằng testing.
- Chưa thể ánh xạ trực tiếp utilization của service batch sang CPU pod hoặc host. Batch 1 giây, RAM reserve theo service capacity, capacity cố định và lỗi overflow là hạn chế khi hiệu chỉnh.

Không sửa model, reward, optimizer, logic chọn checkpoint hoặc train lại. Hai snapshot SHA-256 trước G (`stage-g-preservation.json`, `stage-g-logic-preservation.json`) được lưu trong ZIP lịch sử. Sau khi người dùng yêu cầu dọn: baseline/legacy được di chuyển, pilot/smoke gom ZIP; checkpoint và kết quả chính giữ nguyên nội dung. Manifest đang dùng: `data/validation/preserved-files.json`.

## Việc thực hiện trên Windows

- [x] Nhóm mã vào `src/` theo chức năng, tests theo domain; bỏ launcher trùng, cập nhật đường dẫn và lệnh theo bản đồ project.
- [x] Schema chung source real/simulated, lớp host/hypervisor/node/pod/application/client và metadata workload.
- [x] Parser Kubernetes quantities, collector read-only và fixture offline có nhãn simulated.
- [x] App stdlib nhẹ, Deployment/Service/namespace/RBAC tùy chọn; không tự apply manifest.
- [x] Locust bốn pha với giới hạn user/duration và ngắt khi lỗi/latency kéo dài.
- [x] Preprocess giữ provenance, cân chỉnh thời gian và calibration chỉ đề xuất cấu hình A ở tệp mới.
- [x] Tests offline, smoke HTTP local, bảo toàn artifacts, hướng dẫn ba nơi chạy và bàn giao G riêng.

## Còn phụ thuộc Cluster A thật

Chưa có địa chỉ, kubeconfig/context, node identity, output Metrics API hoặc workload thật trong phiên này. Cần xác minh topology VM/OpenStack, network/port-forward, image pull, quyền read-only, metric freshness và đo baseline tải nhỏ. Không coi fixture hoặc app chạy localhost Windows là số đo Cluster A.
