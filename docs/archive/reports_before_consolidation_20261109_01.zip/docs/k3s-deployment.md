# Sample app K3s — khám phá, triển khai, kiểm tra và gỡ

Các lệnh trong tài liệu này dành cho **VM chạy K3s Cluster A đã xác minh**, không phải Ubuntu DevStack host nếu đó là hai máy khác nhau. Chưa chạy các lệnh deploy trên Cluster A trong phiên phát triển. Chỉ namespace/resources mới `cloud-calibration` được đề xuất; không thay đổi hoặc restart OpenStack/K3s đang hoạt động.

## 1. Khám phá trước

```bash
hostnamectl
ip -br address
ip route
sudo ss -ltnp
sudo k3s kubectl config current-context
sudo k3s kubectl get nodes -o wide
sudo k3s kubectl get services -A -o wide
sudo k3s kubectl get namespaces
sudo k3s kubectl -n kube-system get deployment metrics-server
sudo k3s kubectl top nodes
```

Đối chiếu node với VM/flavor/IP trong `openstack server show` trên Ubuntu. Không dùng IP host DevStack thay IP guest K3s. Nếu `top` không hoạt động, lưu lỗi, chưa cài Prometheus hoặc thay flags TLS của metrics-server. [kubectl top](https://kubernetes.io/docs/reference/kubectl/generated/kubectl_top/) có tín hiệu phục vụ autoscaling, không phải phép đo có độ chính xác như profiler.

Kiểm tra namespace `cloud-calibration` chưa có hoặc đúng là namespace thử nghiệm của bạn. Bắt đầu một pod, CPU limit 250m và RAM limit 96Mi; đây là hạn mức đề xuất cần quan sát thực tế trên VM, không bảo đảm host DevStack không bị ảnh hưởng.

## 2. Copy source và apply thủ công

Trong thư mục project trên VM, Python 3 có sẵn là đủ. Không cần cài Docker/SDK/Prometheus trên Windows. App chạy từ ConfigMap trên image Python chính thức; không cần tự build image:

```bash
read -rp 'Đường dẫn project trong VM: ' PROJECT_DIR
cd "$PROJECT_DIR"
# Kiểm tra manifest trước, chưa ghi cluster
sudo k3s kubectl apply --dry-run=client -f deploy/k3s/namespace.yaml
sudo k3s kubectl apply --dry-run=client -f deploy/k3s/deployment.yaml
sudo k3s kubectl apply --dry-run=client -f deploy/k3s/service.yaml

sudo k3s kubectl apply -f deploy/k3s/namespace.yaml
sudo k3s kubectl -n cloud-calibration create configmap calibration-work-code --from-file=server.py=src/apps/sample_api/server.py --dry-run=client -o yaml | sudo k3s kubectl apply -f -
sudo k3s kubectl apply -f deploy/k3s/deployment.yaml
sudo k3s kubectl apply -f deploy/k3s/service.yaml
sudo k3s kubectl -n cloud-calibration rollout status deployment/calibration-work --timeout=90s
```

Image `python:3.11-slim` cần pull được trong VM. Sau khi xác minh hoạt động, có thể pin digest image đã kéo để tái lập; không bịa digest. Nếu ImagePullBackOff, không tự cài thêm registry hoặc thay network OpenStack: xem events và cấu hình registry hiện có theo môi trường của bạn.

Pod chạy non-root UID 10001, không mount service-account token, drop capabilities, read-only root filesystem, một replica và Recreate để tránh pod surge khi cập nhật. Code ConfigMap được mount read-only. `/health` dành cho readiness/liveness; failure threshold rộng để không restart vội vì tải ngắn. `/work` mặc định tiêu thụ khoảng 5ms **thread CPU time** và cấp phát 64KiB tạm; CPU throttling có thể làm wall-clock latency dài hơn. Max concurrent work=2, khi bận trả 429 thay vì queue vô hạn. `/metrics` và `/health` không tính vào workload counters.

Các mức work có giới hạn CPU 0–25ms, memory 0–1024KiB/request; cấu hình qua env `WORK_CPU_MS`, `WORK_MEMORY_KIB`, không cho URL tạo tác vụ tùy ý. Một process/pod; `/metrics` có instance UUID để phát hiện restart. Chưa có xác nhận trên ARM/image/VM thực của bạn.

## 3. Kiểm tra service và endpoint thật

```bash
sudo k3s kubectl -n cloud-calibration get deployment,pods,service -o wide
sudo k3s kubectl -n cloud-calibration get endpointslices -l kubernetes.io/service-name=calibration-work -o wide
sudo k3s kubectl -n cloud-calibration get events --sort-by=.metadata.creationTimestamp
sudo k3s kubectl -n cloud-calibration logs deployment/calibration-work --tail=30
sudo k3s kubectl -n cloud-calibration top pods -l app=calibration-work
sudo k3s kubectl get --raw /apis/metrics.k8s.io/v1beta1/namespaces/cloud-calibration/pods
```

Service mặc định **ClusterIP**, không giả định IP routable từ Windows và không tự cấp NodePort/load balancer. Dùng port-forward loopback trong VM:

```bash
sudo k3s kubectl -n cloud-calibration port-forward --address 127.0.0.1 service/calibration-work 18080:8080
```

Terminal khác:

```bash
curl --fail http://127.0.0.1:18080/health
curl --fail http://127.0.0.1:18080/work
curl --fail http://127.0.0.1:18080/metrics
```

`/metrics` phải có namespace cloud-calibration, pod_name khớp pod thật, instance_id và counters. Windows dùng SSH `-L`/`-J` như `real-cluster-integration.md`; không mở port-forward ra `0.0.0.0` để tiện test.

## 4. RBAC collector tùy chọn

```bash
sudo k3s kubectl apply --dry-run=client -f deploy/k3s/collector-rbac.yaml
sudo k3s kubectl apply -f deploy/k3s/collector-rbac.yaml
```

Manifest chỉ cấp get/list nodes/node metrics và pods/pod metrics trong namespace. Không cấp exec/proxy/secrets hoặc quyền ghi. Quản trị viên cung cấp kubeconfig/context của identity này bằng cơ chế hiện có; không lưu token vào source/CSV. Port-forward được mở riêng bằng context quản trị đã có, không cấp quyền đó cho collector. Config collector cần expected_node_names và context đã xác minh.

## 5. Gỡ phần thử nghiệm

Xem tài nguyên trước, chỉ xóa những tài nguyên vừa tạo:

```bash
sudo k3s kubectl -n cloud-calibration get all,configmap
sudo k3s kubectl delete -f deploy/k3s/collector-rbac.yaml --ignore-not-found
sudo k3s kubectl delete -f deploy/k3s/service.yaml -f deploy/k3s/deployment.yaml --ignore-not-found
sudo k3s kubectl -n cloud-calibration delete configmap calibration-work-code --ignore-not-found
# Chỉ nếu namespace đúng là namespace mới dành riêng cho bài test và không có workload khác:
sudo k3s kubectl delete -f deploy/k3s/namespace.yaml --ignore-not-found
```

Ctrl+C dừng port-forward/tunnel/load/collector. Không xóa namespace hệ thống, không reboot VM hoặc restart OpenStack để gỡ app.
