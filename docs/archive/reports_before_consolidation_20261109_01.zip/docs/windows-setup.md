# Windows PowerShell

Chạy các lệnh từ thư mục gốc project, Python 3.11 trở lên. Bộ kết quả hiện có dùng PyTorch CPU; không cần bật Ubuntu/VMware để xem hoặc chạy tests offline.

## Cài đặt

```powershell
Set-Location 'D:\HocTap\hk7\VMWare\cloud_marl_simulator_start'
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

`requirements.txt` cài dependency toàn project và đăng ký editable package từ `src/`. Chỉ cần G thì thay lệnh cuối bằng `pip install -r requirements/integration.txt`; file này gồm Locust, pytest, YAML và editable package, không cài PyTorch.

Với `.venv` đã có đầy đủ dependency trước khi sắp xếp, cập nhật đường dẫn một lần, không tải dependency:

```powershell
.\.venv\Scripts\python.exe -m pip install -e . --no-deps --no-build-isolation
```

Venv hiện tại dùng `system-site-packages`; chưa kiểm chứng cài một venv cô lập mới qua mạng. Không cần activate hoặc thay ExecutionPolicy để dùng các lệnh dưới đây.

## Tests, API và offline G

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m cli.verify_api
.\.venv\Scripts\python.exe -m cli.cluster_smoke --output data/demo/my-stage-g
.\.venv\Scripts\python.exe -m cli.serve --results results/evaluation --port 8000
```

Giữ terminal API, mở `http://127.0.0.1:8000/docs`. Terminal khác:

```powershell
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/status'
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/comparison?scenario=mixed'
Get-Content results/evaluation/report.md -Encoding UTF8
```

Ctrl+C dừng API. `verify_api` tự khởi động và dừng server kiểm tra. Không có kết nối K3s thật trong offline smoke; đầu ra mang `source=simulated`. Đích smoke phải mới/trống.

Nếu plugin pytest cài toàn máy gây xung đột, tạm dùng `$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'` trước khi chạy tests; bỏ bằng `Remove-Item Env:\PYTEST_DISABLE_PLUGIN_AUTOLOAD` sau đó.

## Khi chủ động chạy thí nghiệm mới

Các lệnh sau tạo kết quả mới và có training; không cần chạy để xem bản bàn giao hoặc thu dữ liệu G:

```powershell
.\.venv\Scripts\python.exe -m cli.baselines --seeds 42 43 44 45 46 --output results/local-baseline
.\.venv\Scripts\python.exe -m cli.train --smoke --output results/local-smoke
.\.venv\Scripts\python.exe -m cli.train --output results/local-training
# Resume đến TỔNG 500 episode
.\.venv\Scripts\python.exe -m cli.train --resume results/local-training/checkpoints/last.pt --episodes 500 --output results/local-training
.\.venv\Scripts\python.exe -m cli.evaluate --checkpoint results/local-training/checkpoints/best.pt --output results/local-evaluation
.\.venv\Scripts\python.exe -m cli.plot --input results/local-evaluation/csv --output results/local-evaluation/figures --scenario mixed
.\.venv\Scripts\python.exe -m cli.package --output dist/cloud_marl.zip
```

Baseline/evaluation/plot có thể thay đầu ra nếu dùng lại cùng đích. Training từ chối ghi đè run đã có nếu không resume; thay hyperparameter cần run mới. Các lệnh CLI cũ ở gốc đã bỏ; xem [bản đồ project](project-layout.md).
