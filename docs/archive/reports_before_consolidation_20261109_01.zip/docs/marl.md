# Môi trường đa agent và Independent PPO

## Hợp đồng môi trường (C)

`marl.env.MultiClusterEnv` cung cấp parallel dict API rõ ràng, không tuyên bố là PettingZoo:

```python
env = MultiClusterEnv(simulation_config, reward_config, action_step=0.03)
observations, infos = env.reset(seed=1000)
observations, rewards, terminated, truncated, infos = env.step({
    'cluster_A': 1, 'cluster_B': 1, 'cluster_C': 2,
})
```

Mọi dict đều có ba ID tương ứng tên cluster trong JSON, không có khóa `__all__`. `possible_agents` cố định, `agents` trống sau khi kết thúc. `step` trước reset hoặc sau khi kết thúc báo lỗi. `JointGymEnv` là adapter kế thừa Gymnasium Env với Dict observation/action spaces; đã qua `gymnasium.utils.env_checker.check_env`. IPPO dùng trực tiếp parallel API với ba policy riêng.

Mỗi agent thấy 26 số float32, Box [0,10], thứ tự:

| Nhóm | Đặc trưng |
|---|---|
| 8 số cho cluster của mình | CPU/100, RAM/100, queue/max_queue, assigned trước đó/tổng capacity, latency trước đó/latency_scale, (processed trước đó + queue)/capacity, capacity/tổng capacity, tỷ lệ nhận hiện tại |
| 8 số cho cluster kế tiếp | Cùng thứ tự, xoay vòng thứ tự cluster |
| 8 số cho cluster còn lại | Cùng thứ tự |
| 2 số chung | Batch incoming hiện tại/tổng capacity; tỷ lệ thời gian còn lại của trace |

Observation ban đầu dùng CPU=0, RAM nền, queue=0, chưa có latency. Latency không có hoàn tất dùng 0 trong **feature** để biểu diễn vắng đo đạc; CSV/metric vẫn để null. Feature được clip [0,10] và mẫu số queue dùng max(1,max_queue). Không có future demand, phase tương lai, metric sau action hoặc seed trong observation. Biết tổng thời lượng trace là giả định finite-horizon; incoming batch hiện tại được quan sát theo cùng quy ước baseline.

## Action và chuẩn hóa

Action Discrete(3): 0 giảm, 1 giữ, 2 tăng. Khởi tạo tỷ lệ đều 1/3, không có prior gán sẵn tỷ lệ tối ưu. Với δ = action − 1 và bước `action_step`:

```text
logits_i = log(previous_ratio_i) + action_step * delta_i
logits = clip(logits - max(logits), -8, 0)
ratio_i = exp(logits_i) / sum(exp(logits))
```

Tỷ lệ dương, tổng bằng 1, nhưng đề xuất tăng của một agent có thể bị trung hòa bởi đề xuất của agent khác. Nếu cả ba cùng thay đổi như nhau, tỷ lệ không đổi. Phân bổ nguyên dùng largest remainder, hòa điểm theo thứ tự cluster, đảm bảo tổng assigned đúng bằng demand. Không tự chuyển request bị drop sang cluster khác hoặc dùng heuristic thay thế action MARL.

## Reward hợp tác

Cả ba agent nhận cùng team reward; mỗi agent vẫn có critic, actor và optimizer độc lập. Tổng reward mỗi step gồm các thành phần lưu trong `info['reward_components']`:

| Thành phần | Mặc định | Công thức, mục đích |
|---|---:|---|
| Throughput | +2,0 | processed/tổng capacity; thưởng phục vụ thật |
| Latency | −0,4 | min(latency_mean/1000 ms, 10); giảm response time |
| Error | −4,0 | dropped/current incoming; phạt mạnh mất request |
| Queue | −0,5 | mean(queue/max_queue); tránh tích backlog |
| Overload | −0,2 | mean(max(CPU%−90,0)/10); tránh duy trì sát bão hòa khi có lựa chọn |
| Imbalance | −0,3 | std dân số của (processed+queue)/capacity; cân bằng tải theo năng lực |
| Switching | −0,1 | L1(new ratios−old ratios); giảm đổi tỷ lệ thường xuyên |
| Terminal queue | −1,0 | waiting/tổng max_queue, chỉ khi trace kết thúc tự nhiên; tránh trì hoãn đến cuối |

Hệ số là lựa chọn thiết kế, không khẳng định tối ưu phổ quát. Throughput/error ưu tiên phục vụ thành công; penalty latency/queue giúp giảm việc tích backlog để đổi lấy throughput sau đó. Cần phân tích metric ngoài reward vì mục tiêu có trade-off. Toàn bộ hệ số và latency scale nằm trong JSON, không có kết quả huấn luyện hardcode.

## Termination và truncation

Hết trace là **termination** của bài toán finite-horizon (có feature thời gian còn lại); không drain queue, hạch toán waiting riêng. `max_steps` tùy chọn cắt trước hết trace là **truncation**; observation trả về vẫn chứa demand bước kế tiếp thật, dùng bootstrap value. GAE không bootstrap qua termination; có bootstrap qua truncation nhưng không truyền advantage sang episode sau. Kiểm thử có ví dụ tính tay cho cả hai trường hợp.

Quy ước này dựa trên [Gymnasium termination/truncation](https://gymnasium.farama.org/tutorials/gymnasium_basics/handling_time_limits/) và [Farama Step API](https://farama.org/Gymnasium-Terminated-Truncated-Step-API).

## Huấn luyện (D)

Ba mạng độc lập: hai lớp 32 neuron tanh, head actor 3 logits, head critic 1 value; actor và critic của **một** agent dùng chung trunk, không chia sẻ trọng số giữa agent. PyTorch chạy CPU, một thread và deterministic algorithms. Không có imitation, pretraining hoặc fallback Least Loaded.

Dùng [clipped PPO](https://arxiv.org/abs/1707.06347): ratio exp(logπ_new − logπ_old), tối đa hóa min(ratio×advantage, clipped_ratio×advantage), cộng value MSE và entropy regularization. Advantage GAE, chuẩn hóa trong rollout mỗi agent; minibatch shuffle và gradient clipping. Config JSON chứa gamma, lambda, clip, learning rate, entropy/value coefficient, gradient norm, epochs, minibatch, action step, seed và lịch validation.

Mỗi episode có workload seed mới `train_seed_start + episode - 1`. Validation dùng các seed cố định riêng, không tiêu thụ RNG của training. Mặc định lấy mẫu policy với RNG riêng được seed bởi `(policy_seed*1000003 + workload_seed*9176) mod (2**63−1)`, để đánh giá đúng policy ngẫu nhiên và tái lập. Có tùy chọn `inference_mode='greedy'`; phải cố định mode trước testing. Không chọn mode bằng kết quả testing.

`best.pt` chọn theo mean step reward trên validation, gồm mốc episode 0 để phát hiện việc học làm policy tệ đi; `last.pt` là mốc train cuối. Không giả định best phải là một episode đã update. Validation CSV ghi tất cả mốc và seed. Training CSV ghi reward, policy/value loss, entropy, clip fraction, approximate KL, throughput, latency, error và request counts; agent_training.csv ghi loss từng agent.

Checkpoint chứa model, optimizer, hyperparameters, simulator config, histories, Python/NumPy/Torch RNG, episode và snapshot tốt nhất. Ghi file tạm rồi replace; load với [`weights_only=True`](https://docs.pytorch.org/docs/stable/notes/serialization.html). Resume tại ranh giới episode đã lưu, với cấu hình giữ nguyên trừ tổng episodes. Đã kiểm chứng trọng số và log khớp tuyệt đối train liên tục trên case kiểm thử, đồng thời cả ba agent thực sự thay đổi trọng số.

Năm learning curves được sinh từ CSV: reward, reward moving average 20, policy/value loss và entropy, error, validation reward/latency/throughput. Thời lượng train hữu hạn, không có tác vụ nhiều giờ chạy nền.
