# Tích hợp dashboard qua FastAPI (F)

API chỉ đọc CSV/metadata được simulator sinh ra; không khởi chạy huấn luyện, không giữ cloud credentials, không tạo hoặc thay đổi tài nguyên thật. Chưa sửa website React vì source website không có trong workspace.

## Khởi động

```powershell
.\.venv\Scripts\python.exe -m cli.serve
# Hoặc đọc baseline A+B
.\.venv\Scripts\python.exe -m cli.serve --results results --port 8001
# Tương đương, dùng biến môi trường
$env:CLOUD_SIM_RESULTS = (Resolve-Path results/evaluation).Path
.\.venv\Scripts\python.exe -m uvicorn cloud_api.app:app --host 127.0.0.1 --port 8000
```

Mặc định dùng `results/evaluation`, host loopback, port 8000. OpenAPI/Swagger: `http://127.0.0.1:8000/docs`; schema: `/openapi.json`. Chỉ gọi GET, không có endpoint ghi hoặc điều khiển hạ tầng. Chạy pipeline xong trước khi serve dataset; nên dùng mỗi thư mục output cho một thí nghiệm riêng.

## Hợp đồng dữ liệu

Tất cả response thành công có:

```json
{
  "data_source": "simulation",
  "is_simulation": true,
  "metrics_are_real": false,
  "notice": "Synthetic simulator output; not real OpenStack/Kubernetes/AWS telemetry."
}
```

Frontend phải giữ badge **Simulation** và không ghép các metric này vào thẻ telemetry OpenStack thật. Metric không có mẫu hoàn tất dùng JSON null. CPU/RAM là %, latency ms, throughput req/s, queue/processed/dropped là số request. Tất cả số CSV được chuyển về JSON numeric, không trả số dạng string. Lỗi trả HTTP 404/422/503 với `detail`, không sinh dữ liệu giả.

| Endpoint | Query | Nội dung |
|---|---|---|
| GET `/api/simulation/status` | không | ready/status, datasets, policies, scenarios, seeds, timestamp và checkpoint episode |
| GET `/api/simulation/clusters` | policy, seed, scenario | cấu hình A/B/C, effective capacity, CPU/RAM, max queue và metric cuối của bộ lọc |
| GET `/api/simulation/metrics` | policy, seed, scenario, cluster, dataset, start_second, end_second, limit, offset | time-series theo cluster hoặc toàn hệ thống, total và phân trang |
| GET `/api/simulation/comparison` | policy, scenario | mean/std và số mẫu cho mọi chỉ số trong comparison.csv |

`policy`: round_robin/least_loaded/marl; `scenario`: mixed/stable/ramp_up/spike/recovery. `dataset=cluster` mặc định hoặc `system`; system không nhận cluster filter. Giới hạn `limit` 1–10000 (mặc định 1000); `offset` và seed/thời gian không âm; end_second bao gồm mốc cuối và không được nhỏ hơn start_second. Không có bộ lọc → metrics trả tất cả trong phạm vi phân trang, vì vậy frontend nên chỉ định scenario/seed/policy.

Clusters mặc định lấy MARL nếu có, nếu không lấy policy đầu; seed đầu và scenario mixed (hoặc scenario đầu). Bộ lọc không có mẫu trả `latest_metrics=null` hoặc rows rỗng, không lấy metric từ một seed khác. Status là no_results/invalid_results/incomplete/ready; chỉ ready khi có đủ các dataset yêu cầu và metadata được đánh dấu simulation hợp lệ.

```powershell
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/status'
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/clusters?policy=marl&scenario=mixed&seed=30001'
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/metrics?policy=marl&scenario=mixed&seed=30001&cluster=A&limit=180'
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/metrics?dataset=system&policy=marl&scenario=mixed&seed=30001'
Invoke-RestMethod 'http://127.0.0.1:8000/api/simulation/comparison?scenario=mixed'
```

## React tích hợp sau

Chỉ bật CORS cho đúng origin dashboard, ví dụ:

```powershell
$env:CLOUD_SIM_CORS_ORIGINS = 'http://localhost:5173,http://127.0.0.1:5173'
.\.venv\Scripts\python.exe -m cli.serve
```

Không bật wildcard credentials. Các origin trong ví dụ chỉ là cấu hình local tùy chọn; thay bằng origin website thật. React có thể dùng:

```javascript
const response = await fetch(
  'http://127.0.0.1:8000/api/simulation/metrics?dataset=system&policy=marl&scenario=mixed&seed=30001'
);
if (!response.ok) throw new Error(`Simulation API: ${response.status}`);
const payload = await response.json();
if (payload.data_source !== 'simulation') throw new Error('Unexpected data source');
// Hiển thị badge Simulation; dùng payload.rows để vẽ biểu đồ.
```

API độc lập với simulator/trainer; startup không import PyTorch hoặc load checkpoint. Muốn chuyển dataset, khởi động lại với `--results` hoặc biến môi trường khác.
