# G — Thu dữ liệu Cluster A thật, chuẩn bị trên Windows

**Trạng thái bàn giao:** code và offline/localhost tests đã triển khai; chưa có kubeconfig/context/node/network thực trong phiên này nên **chưa xác nhận đã kết nối Cluster A**. Chưa train lại MARL. React và backend Ubuntu không bị sửa; logic simulator/reward/best checkpoint giữ nguyên. Bản đồ thư mục ở `project-layout.md`; kết quả A–F được bảo toàn bằng SHA-256.

## Kiến trúc nhẹ

`kubectl get ... -o json` và GET Metrics API → collector + app `/metrics` → raw JSONL/CSV chuẩn → preprocessing → calibration report → cấu hình đề xuất A riêng nếu đủ bằng chứng. Không dùng Kubernetes Python SDK hoặc cài Prometheus. K3s thường đóng gói metrics-server, nhưng phải kiểm tra bản cài của bạn; [K3s packaged components](https://docs.k3s.io/installation/packaged-components). Metrics API chỉ có CPU/RAM cơ bản, không cung cấp request/latency; [Kubernetes resource metrics](https://kubernetes.io/docs/tasks/debug/debug-cluster/resource-metrics-pipeline/).

App đếm request thật và timestamp service, collector dùng delta counters. Node metrics là toàn bộ VM/node K3s; pod metrics là tài nguyên ứng dụng theo namespace/label. Linux /proc ở Ubuntu DevStack là host/hypervisor, không phải Cluster A. Chi tiết đơn vị, latency và chất lượng ở `metrics-calibration.md`.

## 1. Windows PowerShell — có thể chạy ngay

```powershell
Set-Location 'D:\HocTap\hk7\VMWare\cloud_marl_simulator_start'
# Dùng venv hiện tại; nếu tạo mới:
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements/integration.txt
# Tests G không cần PyTorch; toàn bộ tests cần requirements.txt
.\.venv\Scripts\python.exe -m pytest -q tests/integration
.\.venv\Scripts\python.exe -m cli.cluster_smoke --output data/demo/my-stage-g
```

Collector/app/preprocess/calibration chỉ dùng thư viện chuẩn; Locust và YAML parser là gói tùy chọn cho load test/tests. Không cần cài kubectl trên Windows nếu collector chạy trong VM K3s. Offline pipeline dùng fixture có nhãn simulated, không tạo calibrated config thật:

```powershell
.\.venv\Scripts\python.exe -m cli.cluster collect --fixture tests/fixtures/cluster_a.json --samples 8 --output data/demo/offline-collector
.\.venv\Scripts\python.exe -m cli.cluster preprocess --input data/demo/offline-collector/metrics.csv --allow-simulated --output data/demo/offline-processed
.\.venv\Scripts\python.exe -m cli.cluster calibrate --input data/demo/offline-collector/metrics.csv --allow-simulated --output data/demo/offline-calibration
.\.venv\Scripts\python.exe -m cli.cluster export-simulation --input results/evaluation --output data/demo/simulation-common.csv
```

Output phải mới/trống. `--allow-simulated` chỉ cho phát triển/kiểm thử, report ghi fixture demonstration và không cho xuất candidate calibrated thật.

## 2. Ubuntu OpenStack — khám phá, không thay đổi dịch vụ

Vào môi trường OpenStack CLI đã có bằng openrc/cloud config hiện tại. Không in password/token, không cài lại DevStack:

```bash
hostnamectl
ip -br address
free -h
openstack server list
openstack hypervisor list
read -rp 'VM K3s ID đã xác minh: ' K3S_VM_ID
openstack server show "$K3S_VM_ID" -f json
read -rp 'Hypervisor ID chứa VM: ' HYPERVISOR_ID
openstack hypervisor show "$HYPERVISOR_ID" -f json
```

Đối chiếu addresses/flavor/hypervisor của VM với hostname/IP/node trong VM K3s. `vcpus_used`/`memory_mb_used` OpenStack có thể là **allocation**, không phải CPU busy hoặc working-set của guest. Không biến các trường đó thành utilization Cluster A.

Trong thư mục project đã copy sang Ubuntu, dùng Python sẵn có; không cài PyTorch/Locust ở host nếu không cần:

```bash
read -rp 'Đường dẫn project trên Ubuntu: ' PROJECT_DIR
cd "$PROJECT_DIR"
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
mkdir -p data/runs/first-a
python3 -m cli.cluster host --layer ubuntu_host --run-id first-a --samples 14 --interval 15 --output data/runs/first-a/ubuntu-host.csv
```

Nếu hệ điều hành đó chính là hypervisor DevStack, có thể chọn `--layer openstack_hypervisor` **thay** `ubuntu_host`, ghi rõ chúng là cùng máy; không cộng hai mẫu thành hai tài nguyên độc lập. Sampler để cluster_id trống và không được đưa vào fit CPU pod.

Backend `/api/system`, `/api/openstack/overview` chưa có source/schema trong project. Có thể chụp raw để thiết kế adapter sau, không suy diễn trường:

```bash
read -rp 'Base URL backend đang chạy: ' BACKEND_URL
mkdir -p data/unmapped
curl --fail --max-time 5 "$BACKEND_URL/api/system" -o data/unmapped/ubuntu-system.json
curl --fail --max-time 5 "$BACKEND_URL/api/openstack/overview" -o data/unmapped/openstack-overview.json
```

Không restart Nova/Neutron/libvirt/K3s hoặc đổi cấu hình OpenStack trong các lệnh này.

## 3. VM K3s Cluster A — khám phá trước khi deploy

Theo `k3s-deployment.md` để kiểm tra node/service/network và triển khai sample app. Các lệnh sau chỉ đọc:

```bash
hostnamectl
ip -br address
ip route
sudo k3s kubectl config current-context
sudo k3s kubectl get nodes -o wide
sudo k3s kubectl get services -A -o wide
sudo k3s kubectl -n kube-system get deployment metrics-server
sudo k3s kubectl get --raw /apis/metrics.k8s.io/v1beta1/nodes
```

Nếu Metrics API thiếu/quyền bị từ chối, ghi nhận lỗi; không tự bật addon hoặc bỏ TLS verification. Collector vẫn ghi inventory/status và để CPU/RAM thiếu là null. Chưa đủ dữ liệu thì calibration từ chối hoặc loại cửa sổ.

Sau khi pod Ready, terminal thứ nhất trong VM giữ port-forward loopback:

```bash
sudo k3s kubectl -n cloud-calibration port-forward --address 127.0.0.1 service/calibration-work 18080:8080
```

Terminal thứ hai, từ project:

```bash
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export CAL_CONTEXT="$(sudo k3s kubectl config current-context)"
export CAL_NODES="$(sudo k3s kubectl get nodes -o jsonpath='{.items[*].metadata.name}')"
export CAL_RUN_ID='first-a'
python3 - <<'PY'
import json, os
from pathlib import Path
p = json.loads(Path('configs/integration/collector.example.json').read_text())
p.update(context=os.environ['CAL_CONTEXT'], expected_node_names=os.environ['CAL_NODES'].split(),
         kubectl_command=['sudo', '-n', 'k3s', 'kubectl'], run_id=os.environ['CAL_RUN_ID'])
Path('configs/integration/collector.local.json').write_text(json.dumps(p, indent=2))
PY
python3 -m cli.cluster collect --config configs/integration/collector.local.json --workload configs/integration/load-safe.json --samples 14 --interval 15 --output data/runs/first-a/collector
```

Đọc/đối chiếu node names với đúng VM trước khi dùng config. Collector yêu cầu danh sách node khớp toàn bộ, kiểm tra app pod/namespace trong inventory, không nhận nhầm host IP là node. `sudo -n` cần quyền đã có, nếu bị từ chối hãy dùng context read-only/kubeconfig phù hợp, không nới quyền tự động. RBAC tối thiểu tùy chọn có trong deploy/k3s.

## 4. Windows tạo tải nhỏ qua SSH tunnel

Không giả định IP. Nhập địa chỉ đã tìm ở bước trên, kiểm tra SSH. Nếu Windows truy cập VM trực tiếp được, không cần jump host:

```powershell
$UbuntuAddress = Read-Host 'IP Ubuntu đã xác minh'
$UbuntuLogin = Read-Host 'SSH user Ubuntu'
$K3sAddress = Read-Host 'IP VM K3s đã xác minh'
$VmLogin = Read-Host 'SSH user VM K3s'
Test-NetConnection -ComputerName $UbuntuAddress -Port 22
# Terminal riêng, giữ tunnel mở; port-forward trong VM vẫn chạy
ssh -J "$UbuntuLogin@$UbuntuAddress" -N -L 18080:127.0.0.1:18080 "$VmLogin@$K3sAddress"
```

Terminal Windows khác:

```powershell
Invoke-RestMethod 'http://127.0.0.1:18080/health'
Invoke-RestMethod 'http://127.0.0.1:18080/metrics'
.\.venv\Scripts\python.exe -m cli.cluster load --host http://127.0.0.1:18080 --source real --run-id first-a --profile configs/integration/load-safe.json --output data/runs/first-a/load
```

Chỉ dùng source real sau khi xác minh `/metrics` trả đúng namespace/pod và context/node mapping. Nếu tunnel/route/SSH không thông, dừng ở bước khám phá; không tự sửa security groups, bridge hoặc firewall. Load mặc định 120 giây, tối đa 6 user trong spike 15 giây; think time 1–2s, spawn 1/s, app giới hạn 0,25 CPU và 96Mi. Trên host quan sát `free -h`, CPU/IO; Ctrl+C ngay nếu ảnh hưởng DevStack. Client có guard lỗi/latency và hard timeout, nhưng không thay thế giám sát sức khỏe host.

## 5. Chép CSV và xử lý

```powershell
$RemoteProject = Read-Host 'Đường dẫn project tuyệt đối trong VM'
New-Item -ItemType Directory -Force data/imported/first-a | Out-Null
scp -r -J "$UbuntuLogin@$UbuntuAddress" "${VmLogin}@${K3sAddress}:$RemoteProject/data/runs/first-a/collector" data/imported/first-a/
.\.venv\Scripts\python.exe -m cli.cluster preprocess --input data/imported/first-a/collector/metrics.csv --output data/imported/first-a/processed
.\.venv\Scripts\python.exe -m cli.cluster calibrate --input data/imported/first-a/collector/metrics.csv --output data/imported/first-a/calibration
```

Đợt tải nhỏ có thể chưa bão hòa: report phải ghi capacity lower bound và overload not observed. Không tăng tải tự động để buộc có kết quả. Xem `metrics-calibration.md` về điều kiện candidate A, các giả định giữ nguyên và phần chờ xác minh thật.
