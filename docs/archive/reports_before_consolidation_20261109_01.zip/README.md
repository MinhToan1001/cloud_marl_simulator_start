# Cloud MARL Simulator

| Giai đoạn mới nhất | Báo cáo và trạng thái |
|---|---|
| Task 2 Placement V1 | [H1–H5](docs/task2/README.md), run `_03` giữ nguyên |
| Task 2B closeout | [H6](docs/task2/H6_CLOSEOUT_REPORT.md): A1/A2/A3/A6 DONE; A4 PENDING bằng chứng sau khi Cluster A phục hồi theo kiểm tra thủ công; [A5 PENDING](docs/task2/A5_LOAD_TEST_APPROVAL_REQUEST.md), chưa thử tải |
| Task 3 DAG Simulator V2 | [Báo cáo](docs/task3/SIMULATOR_V2_REPORT.md), [mô hình](docs/task3/MATH_MODEL.md), [schema](docs/task3/SCHEMA_V2.md), [validation](docs/task3/VALIDATION_REPORT.md) |
| Run V2 cần đọc | [dag_v2_20261109_05](results/task3/dag_v2_20261109_05/REPORT.md), SIMULATED; không huấn luyện MARL hoặc thay đổi hạ tầng |

Tái hiện V2: `.venv-task2\Scripts\python.exe -X utf8 -m cli.task3 --output results/task3/<run_moi> --test-python .venv/Scripts/python.exe`. Mọi stage từ chối ghi đè. Calibration hiện chỉ low-load; chưa sẵn sàng closed loop.

Mô phỏng 3 cluster, huấn luyện IPPO, đánh giá và API FastAPI. Giai đoạn G bổ sung collector K3s, ứng dụng mẫu, Locust và calibration. **G mới được kiểm chứng offline/localhost; chưa xác nhận kết nối Cluster A thật.**

## Bắt đầu trên Windows

Chạy từ thư mục project, dùng Python 3.11 trở lên:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m cli.serve
```

API đọc kết quả có sẵn, mở `http://127.0.0.1:8000/docs`. Không cần train lại. Nếu chỉ dùng G, cài `requirements/integration.txt` thay cho `requirements.txt`.

Sau khi tải phiên bản đã sắp xếp vào môi trường có sẵn, đăng ký lại source một lần:

```powershell
.\.venv\Scripts\python.exe -m pip install -e . --no-deps --no-build-isolation
```

## Thư mục theo chức năng

| Thư mục | Nội dung |
|---|---|
| [src](src/) | Mã Python: simulator, MARL, API, collector, app mẫu, load test và CLI |
| [configs](configs/) | Cấu hình simulation/MARL và mẫu cấu hình Cluster A |
| [deploy/k3s](deploy/k3s/) | Namespace, Deployment, Service và RBAC |
| [tests](tests/) | Tests theo simulation, MARL, API, integration; fixture offline |
| [results](results/) | Kết quả chính: `baseline/`, `training/`, `evaluation/` |
| [data](data/) | Dữ liệu thu thập, bằng chứng kiểm tra và một ZIP lịch sử |
| [legacy](legacy/) | Simulator và CSV gốc, giữ nguyên nội dung |
| [docs](docs/README.md) | Hướng dẫn theo chủ đề và báo cáo bàn giao |

Các launcher `.py` ở gốc đã được bỏ. Dùng `python -m cli.<command>`; package API và định dạng kết quả vẫn giữ tương thích. Xem [bản đồ chi tiết](docs/project-layout.md).

## Công việc thường dùng

```powershell
# G: fixture → CSV → calibration + tải nhỏ trên localhost
.\.venv\Scripts\python.exe -m cli.cluster_smoke --output data/demo/my-stage-g

# G: xem các lệnh collector/preprocess/calibrate/load
.\.venv\Scripts\python.exe -m cli.cluster --help

# A+B: dùng thư mục mới, tránh ghi đè kết quả đã bàn giao
.\.venv\Scripts\python.exe -m cli.baselines --seeds 42 43 44 45 46 --output results/my-baseline

# Vẽ CSV ra thư mục mới
.\.venv\Scripts\python.exe -m cli.plot --input results/evaluation/csv --output data/demo/figures --scenario mixed

# Kiểm tra HTTP API, tự dừng server khi xong
.\.venv\Scripts\python.exe -m cli.verify_api

# Đóng gói khi cần
.\.venv\Scripts\python.exe -m cli.package --output dist/cloud_marl.zip
```

Checkpoint chính ở [results/training/checkpoints](results/training/checkpoints/), gồm `best.pt` và `last.pt`; báo cáo ở [results/evaluation/report.md](results/evaluation/report.md). Đã có 300 episode và 75 lượt đánh giá. Không chạy lại training trong giai đoạn G hoặc lần dọn thư mục này.

## Tài liệu cần đọc

- [Lệnh cho Windows, Ubuntu OpenStack và VM K3s](docs/real-cluster-integration.md).
- [Khám phá mạng, triển khai và gỡ ứng dụng K3s](docs/k3s-deployment.md).
- [Schema metrics và calibration](docs/metrics-calibration.md).
- [Simulator](docs/architecture.md), [MARL/reward](docs/marl.md), [API](docs/api.md).
- [Bàn giao A–F](docs/reports/af-delivery.md), [bàn giao G](docs/reports/stage-g.md).

Các lần chạy thử/pilot, demo và tài liệu lịch sử trùng được gom vào [data/archive/af-experiments.zip](data/archive/af-experiments.zip), giữ byte gốc và kiểm tra SHA-256. Hai ZIP bàn giao cũ và các cache đã được bỏ. Chi tiết ở [báo cáo sắp xếp](docs/reports/cleanup.md).
