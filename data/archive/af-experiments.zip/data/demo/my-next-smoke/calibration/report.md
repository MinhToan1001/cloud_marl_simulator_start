# Calibration estimate

Status: **fixture_demonstration_not_real_calibration**

Aligned windows: 7; observed healthy capacity LOWER BOUND: 8.0 req/s.
Observed overload onset: None req/s (null means not observed).

See calibration.json for coefficients, units, R-squared, observed range and exclusions.

- Scope is the measured sample-app pod budget, not entire Cluster A hardware
- Node/Ubuntu/hypervisor CPU are not interchangeable with pod CPU
- Resource Metrics API is smoothed and intended for autoscaling; fit is exploratory
- Linear fits are descriptive within observed load range, not proven causal laws
- Server latency excludes Windows/network/SSH; client latency is a separate layer
- Do not map mean/p95 server latency directly to simulator base latency (service time would be double counted)
- RAM-vs-RPS slope does not identify memory per queued request; queue depth/capacity remain unmeasured
- No MARL retraining or live infrastructure changes; B/C remain simulated assumptions
