# Trạng thái A → F

- [x] Audit source/CSV đầu vào; giữ nguyên tệp lịch sử.
- [x] A: cấu hình, bốn pha tải, CPU/RAM, FIFO và request/latency metrics.
- [x] A: kiểm thử conservation, giới hạn, tính toán latency và không dùng tương lai.
- [x] B: hai baseline dùng chung workload; CSV/PNG/report một lệnh.
- [x] B: multi-seed, tái lập và replay/plot CSV cũ.
- [x] C: ba agent, observation, action normalization, reward, reset/step và termination/truncation.
- [x] C: Gymnasium adapter/check_env và tests trước training.
- [x] D: ba IPPO model/optimizer riêng, CPU, smoke, best/last, log và learning curves.
- [x] D: RNG resume, kiểm tra khớp train liên tục và trọng số thay đổi thật.
- [x] E: ba phương pháp, năm testing seed độc lập, năm scenario, mean/std và paired differences.
- [x] E: kết quả thực, hạn chế; không giả định MARL thắng.
- [x] F: bốn FastAPI GET endpoints, filter/phân trang, nhãn simulation, OpenAPI/CORS/React docs.
- [x] Tài liệu Windows, kiến trúc, reward, thí nghiệm, API và đóng gói.

Chi tiết thực chạy ở `DELIVERY.md`, `results/evaluation/report.md`, `docs/validation.md`. Giữ các pilot để đối chiếu. Checklist chức năng không hàm ý đã hiệu chỉnh hạ tầng thật hoặc MARL vượt mọi baseline.
