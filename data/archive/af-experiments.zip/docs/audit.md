# Kiểm tra project đầu vào

Tài liệu này ghi lại trạng thái đầu vào và đợt A+B. Hiện C–F cũng đã được triển khai; xem `DELIVERY.md` và `validation.md` cho bàn giao cuối.

Đã đọc toàn bộ hai tệp nguồn/tài liệu ban đầu: `simulate.py`, `README (1).md`, và toàn bộ ba CSV trong `output/`. Không có React/FastAPI, `.venv`, cấu hình, test hoặc module MARL trong workspace đầu vào. Workspace không phải Git repository.

## Dữ liệu thật đã có trong CSV

`workload.csv`: 180 dòng, 36.352 request; min/max theo giây 77/402. Tổng mỗi đoạn 45 giây lần lượt 4.007, 8.481, 15.882, 7.982.

`cluster_metrics.csv`: 1.080 dòng = 180 giây × 3 cluster × 2 thuật toán. Kiểm tra tất cả dòng không thấy vi phạm `queue_before + assigned = processed + dropped + queue_after`. Tổng assigned bằng workload cho mỗi thuật toán.

| Thuật toán gốc | Đến | Hoàn tất | Loại | Chờ cuối | Throughput req/s | Drop % | Latency proxy ms |
|---|---:|---:|---:|---:|---:|---:|---:|
| Round Robin | 36352 | 32603 | 3673 | 76 | 181.13 | 10.10 | 695.90 |
| Least Loaded | 36352 | 33160 | 3192 | 0 | 184.22 | 8.78 | 765.52 |

Những số trên được đọc từ CSV có sẵn, không phải kết quả của mô hình mới. Least Loaded trong dữ liệu gốc throughput cao hơn, ít drop hơn nhưng latency proxy cao hơn; không có cơ sở kết luận thắng trên mọi chỉ số.

## Những phần đã đúng

- Mô phỏng ba cluster có năng lực không đồng nhất 60/90/120 req/s.
- Hai thuật toán dùng chung một workload seed 42.
- Có giới hạn queue, xử lý/drop và bảo toàn request toàn run.
- Đã ghi rõ simulation, không phải metrics cloud thật.

## Vấn đề và cách xử lý trong A + B

| Vấn đề | Cách xử lý |
|---|---|
| Ramp-up là bước nhảy 90 → 190 | Nội suy tuyến tính 90 → 190 trong pha, sau đó jitter có seed |
| Round Robin khởi động bằng `t` mỗi giây | Dispatcher giữ con trỏ theo tổng request đã phân phối |
| RAM chỉ là công thức proxy, không giới hạn queue | Tính số slot từ RAM, giới hạn cả service batch và backlog |
| CPU chưa có cấu hình riêng | Giới hạn service bằng capacity và CPU cores × requests/core/s |
| Latency proxy suy từ độ dài queue | FIFO timestamp cho từng request hoàn tất; lưu histogram mean/p95 |
| Chia cho 0 khi workload rỗng | Báo lỗi đầu vào; workload toàn 0 là trường hợp hợp lệ |
| Cấu hình hardcode, không test/biểu đồ | JSON có validation, pytest, pipeline CSV/PNG/report |
| Chưa thể tái kiểm tra p95 | Histogram request-weighted, nearest-rank, không dùng p95 của mean theo giây |

Mô hình mới giữ batch một giây và công thức hạch toán của bản đầu. Giá trị RAM và latency thay đổi có chủ đích; throughput có thể thay đổi vì workload và dispatcher được sửa. Dữ liệu gốc giữ nguyên; có lệnh replay workload và vẽ schema cũ trong README.

Giai đoạn C–F chưa thực hiện ở đợt A + B; không có checkpoint, training log hoặc API thật.
