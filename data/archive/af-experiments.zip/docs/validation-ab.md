# Lịch sử kiểm chứng A + B

Ngày thực hiện: 06/11/2026 (Asia/Saigon). Môi trường thực chạy: Windows, Python 3.11.5 trong `.venv`, Matplotlib 3.10.6, pytest 9.0.2. `.venv` dùng system site packages vì pip bị chặn truy cập mạng. Không cài hoặc khởi động dịch vụ cloud.

## Giai đoạn A

Tạo `cloud_sim/__init__.py`, `config.py`, `workload.py`, `model.py`, `policies.py`, `engine.py`, `configs/simulation.json`, `tests/conftest.py`, `tests/test_simulator.py`.

32 test simulator đã qua: ví dụ FIFO/latency tính tay; CPU/RAM giới hạn service và backlog; queue bằng 0; đầu vào âm/không nguyên/NaN/Inf; cấu hình sai; Round Robin liên tục; Least Loaded ưu tiên tải và chỗ trống; conservation từng tick/toàn run trên tải ngẫu nhiên và quá tải; không dùng tương lai; workload rỗng/toàn 0; seed/RNG isolation; ramp tuyến tính; nearest-rank p95; không lấy trung bình latency qua tick không có hoàn tất.

Lệnh chạy lại:

```powershell
.\.venv\Scripts\python.exe -m pytest -q tests/test_simulator.py
```

Không quan sát thấy lỗi hạch toán hoặc vi phạm giới hạn tài nguyên trong các kiểm thử. Latency và tài nguyên vẫn là mô hình chưa hiệu chỉnh, theo `architecture.md`.

## Giai đoạn B

Tạo `cloud_sim/storage.py`, `experiments.py`, `plotting.py`, `run_baselines.py`, `plot_results.py`, `tests/test_baselines.py`, `requirements.txt`, `pytest.ini`, `.gitignore` và tài liệu `README.md`, `docs/audit.md`, `architecture.md`, `experiments.md`, `windows-setup.md`, `task-list.md`, tệp kiểm chứng này. Không sửa các tệp ban đầu.

11 test baseline đã qua: cùng workload cho từng policy, tái lập CSV, aggregate sample std, đọc/replay CSV cũ mà không đổi file gốc, seed không hợp lệ, ngăn lặp trace thành nhiều seed giả, CSV lỗi, bảy PNG cho dữ liệu legacy và trường hợp zero traffic.

Tổng suite: **43 passed**, lần kiểm tra cuối 6,24 giây. Đã tắt autoload pytest plugin bên ngoài project trong lần kiểm tra cuối để tránh cảnh báo `requests` từ gói hệ thống không liên quan.

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'
.\.venv\Scripts\python.exe -m pytest -q
Remove-Item Env:\PYTEST_DISABLE_PLUGIN_AUTOLOAD
.\.venv\Scripts\python.exe run_baselines.py --seeds 42 43 44 45 46
.\.venv\Scripts\python.exe plot_results.py
```

Đã chạy hai lần thí nghiệm năm seed và so sánh byte: cả sáu CSV trong `results/csv/` khớp hoàn toàn. Metadata timestamp thay đổi theo lần chạy, không dùng làm điều kiện khớp byte.

## Kết quả đã tạo thực tế

| Output mặc định | Số dòng dữ liệu |
|---|---:|
| workload.csv | 900 |
| cluster_metrics.csv | 5400 |
| timeseries.csv | 1800 |
| summary.csv | 10 |
| comparison.csv | 2 |
| latency_histogram.csv | 7078 |

Bảy PNG đã kiểm tra mở được và xem trực quan: comparison 2600×1600, CPU/RAM/queue 2200×1200, workload/error 2200×800, latency/throughput 2200×1400, tất cả 200 DPI. Các trục, legend và nhãn simulation hiển thị rõ. CSV và biểu đồ đều được sinh từ chương trình.

| Thuật toán | Throughput req/s | Error % | Latency mean ms |
|---|---:|---:|---:|
| Round Robin | 169.78 ± 0.72 | 10.38 ± 0.24 | 1026.38 ± 18.04 |
| Least Loaded | 172.48 ± 0.87 | 9.24 ± 0.36 | 1203.08 ± 11.63 |

Các số là mean ± sample std của năm seed 42–46. Least Loaded tăng throughput, giảm error nhưng latency cao hơn trong thí nghiệm này. Không kết luận ý nghĩa thống kê hoặc ưu thế MARL.

## Kiểm chứng tương thích

Đã import và chạy lại hàm simulator gốc với workload cũ, không ghi file; summary của cả hai thuật toán khớp mọi cột với `output/summary.csv`. Đã chạy CLI replay và CLI plot legacy thành công:

```powershell
.\.venv\Scripts\python.exe run_baselines.py --workload-csv output/workload.csv --seeds 42 --output results/replay --no-plots
.\.venv\Scripts\python.exe plot_results.py --input output --output results/legacy_figures
```

Replay dùng mô hình mới trên đúng 36.352 request: Round Robin completed=32.599, dropped=3.673, waiting=80; Least Loaded completed=33.160, dropped=3.192, waiting=0. Chênh lệch nhỏ với Round Robin lịch sử là hệ quả cursor liên tục được sửa. Các CSV gốc giữ nguyên; replay được ghi riêng trong `results/replay/`.

## Phần chưa thực hiện và giới hạn

Không có test thất bại còn mở. Cài dependency sạch từ mạng chưa xác minh trong sandbox vì socket bị chặn; phiên này đã kiểm chứng các phiên bản gói hiện có. Chưa thực hiện C–F: môi trường MARL, IPPO/checkpoint/log, đánh giá MARL bằng testing seed độc lập và FastAPI. Không có dữ liệu huấn luyện được tạo hay suy diễn.

Mô hình chỉ có lỗi do overflow, arrival theo lô một giây, tài nguyên cố định và không drain queue cuối run. Những giả định này cần được giữ nguyên khi so sánh hoặc báo cáo rõ khi thay đổi.
