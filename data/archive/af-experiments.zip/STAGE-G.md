# Bàn giao G — thu thập dữ liệu K3s và calibration

**Chưa xác nhận kết nối Cluster A thật.** Đã triển khai code, offline tests và Locust/HTTP smoke trên Windows localhost. Không deploy lên K3s, không gọi OpenStack, không sửa React, không retrain mô hình đã bàn giao. Fixtures/local smoke ghi source simulated; `connected_to_real_cluster=false`.

## Điểm bắt đầu

- [Hướng dẫn Windows, Ubuntu OpenStack và VM K3s](docs/real-cluster-integration.md).
- [Khám phá node/network, triển khai và gỡ sample app](docs/k3s-deployment.md).
- [Schema, provenance, preprocessing, calibration và giới hạn](docs/metrics-calibration.md).
- [Bản đồ thư mục và lệnh cũ–mới](docs/project-layout.md); [mục lục tài liệu](docs/README.md).

## Đã triển khai

| Thành phần | Tệp/nhóm tệp |
|---|---|
| Schema real/simulated, timestamps, layers và CSV | integration/schema.py |
| CPU/memory quantity, inventory và app delta parser | integration/quantities.py, parser.py |
| Collector kubectl GET + app GET, identity checks, raw/error/session logs | integration/collector.py |
| Ubuntu host/hypervisor /proc, không gán cluster_id | integration/host.py |
| Ghép đúng pod/run/source/profile, freshness/dedup | integration/preprocess.py |
| Fit CPU/RAM/latency, capacity lower bound/overload, candidate A có điều kiện | integration/calibration.py |
| Adapter simulator/Locust sang schema chung | integration/export.py |
| Sample app stdlib health/work/metrics, bounded work/events | apps/sample_api/server.py |
| Namespace, một Deployment, ClusterIP Service, RBAC get/list tùy chọn | deploy/k3s/ |
| Locust bốn pha, profile có giới hạn và failure/latency guard | loadtests/, configs/integration/ |
| CLI G và smoke offline + localhost | cli/cluster.py, cluster_smoke.py |
| Tests và synthetic fixtures | tests/integration/, tests/fixtures/ |

Mã CLI cũ đã nhóm vào `cli/`; các launcher ở gốc giữ tương thích. Tests chia thành simulation/marl/api/integration. Không di chuyển hoặc ghi đè kết quả `results/`, `output/`, ZIP A–F; legacy `simulate.py` giữ nguyên.

## Kết quả kiểm chứng

**128/128 test đạt (20,38 giây): 81 A–F + 47 G.** Kết quả JUnit được ghi riêng trong data/validation, không ghi đè kết quả kiểm thử A–F.

- Tests G bao phủ schema/parser/collector/calibration, HTTP app, profile/guard, YAML/RBAC và launcher compatibility. Kết quả toàn suite/JUnit: [stage-g-tests.xml](data/validation/stage-g-tests.xml).
- [Smoke cuối](data/demo/stage-g-final/smoke-evidence.json): 24 record fixture, 7 aligned windows, 5.400 record simulation được export, **6 request localhost thành công**, Locust tự kết thúc sau profile ngắn.
- Negative smoke xác nhận `--source real` bị từ chối khi target chỉ là app Windows local; không có request workload bị gửi trong lần bị từ chối.
- Calibration fixture ghi `fixture_demonstration_not_real_calibration`, không cho xuất candidate calibrated thật. P95 thiếu events để null, không bịa giá trị.
- API simulation A–F vẫn trả bốn endpoint và OpenAPI hợp lệ qua HTTP thật sau sắp xếp CLI: [API compatibility](data/validation/api-af-compatibility.json).
- [Preservation](data/validation/preservation.json): 161 artifact cũ, 18 module model/MARL/API, ba config gốc và hai legacy file đều giữ SHA-256. Không có model/checkpoint/result cũ bị thay đổi.

Các lần smoke dùng dữ liệu riêng trong `data/demo`, không phải phép đo capacity/latency của Cluster A. Không diễn giải hệ số fixture thành năng lực thật.

## Lệnh chạy lại trên Windows

```powershell
Set-Location 'D:\HocTap\hk7\VMWare\cloud_marl_simulator_start'
.\.venv\Scripts\python.exe -m pip install -r requirements-integration.txt
.\.venv\Scripts\python.exe -m pytest -q tests/integration
.\.venv\Scripts\python.exe -m cli.cluster_smoke --output data/demo/my-next-smoke
.\.venv\Scripts\python.exe -m cli.package --output dist/cloud_marl_stage_g.zip
```

Collector/preprocess/calibration/app dùng standard library. Locust 2.47.0 đã được cài và chạy trong `.venv`; phiên này vẫn dùng system site packages, nên không coi đó là venv cô lập sạch. Full suite A–F cần các dependency trong requirements.txt. Không cần cài Kubernetes/Docker/Prometheus/SDK trên Windows.

## Các lệnh phải chạy trong VM K3s để xác minh thật

Khám phá **trước**, không giả định IP/context:

```bash
hostnamectl
ip -br address
sudo k3s kubectl config current-context
sudo k3s kubectl get nodes -o wide
sudo k3s kubectl get services -A -o wide
sudo k3s kubectl get --raw /apis/metrics.k8s.io/v1beta1/nodes
```

Sau khi đối chiếu đúng VM A và đọc hướng dẫn deploy:

```bash
sudo k3s kubectl apply -f deploy/k3s/namespace.yaml
sudo k3s kubectl -n cloud-calibration create configmap calibration-work-code --from-file=server.py=apps/sample_api/server.py --dry-run=client -o yaml | sudo k3s kubectl apply -f -
sudo k3s kubectl apply -f deploy/k3s/deployment.yaml -f deploy/k3s/service.yaml
sudo k3s kubectl -n cloud-calibration rollout status deployment/calibration-work --timeout=90s
sudo k3s kubectl -n cloud-calibration port-forward --address 127.0.0.1 service/calibration-work 18080:8080
```

Tạo collector.local.json từ context/node thực theo tài liệu, rồi terminal khác:

```bash
python3 -m cli.cluster collect --config configs/integration/collector.local.json --samples 14 --interval 15 --output data/runs/first-a/collector
```

Ubuntu DevStack chỉ cần lệnh khám phá OpenStack và `/proc` sampler riêng, không restart dịch vụ. Windows tạo tải qua SSH tunnel đã kiểm tra, với cùng run ID/profile; xem tài liệu để có đủ lệnh và cách chép CSV.

## Chờ kiểm chứng trên Cluster A

1. Context/node/VM identity và đường SSH/route thực.
2. Image pull, pod Ready, Service/EndpointSlice và port-forward từ Windows.
3. RBAC/quyền Metrics API, độ tươi timestamp/window và đồng bộ đồng hồ.
4. CPU/RAM/Pod status và request counters/latency khi có tải thật.
5. Ảnh hưởng lên Ubuntu/OpenStack; capacity chỉ là lower bound nếu chưa quan sát overload.
6. Fit chất lượng đủ, mapping budget pod sang simulator A; B/C vẫn giả định mô phỏng.

Candidate nếu đủ điều kiện chỉ ghi **A.capacity vào file mới**, kèm provenance. Không sửa config gốc hoặc tự gán CPU/RAM/latency/queue chưa đo. Mô hình batch 1s và service latency hiện tại có giới hạn khi so với HTTP thật, đã ghi trong [audit](docs/stage-g-audit.md); logic training không đổi trong G.
