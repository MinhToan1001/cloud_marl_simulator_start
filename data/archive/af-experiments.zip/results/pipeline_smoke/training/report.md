# IPPO training — simulation only

Completed episodes: 2; environment steps: 360.
Device: CPU; elapsed seconds: 3.14.
Training workload seeds: [1000, 1001]; validation: [20001].
Best episode: 0; validation mean step reward: 0.265029.

Three independent actor-critics; no weight sharing or imitation/pretraining. Validation chooses best.pt; testing is performed only by evaluate_marl.py. best.pt may be episode 0 if no learned policy improved validation.

csv/training.csv and csv/agent_training.csv contain measured PPO losses/entropy and rollout metrics; csv/validation.csv records sample validation with an isolated fixed policy RNG. figures/ contains learning curves.
Resume is exact at saved episode boundaries with unchanged hyperparameters except total episodes. last.pt includes optimizer and RNG states and the best checkpoint snapshot.
