# Đánh giá Round Robin, Least Loaded và MARL (IPPO)

**Dữ liệu simulation; không phải metrics OpenStack/Kubernetes/AWS.**

Checkpoint episode 0, chọn bằng validation, inference sample với policy RNG riêng có seed cố định.
Policy initialization seed: 7; training workload seeds: [1000, 1001];
validation: [20001]; testing độc lập: [30001, 30002].
Mỗi cặp scenario/seed dùng cùng workload, tài nguyên, tick và hạch toán cho cả ba phương pháp.
`metadata.json` lưu hash workload/checkpoint và cấu hình từng scenario; không tune bằng tập testing.

| Scenario | Thuật toán | Throughput req/s | Latency mean ms | P95 ms | Error % | Thành công |
|---|---|---:|---:|---:|---:|---:|
| mixed | round_robin | 169.78 ± 0.27 | 1021.11 ± 12.33 | 2831.39 ± 12.18 | 9.77 ± 0.14 | 30560.00 ± 48.08 |
| mixed | least_loaded | 173.44 ± 0.33 | 1177.62 ± 1.81 | 2895.83 ± 5.89 | 8.19 ± 0.17 | 31218.50 ± 60.10 |
| mixed | marl | 168.72 ± 5.15 | 1114.18 ± 99.06 | 2856.67 ± 23.57 | 10.33 ± 2.72 | 30370.00 ± 926.31 |

Giá trị mean ± sample std giữa testing seed; p95 tính trên từng request hoàn tất của từng run rồi tổng hợp.
CPU/RAM trung bình, imbalance, số dropped/waiting và số mẫu hợp lệ cũng có trong `csv/comparison.csv`.

## Diễn giải kết quả

Trong mixed, MARL − round_robin: -1.06 req/s throughput; +93.07 ms latency mean; +0.56 điểm phần trăm error.
Trong mixed, MARL − least_loaded: -4.71 req/s throughput; -63.45 ms latency mean; +2.15 điểm phần trăm error.

Không coi throughput cao hơn là thắng mọi tiêu chí. Kiểm tra đồng thời latency, drop, imbalance và queue cuối.
Đây là đánh giá trên năm seed tải (mặc định), với một seed huấn luyện chính sách; không phải năm lần train độc lập.
Mean/std mô tả biến thiên, chưa phải chứng minh ý nghĩa thống kê hoặc ưu thế ngoài mô hình.

## Ưu điểm và giới hạn

Round Robin đơn giản; Least Loaded phản ứng trực tiếp với backlog/capacity và cần telemetry hiện tại.
MARL học ba policy riêng từ reward, có chi phí training và suy luận; có thể kém baseline nếu học chưa đủ hoặc reward lệch mục tiêu.
Không có imitation hay hardcode kết quả MARL. Training hữu hạn, mạng nhỏ chạy CPU và chọn checkpoint bằng validation.
Stable/Ramp-up/Spike được chạy riêng theo phase; Recovery gồm Spike rồi Recovery để quan sát xả backlog.
Mô hình arrival theo lô một giây, capacity cố định, chưa hiệu chỉnh cluster thật, chỉ có lỗi overflow.
Không drain queue cuối run; dropped/waiting không có latency hoàn tất, nên có censoring.
Không dùng kết quả này để khẳng định hiệu năng OpenStack/AWS thật.

## Dữ liệu và biểu đồ

`csv/summary.csv`: từng run; `comparison.csv`: mean/std; `paired_differences.csv`: chênh lệch paired theo seed;
`cluster_metrics.csv`, `timeseries.csv`, `workload.csv`, `latency_histogram.csv`: dữ liệu để tái kiểm tra.
`figures/`: bảy hình cho scenario mixed, seed đầu tiên ở các time-series; comparison dùng tất cả testing seed.
`figures/scenario_comparison.png`: throughput, latency, error và imbalance giữa các scenario.
